#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import torch
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import json
from datetime import datetime
import argparse

# 添加项目路径
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.models.model_trainer import GoldThreadModelTrainer
from src.models.advanced_gold_thread_trainer import AdvancedGoldThreadTrainer

class GenerationQualityComparator:
    """生成质量对比器"""
    
    def __init__(self, output_dir="output/results/comparison"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
        plt.rcParams['axes.unicode_minus'] = False
    
    def compare_models(self, test_prompts, num_images_per_prompt=2):
        """对比不同模型的生成质量"""
        print("=== 生成质量对比测试 ===")
        
        results = {
            "timestamp": datetime.now().isoformat(),
            "test_prompts": test_prompts,
            "num_images_per_prompt": num_images_per_prompt,
            "models": {}
        }
        
        # 测试基础训练器
        print("\n1. 测试基础训练器...")
        try:
            basic_trainer = GoldThreadModelTrainer()
            basic_results = self._test_model(
                basic_trainer, "basic", test_prompts, num_images_per_prompt
            )
            results["models"]["basic"] = basic_results
        except Exception as e:
            print(f"基础训练器测试失败: {e}")
            results["models"]["basic"] = {"error": str(e)}
        
        # 测试高级训练器
        print("\n2. 测试高级训练器...")
        try:
            advanced_trainer = AdvancedGoldThreadTrainer()
            advanced_results = self._test_model(
                advanced_trainer, "advanced", test_prompts, num_images_per_prompt
            )
            results["models"]["advanced"] = advanced_results
        except Exception as e:
            print(f"高级训练器测试失败: {e}")
            results["models"]["advanced"] = {"error": str(e)}
        
        # 生成对比报告
        self._generate_comparison_report(results)
        
        return results
    
    def _test_model(self, trainer, model_name, test_prompts, num_images_per_prompt):
        """测试单个模型"""
        model_output_dir = os.path.join(self.output_dir, model_name)
        os.makedirs(model_output_dir, exist_ok=True)
        
        results = {
            "model_name": model_name,
            "generated_images": [],
            "generation_times": [],
            "errors": []
        }
        
        for i, prompt in enumerate(test_prompts):
            print(f"  生成提示词 {i+1}/{len(test_prompts)}: {prompt}")
            
            try:
                import time
                start_time = time.time()
                
                # 生成图像
                if hasattr(trainer, 'generate_advanced'):
                    images = trainer.generate_advanced(
                        prompt=prompt,
                        output_dir=os.path.join(model_output_dir, f"prompt_{i+1}"),
                        num_images=num_images_per_prompt
                    )
                else:
                    images = trainer.generate(
                        prompt=prompt,
                        output_dir=os.path.join(model_output_dir, f"prompt_{i+1}"),
                        num_images=num_images_per_prompt
                    )
                
                generation_time = time.time() - start_time
                
                results["generated_images"].append({
                    "prompt": prompt,
                    "num_images": len(images) if images else 0,
                    "output_dir": os.path.join(model_output_dir, f"prompt_{i+1}")
                })
                
                results["generation_times"].append(generation_time)
                
                print(f"    生成完成，用时: {generation_time:.2f}秒")
                
            except Exception as e:
                error_msg = f"生成失败 - 提示词: {prompt}, 错误: {str(e)}"
                print(f"    {error_msg}")
                results["errors"].append(error_msg)
        
        # 计算统计信息
        if results["generation_times"]:
            results["avg_generation_time"] = np.mean(results["generation_times"])
            results["total_generation_time"] = sum(results["generation_times"])
        else:
            results["avg_generation_time"] = 0
            results["total_generation_time"] = 0
        
        results["success_rate"] = (len(test_prompts) - len(results["errors"])) / len(test_prompts)
        
        return results
    
    def _generate_comparison_report(self, results):
        """生成对比报告"""
        print("\n=== 生成对比报告 ===")
        
        # 创建可视化对比
        self._create_visual_comparison(results)
        
        # 保存详细报告
        report_path = os.path.join(self.output_dir, "comparison_report.json")
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        # 生成文本报告
        self._create_text_report(results)
        
        print(f"对比报告已保存到: {self.output_dir}")
    
    def _create_visual_comparison(self, results):
        """创建可视化对比"""
        models = [name for name in results["models"].keys() if "error" not in results["models"][name]]
        
        if len(models) < 2:
            print("可用模型数量不足，跳过可视化对比")
            return
        
        # 创建性能对比图
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        fig.suptitle('Model Generation Quality Comparison', fontsize=16)
        
        # 成功率对比
        success_rates = [results["models"][model]["success_rate"] for model in models]
        axes[0].bar(models, success_rates, color=['skyblue', 'lightcoral'])
        axes[0].set_title('Generation Success Rate')
        axes[0].set_ylabel('Success Rate')
        axes[0].set_ylim(0, 1)
        
        # 平均生成时间对比
        avg_times = [results["models"][model]["avg_generation_time"] for model in models]
        axes[1].bar(models, avg_times, color=['lightgreen', 'orange'])
        axes[1].set_title('Average Generation Time')
        axes[1].set_ylabel('Time (seconds)')
        
        # 总生成时间对比
        total_times = [results["models"][model]["total_generation_time"] for model in models]
        axes[2].bar(models, total_times, color=['plum', 'gold'])
        axes[2].set_title('Total Generation Time')
        axes[2].set_ylabel('Time (seconds)')
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, "performance_comparison.png"), dpi=300, bbox_inches='tight')
        plt.close()
        
        print("性能对比图已生成")
    
    def _create_text_report(self, results):
        """创建文本报告"""
        report_lines = []
        report_lines.append("# 金线刺绣生成模型对比报告")
        report_lines.append(f"\n生成时间: {results['timestamp']}")
        report_lines.append(f"测试提示词数量: {len(results['test_prompts'])}")
        report_lines.append(f"每个提示词生成图像数: {results['num_images_per_prompt']}")
        
        report_lines.append("\n## 测试提示词")
        for i, prompt in enumerate(results['test_prompts'], 1):
            report_lines.append(f"{i}. {prompt}")
        
        report_lines.append("\n## 模型对比结果")
        
        for model_name, model_results in results["models"].items():
            report_lines.append(f"\n### {model_name.upper()} 模型")
            
            if "error" in model_results:
                report_lines.append(f"❌ 模型测试失败: {model_results['error']}")
                continue
            
            report_lines.append(f"- 生成成功率: {model_results['success_rate']:.2%}")
            report_lines.append(f"- 平均生成时间: {model_results['avg_generation_time']:.2f} 秒")
            report_lines.append(f"- 总生成时间: {model_results['total_generation_time']:.2f} 秒")
            
            if model_results['errors']:
                report_lines.append(f"- 错误数量: {len(model_results['errors'])}")
                for error in model_results['errors']:
                    report_lines.append(f"  - {error}")
        
        # 生成建议
        report_lines.append("\n## 建议")
        
        models = [name for name in results["models"].keys() if "error" not in results["models"][name]]
        
        if len(models) >= 2:
            # 找出最佳模型
            best_success = max(models, key=lambda m: results["models"][m]["success_rate"])
            fastest = min(models, key=lambda m: results["models"][m]["avg_generation_time"])
            
            report_lines.append(f"- 最高成功率: {best_success.upper()} 模型 ({results['models'][best_success]['success_rate']:.2%})")
            report_lines.append(f"- 最快生成速度: {fastest.upper()} 模型 ({results['models'][fastest]['avg_generation_time']:.2f}秒)")
            
            if best_success == "advanced":
                report_lines.append("- 🎯 **推荐使用高级训练器**，具有更好的生成质量和多模态融合能力")
            elif best_success == "basic":
                report_lines.append("- ⚡ 基础训练器在当前测试中表现更好，但建议检查高级训练器的配置")
        
        # 保存报告
        report_path = os.path.join(self.output_dir, "comparison_report.md")
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_lines))
        
        print("文本报告已生成")

def main():
    parser = argparse.ArgumentParser(description="生成质量对比测试")
    parser.add_argument("--output_dir", type=str, default="output/results/comparison", help="输出目录")
    parser.add_argument("--num_images", type=int, default=2, help="每个提示词生成的图像数量")
    
    args = parser.parse_args()
    
    # 测试提示词
    test_prompts = [
        "一品文官仙鹤金线刺绣",
        "二品文官锦鸡金线刺绣",
        "三品文官孔雀金线刺绣",
        "一品武官麒麟金线刺绣"
    ]
    
    # 创建对比器
    comparator = GenerationQualityComparator(output_dir=args.output_dir)
    
    # 执行对比测试
    results = comparator.compare_models(test_prompts, args.num_images)
    
    print(f"\n✅ 对比测试完成，结果保存在: {args.output_dir}")

if __name__ == "__main__":
    main() 