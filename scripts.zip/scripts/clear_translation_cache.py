#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import shutil
from datetime import datetime

class TranslationCacheCleaner:
    """翻译缓存清理器 - 删除所有翻译记录以便重新翻译"""
    
    def __init__(self, knowledge_dir="data/知识层1", output_dir="data/pretranslated"):
        self.knowledge_dir = knowledge_dir
        self.output_dir = output_dir
        
        print("🧹 翻译缓存清理器初始化")
        print(f"   知识层目录: {knowledge_dir}")
        print(f"   输出目录: {output_dir}")
    
    def clear_translation_status_files(self):
        """清除所有类别目录下的翻译状态文件"""
        print("\n🔄 清除翻译状态文件...")
        
        cleared_count = 0
        
        if not os.path.exists(self.knowledge_dir):
            print(f"❌ 知识层目录不存在: {self.knowledge_dir}")
            return cleared_count
        
        # 遍历所有类别目录
        for category_name in os.listdir(self.knowledge_dir):
            category_path = os.path.join(self.knowledge_dir, category_name)
            if not os.path.isdir(category_path):
                continue
            
            # 查找翻译状态文件
            status_file = os.path.join(category_path, ".translated.json")
            if os.path.exists(status_file):
                try:
                    # 备份状态文件（可选）
                    backup_file = os.path.join(category_path, f".translated_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
                    shutil.copy2(status_file, backup_file)
                    
                    # 删除状态文件
                    os.remove(status_file)
                    print(f"  ✅ 已清除: {category_name}/.translated.json")
                    print(f"     备份到: {os.path.basename(backup_file)}")
                    cleared_count += 1
                except Exception as e:
                    print(f"  ❌ 清除失败: {category_name}/.translated.json - {e}")
        
        print(f"\n📊 翻译状态文件清除完成: {cleared_count} 个文件")
        return cleared_count
    
    def clear_pretranslated_output(self):
        """清除预翻译输出目录"""
        print("\n🔄 清除预翻译输出目录...")
        
        if not os.path.exists(self.output_dir):
            print(f"  ℹ️  输出目录不存在: {self.output_dir}")
            return
        
        try:
            # 备份整个输出目录
            backup_dir = f"{self.output_dir}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.copytree(self.output_dir, backup_dir)
            print(f"  💾 输出目录已备份到: {backup_dir}")
            
            # 删除输出目录
            shutil.rmtree(self.output_dir)
            print(f"  ✅ 已删除输出目录: {self.output_dir}")
            
            # 重新创建空目录
            os.makedirs(self.output_dir, exist_ok=True)
            print(f"  📁 已重新创建空目录: {self.output_dir}")
            
        except Exception as e:
            print(f"  ❌ 清除输出目录失败: {e}")
    
    def clear_specific_files(self, file_patterns=None):
        """清除特定的翻译文件"""
        if file_patterns is None:
            file_patterns = [
                "translated_knowledge.json",
                "translated_craft.json", 
                "unified_prompts.json",
                "translation_report.json"
            ]
        
        print(f"\n🔄 清除特定翻译文件...")
        
        cleared_files = []
        
        for root, dirs, files in os.walk(self.output_dir):
            for file in files:
                if any(pattern in file for pattern in file_patterns):
                    file_path = os.path.join(root, file)
                    try:
                        # 备份文件
                        backup_path = f"{file_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                        shutil.copy2(file_path, backup_path)
                        
                        # 删除文件
                        os.remove(file_path)
                        print(f"  ✅ 已删除: {os.path.relpath(file_path, self.output_dir)}")
                        print(f"     备份到: {os.path.relpath(backup_path, self.output_dir)}")
                        cleared_files.append(file_path)
                    except Exception as e:
                        print(f"  ❌ 删除失败: {file_path} - {e}")
        
        print(f"\n📊 特定文件清除完成: {len(cleared_files)} 个文件")
        return cleared_files
    
    def show_current_status(self):
        """显示当前翻译状态"""
        print("\n📋 当前翻译状态:")
        
        # 检查翻译状态文件
        status_files = []
        if os.path.exists(self.knowledge_dir):
            for category_name in os.listdir(self.knowledge_dir):
                category_path = os.path.join(self.knowledge_dir, category_name)
                if os.path.isdir(category_path):
                    status_file = os.path.join(category_path, ".translated.json")
                    if os.path.exists(status_file):
                        try:
                            with open(status_file, 'r', encoding='utf-8') as f:
                                status_data = json.load(f)
                            status_files.append((category_name, len(status_data)))
                        except:
                            status_files.append((category_name, "错误"))
        
        if status_files:
            print(f"  📁 发现翻译状态文件: {len(status_files)} 个类别")
            for category, count in status_files:
                print(f"     {category}: {count} 个已翻译文件")
        else:
            print(f"  ✅ 没有发现翻译状态文件")
        
        # 检查输出文件
        output_files = []
        if os.path.exists(self.output_dir):
            for root, dirs, files in os.walk(self.output_dir):
                for file in files:
                    if file.endswith('.json'):
                        file_path = os.path.join(root, file)
                        rel_path = os.path.relpath(file_path, self.output_dir)
                        try:
                            file_size = os.path.getsize(file_path)
                            output_files.append((rel_path, file_size))
                        except:
                            output_files.append((rel_path, "错误"))
        
        if output_files:
            print(f"  📄 发现输出文件: {len(output_files)} 个")
            for file_path, size in output_files:
                if isinstance(size, int):
                    size_str = f"{size/1024:.1f} KB"
                else:
                    size_str = str(size)
                print(f"     {file_path}: {size_str}")
        else:
            print(f"  ✅ 没有发现输出文件")
    
    def interactive_clean(self):
        """交互式清理"""
        print("\n🤖 交互式翻译缓存清理")
        print("=" * 50)
        
        # 显示当前状态
        self.show_current_status()
        
        print("\n❓ 请选择清理操作:")
        print("  1. 只清除翻译状态文件（保留输出文件）")
        print("  2. 只清除输出目录（保留状态文件）") 
        print("  3. 清除所有翻译记录（状态文件 + 输出文件）")
        print("  4. 只清除特定输出文件")
        print("  5. 显示当前状态")
        print("  0. 退出")
        
        while True:
            try:
                choice = input("\n请输入选择 (0-5): ").strip()
                
                if choice == "0":
                    print("👋 退出清理程序")
                    break
                elif choice == "1":
                    print("\n🧹 清除翻译状态文件...")
                    count = self.clear_translation_status_files()
                    print(f"✅ 完成！清除了 {count} 个状态文件")
                elif choice == "2":
                    print("\n🧹 清除输出目录...")
                    self.clear_pretranslated_output()
                    print("✅ 完成！")
                elif choice == "3":
                    print("\n🧹 清除所有翻译记录...")
                    count1 = self.clear_translation_status_files()
                    self.clear_pretranslated_output()
                    print(f"✅ 完成！清除了 {count1} 个状态文件和整个输出目录")
                elif choice == "4":
                    print("\n🧹 清除特定输出文件...")
                    files = self.clear_specific_files()
                    print(f"✅ 完成！清除了 {len(files)} 个文件")
                elif choice == "5":
                    self.show_current_status()
                else:
                    print("❌ 无效选择，请输入 0-5")
                    
            except KeyboardInterrupt:
                print("\n\n👋 用户中断，退出程序")
                break
            except Exception as e:
                print(f"❌ 操作失败: {e}")
    
    def full_clean(self):
        """完全清理（非交互式）"""
        print("\n🧹 执行完全清理...")
        
        # 显示当前状态
        self.show_current_status()
        
        # 清除所有记录
        count = self.clear_translation_status_files()
        self.clear_pretranslated_output()
        
        print(f"\n✅ 完全清理完成！")
        print(f"   清除状态文件: {count} 个")
        print(f"   清除输出目录: {self.output_dir}")
        print(f"\n💡 现在可以重新运行翻译脚本使用Google翻译了:")
        print(f"   python scripts/pretranslate_knowledge_craft.py --translation_method google")

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="清除翻译缓存和记录")
    parser.add_argument("--knowledge_dir", type=str, default="data/知识层1",
                       help="知识层目录路径")
    parser.add_argument("--output_dir", type=str, default="data/pretranslated", 
                       help="预翻译输出目录")
    parser.add_argument("--interactive", action="store_true",
                       help="交互式清理模式")
    parser.add_argument("--full", action="store_true",
                       help="完全清理所有记录")
    parser.add_argument("--status-only", action="store_true",
                       help="只清除翻译状态文件")
    parser.add_argument("--output-only", action="store_true", 
                       help="只清除输出文件")
    
    args = parser.parse_args()
    
    # 创建清理器
    cleaner = TranslationCacheCleaner(
        knowledge_dir=args.knowledge_dir,
        output_dir=args.output_dir
    )
    
    try:
        if args.interactive:
            cleaner.interactive_clean()
        elif args.full:
            cleaner.full_clean()
        elif args.status_only:
            count = cleaner.clear_translation_status_files()
            print(f"✅ 状态文件清理完成: {count} 个文件")
        elif args.output_only:
            cleaner.clear_pretranslated_output()
            print("✅ 输出目录清理完成")
        else:
            # 默认显示状态并询问
            cleaner.show_current_status()
            print("\n❓ 是否要清除所有翻译记录以便重新使用Google翻译？(y/n): ", end="")
            response = input().strip().lower()
            if response in ['y', 'yes', '是']:
                cleaner.full_clean()
            else:
                print("👋 取消清理")
                
    except KeyboardInterrupt:
        print("\n\n👋 用户中断，退出程序")
    except Exception as e:
        print(f"\n❌ 清理失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main() 