#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
统一RTF文件处理工具 - 一键完成所有功能
RTF处理 + 知识图谱构建 + 质量评估
"""

import os
import re
import json
import argparse
import sys
from striprtf.striprtf import rtf_to_text

# 添加src目录到路径
sys.path.append('src')
sys.path.append('src/data_processing')

try:
    from qing_regulations_parser import QingRegulationsParser
    QING_PARSER_AVAILABLE = True
    IMPORT_ERROR_MSG = None
except ImportError as e:
    QING_PARSER_AVAILABLE = False
    IMPORT_ERROR_MSG = str(e)
    print(f"警告: qing_regulations_parser导入失败")
    print(f"具体错误: {e}")
    print("将使用基础RTF处理功能")

def rtf_unicode_to_chinese(text):
    """处理RTF文件中的Unicode和GBK转义"""
    # 1. 处理\uXXXX转义
    def unicode_replace(match):
        val = int(match.group(1))
        if val < 0:
            val += 65536
        return chr(val)
    text = re.sub(r'\\u(-?\d+)', unicode_replace, text)
    
    # 2. 处理\'XX转义（GBK编码）
    def hex_replace(match):
        try:
            return bytes.fromhex(match.group(1)).decode('gbk')
        except Exception:
            return ''
    text = re.sub(r"\\'([0-9a-fA-F]{2})", hex_replace, text)
    
    return text

def fix_json_format(text):
    """修复JSON格式问题 - 强大版本"""
    try:
        # 先尝试直接解析
        json.loads(text)
        return text
    except json.JSONDecodeError:
        pass
    
    # 修复Unicode转义
    fixed_text = rtf_unicode_to_chinese(text)
    
    try:
        json.loads(fixed_text)
        return fixed_text
    except json.JSONDecodeError:
        pass
    
    # 强大的修复方法：逐步修复
    import re
    
    # 1. 在 "value" 后面如果直接跟 "key": 则添加逗号
    # 匹配：引号结束，可能有空白和换行，然后是引号开始和冒号
    fixed_text = re.sub(r'(".*?")\s*\n\s*(".*?"\s*:)', r'\1,\n  \2', fixed_text)
    
    # 2. 在 } 后面如果直接跟 "key": 则添加逗号
    fixed_text = re.sub(r'(})\s*\n\s*(".*?"\s*:)', r'\1,\n  \2', fixed_text)
    
    # 3. 清理多余的逗号（在}前面的逗号）
    fixed_text = re.sub(r',\s*\n\s*}', '\n}', fixed_text)
    
    try:
        json.loads(fixed_text)
        return fixed_text
    except json.JSONDecodeError as e:
        # 4. 最后的尝试：手动构建JSON
        try:
            # 提取基本信息
            rank_match = re.search(r'"品级"\s*:\s*"([^"]*)"', text)
            animal_match = re.search(r'"名称"\s*:\s*"([^"]*)"', text)
            border_match = re.search(r'"边框类型"\s*:\s*"([^"]*)"', text)
            
            result = {
                "品级": rank_match.group(1) if rank_match else "未知",
                "中心纹样": {
                    "名称": animal_match.group(1) if animal_match else "未知"
                },
                "边框类型": border_match.group(1) if border_match else "未知",
                "文化语义": "详细描述（已简化）"
            }
            
            return json.dumps(result, ensure_ascii=False, indent=2)
            
        except Exception:
            # 返回一个基本的JSON结构
            return json.dumps({
                "error": "JSON parsing failed", 
                "original_preview": text.replace('\n', ' ')[:100] + "...",
                "parse_error": str(e)
            }, ensure_ascii=False, indent=2)

def process_rtf_file(rtf_path, mode='escape_only'):
    """处理单个RTF文件 - 改进版本"""
    try:
        with open(rtf_path, 'r', encoding='utf-8') as f:
            rtf_content = f.read()
    except Exception as e:
        print(f"❌ 读取文件失败 {rtf_path}: {e}")
        return "{}"
    
    # 检查文件是否已经是纯JSON格式
    if rtf_content.strip().startswith('{') and rtf_content.strip().endswith('}'):
        # 已经是JSON格式，尝试修复
        processed_text = fix_json_format(rtf_content)
        try:
            # 测试JSON是否有效
            json.loads(processed_text)
            return processed_text
        except json.JSONDecodeError:
            print(f"⚠️  JSON格式修复失败: {os.path.basename(rtf_path)}")
            return "{}"
    
    if mode == 'full':
        # 完整转换：先striprtf再转义
        try:
            plain_text = rtf_to_text(rtf_content)
            processed_text = rtf_unicode_to_chinese(plain_text)
        except:
            processed_text = rtf_unicode_to_chinese(rtf_content)
    elif mode == 'escape_only':
        # 只做转义还原，不动格式
        processed_text = rtf_unicode_to_chinese(rtf_content)
    elif mode == 'fix_json':
        # 修复JSON格式
        processed_text = fix_json_format(rtf_content)
    else:
        # 默认只做转义处理
        processed_text = rtf_unicode_to_chinese(rtf_content)
    
    return processed_text

def generate_knowledge_graph_visualization(output_dir):
    """生成知识图谱可视化"""
    try:
        # 尝试导入可视化库
        try:
            import matplotlib.pyplot as plt
            import networkx as nx
            import matplotlib
            matplotlib.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei']
            matplotlib.rcParams['axes.unicode_minus'] = False
        except ImportError:
            print("⚠️  缺少可视化依赖库 (matplotlib, networkx)")
            print("💡 可运行: pip install matplotlib networkx")
            return
        
        # 查找知识图谱文件
        jsonld_file = None
        for file in os.listdir(output_dir):
            if file.endswith('knowledge_graph.jsonld'):
                jsonld_file = os.path.join(output_dir, file)
                break
        
        if not jsonld_file or not os.path.exists(jsonld_file):
            print("⚠️  未找到知识图谱文件，跳过可视化")
            return
        
        # 加载知识图谱数据
        with open(jsonld_file, 'r', encoding='utf-8') as f:
            kg_data = json.load(f)
        
        # 从处理摘要中获取正确的知识项目数量
        summary_file = os.path.join(output_dir, 'complete_processing_summary.json')
        knowledge_items_count = 0
        if os.path.exists(summary_file):
            try:
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summary_data = json.load(f)
                    processing_summary = summary_data.get('processing_summary', {})
                    knowledge_items_count = processing_summary.get('total_knowledge_items', 0)
            except:
                pass
        
        # 创建网络图
        G = nx.Graph()
        
        # 添加节点和边
        regulations_count = 0
        
        if '@graph' in kg_data:
            for item in kg_data['@graph']:
                item_type = item.get('@type', '')
                
                # 处理规制节点
                if item_type == 'ge:Regulation':
                    regulations_count += 1
                    label = item.get('label', '未知规制')
                    
                    # 提取品级、类别、动物信息
                    rank_info = item.get('rank', {})
                    category_info = item.get('category', {})
                    animal_info = item.get('animal', {})
                    
                    rank_label = rank_info.get('label', '未知品级') if isinstance(rank_info, dict) else str(rank_info)
                    category_label = category_info.get('label', '未知类别') if isinstance(category_info, dict) else str(category_info)
                    animal_label = animal_info.get('label', '未知动物') if isinstance(animal_info, dict) else str(animal_info)
                    
                    # 添加节点
                    G.add_node(rank_label, type='rank', color='#FF6B6B')
                    G.add_node(category_label, type='category', color='#4ECDC4')
                    G.add_node(animal_label, type='animal', color='#45B7D1')
                    
                    # 添加边
                    G.add_edge(rank_label, category_label, weight=1)
                    G.add_edge(category_label, animal_label, weight=1)
        
        if len(G.nodes()) == 0:
            print("⚠️  知识图谱数据为空，无法生成可视化")
            return
        
        # 创建可视化
        plt.figure(figsize=(16, 12))
        
        # 设置布局
        pos = nx.spring_layout(G, k=2, iterations=50, seed=42)
        
        # 根据节点类型设置颜色
        node_colors = []
        node_sizes = []
        for node in G.nodes():
            node_data = G.nodes[node]
            if '品' in str(node):
                node_colors.append('#FF6B6B')  # 红色 - 品级
                node_sizes.append(3000)
            elif '官' in str(node):
                node_colors.append('#4ECDC4')  # 青色 - 官职
                node_sizes.append(2500)
            else:
                node_colors.append('#45B7D1')  # 蓝色 - 动物
                node_sizes.append(2000)
        
        # 绘制网络图
        nx.draw(G, pos, 
                node_color=node_colors,
                node_size=node_sizes,
                font_size=8,
                font_weight='bold',
                with_labels=True,
                edge_color='#CCCCCC',
                alpha=0.9)
        
        plt.title('《大清会典》纹样规制知识图谱\n(品级-官职-动物关系图)', fontsize=16, fontweight='bold', pad=20)
        plt.axis('off')
        
        # 添加图例
        legend_elements = [
            plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='#FF6B6B', markersize=12, label='品级'),
            plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='#4ECDC4', markersize=12, label='官职类别'),
            plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='#45B7D1', markersize=12, label='动物纹样')
        ]
        plt.legend(handles=legend_elements, loc='upper right', fontsize=10)
        
        # 添加统计信息 - 使用正确的知识项目数量
        stats_text = f"规制数量: {regulations_count}\n知识项目: {knowledge_items_count}\n图谱节点: {len(G.nodes())}\n连接边: {len(G.edges())}"
        plt.text(0.02, 0.98, stats_text, transform=plt.gca().transAxes, 
                fontsize=10, verticalalignment='top',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
        
        # 保存图片
        viz_path = os.path.join(output_dir, 'knowledge_graph_visualization.png')
        plt.savefig(viz_path, dpi=300, bbox_inches='tight', facecolor='white')
        plt.close()
        
        print(f"📊 知识图谱可视化已生成: {viz_path}")
        print(f"   - 规制数量: {regulations_count}")
        print(f"   - 知识项目: {knowledge_items_count}")
        print(f"   - 图谱节点: {len(G.nodes())}")
        print(f"   - 连接边: {len(G.edges())}")
        
    except Exception as e:
        print(f"⚠️  可视化生成失败: {e}")
        print("💡 这不影响主要功能，可以忽略")
        import traceback
        traceback.print_exc()

def process_all_in_one(input_dir, output_dir=None):
    """
    一键完成所有功能：RTF处理 + 知识图谱构建 + 质量评估
    
    参数:
        input_dir (str): RTF文件输入目录
        output_dir (str): 输出目录
    """
    if output_dir is None:
        output_dir = 'output/results/knowledge_complete'
    
    print("=" * 80)
    print("🚀 金线刺绣知识处理系统 - 一键完成所有功能")
    print("=" * 80)
    print(f"📂 输入目录: {input_dir}")
    print(f"📁 输出目录: {output_dir}")
    
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. RTF文件预处理
    print("\n" + "🔧 步骤1: RTF文件预处理")
    print("-" * 40)
    
    processed_count = 0
    rtf_files = []
    
    for root, dirs, files in os.walk(input_dir):
        for file in files:
            if file.endswith('.rtf'):
                rtf_path = os.path.join(root, file)
                rtf_files.append(rtf_path)
                try:
                    # 不修改原文件，只处理内容用于后续分析
                    processed_content = process_rtf_file(rtf_path, mode='escape_only')
                    processed_count += 1
                    if processed_count <= 3:  # 只显示前3个文件的处理信息
                        print(f"✅ 已处理: {os.path.basename(rtf_path)}")
                except Exception as e:
                    print(f"❌ 处理失败 {rtf_path}: {e}")
    
    if processed_count > 3:
        print(f"... 共处理 {processed_count} 个RTF文件")
    
    # 2. 知识图谱构建
    print(f"\n🧠 步骤2: 知识图谱构建")
    print("-" * 40)
    
    if not QING_PARSER_AVAILABLE:
        print("❌ qing_regulations_parser不可用，跳过知识图谱构建")
        summary = {
            'rtf_files_processed': processed_count,
            'knowledge_graph_built': False,
            'error': IMPORT_ERROR_MSG
        }
    else:
        # 创建解析器实例
        parser = QingRegulationsParser(input_dir, output_dir)
        
        # 执行完整处理流程（不需要大清会典文本）
        summary = parser.process_all(
            qing_text_path=None,  # 不依赖大清会典文本
            rtf_dir=input_dir,
            preprocess_rtf=False,  # 已经预处理过了
            rtf_mode='escape_only'
        )
        
        print(f"✅ 知识图谱构建完成")
        print(f"   - 规制数量: {summary.get('total_regulations', 0)}")
        print(f"   - 知识项目: {summary.get('total_knowledge_items', 0)}")
        print(f"   - 图谱节点: {summary.get('knowledge_graph_nodes', 0)}")
    
    # 3. 质量评估
    print(f"\n📊 步骤3: 质量评估")
    print("-" * 40)
    
    if QING_PARSER_AVAILABLE and 'coverage_rate' in summary:
        coverage_rate = summary['coverage_rate']
        consistency = summary['annotation_consistency']
        
        print(f"📈 规则覆盖率: {coverage_rate:.1%}")
        print(f"📈 标注一致性: {consistency:.3f}")
        
        # 质量判断
        if coverage_rate >= 0.95 and consistency >= 0.8:
            print("✅ 知识图谱质量: 优秀")
        elif coverage_rate >= 0.8 and consistency >= 0.7:
            print("⚠️  知识图谱质量: 良好")
        else:
            print("❌ 知识图谱质量: 需要改进")
    else:
        print("⚠️  无法进行质量评估")
    
    # 4. 结果输出
    print(f"\n📁 步骤4: 结果输出")
    print("-" * 40)
    
    # 保存完整处理摘要
    complete_summary = {
        'processing_date': __import__('datetime').datetime.now().isoformat(),
        'input_directory': input_dir,
        'output_directory': output_dir,
        'rtf_files_found': len(rtf_files),
        'rtf_files_processed': processed_count,
        'knowledge_graph_available': QING_PARSER_AVAILABLE,
        'processing_summary': summary if QING_PARSER_AVAILABLE else None
    }
    
    summary_path = os.path.join(output_dir, 'complete_processing_summary.json')
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(complete_summary, f, ensure_ascii=False, indent=2)
    
    print(f"📄 处理摘要: {summary_path}")
    
    if QING_PARSER_AVAILABLE and 'jsonld_file' in summary:
        print(f"🗂️  知识图谱: {summary['jsonld_file']}")
        print(f"📋 评估报告: {os.path.join(output_dir, 'evaluation_report.json')}")
    
    # 5. 完成总结
    print("\n" + "=" * 80)
    print("🎉 处理完成！")
    print("=" * 80)
    
    if QING_PARSER_AVAILABLE:
        print("✅ RTF文件预处理完成")
        print("✅ 知识图谱构建完成")
        print("✅ 质量评估完成")
        print("✅ 结果文件已保存")
        
        # 6. 生成知识图谱可视化
        print(f"\n📊 步骤5: 知识图谱可视化")
        print("-" * 40)
        generate_knowledge_graph_visualization(output_dir)
        
        if summary.get('meets_requirements', False):
            print("\n🏆 恭喜！知识图谱质量满足所有要求")
        else:
            print("\n💡 提示：知识图谱质量可以进一步改进")
    else:
        print("⚠️  仅完成RTF文件预处理")
        print("💡 提示：安装相关依赖后可使用完整功能")
    
    return complete_summary

def main():
    parser = argparse.ArgumentParser(description='金线刺绣知识处理系统 - 一键完成所有功能')
    parser.add_argument('--input_dir', type=str, default='data/知识层1',
                       help='RTF文件输入目录 (默认: data/知识层1)')
    parser.add_argument('--output_dir', type=str, default='output/results/knowledge_complete',
                       help='输出目录 (默认: output/results/knowledge_complete)')
    
    args = parser.parse_args()
    
    # 检查输入目录
    if not os.path.exists(args.input_dir):
        print(f"❌ 错误: 输入目录不存在: {args.input_dir}")
        print("💡 请确保RTF文件目录路径正确")
        return
    
    # 检查是否有RTF文件
    rtf_count = 0
    for root, dirs, files in os.walk(args.input_dir):
        rtf_count += sum(1 for f in files if f.endswith('.rtf'))
    
    if rtf_count == 0:
        print(f"⚠️  警告: 在 {args.input_dir} 中未找到RTF文件")
        print("💡 请确保目录中包含.rtf格式的知识文件")
        return
    
    print(f"📊 发现 {rtf_count} 个RTF文件，开始处理...")
    
    # 执行一键处理
    try:
        summary = process_all_in_one(args.input_dir, args.output_dir)
        
        # 显示快速访问路径
        print(f"\n🔗 快速访问:")
        print(f"   输出目录: {args.output_dir}")
        if summary.get('processing_summary') and 'jsonld_file' in summary['processing_summary']:
            print(f"   知识图谱: {summary['processing_summary']['jsonld_file']}")
        
    except Exception as e:
        print(f"❌ 处理过程中发生错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main() 