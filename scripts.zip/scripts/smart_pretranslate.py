#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import sys
import pandas as pd
import re
from tqdm import tqdm
from datetime import datetime

# 添加项目路径
sys.path.append('src')
from models.translation_service import TranslationServiceFactory

class SmartPreTranslationProcessor:
    """智能预翻译处理器 - 能够修复JSON格式问题并翻译"""
    
    def __init__(self, knowledge_dir="data/知识层1", craft_dir="output/results/craft", 
                 output_dir="data/pretranslated", translation_method="google"):
        self.knowledge_dir = knowledge_dir
        self.craft_dir = craft_dir
        self.output_dir = output_dir
        
        # 初始化翻译服务
        print(f"🔧 初始化翻译服务: {translation_method}")
        try:
            self.translation_service = TranslationServiceFactory.create_service(translation_method)
            print(f"✅ 翻译服务初始化成功: {self.translation_service.method}")
        except Exception as e:
            print(f"⚠️  翻译服务初始化失败，使用词典翻译: {e}")
            self.translation_service = TranslationServiceFactory.create_service("dict")
        
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # 统计信息
        self.stats = {
            "total_files": 0,
            "valid_json": 0,
            "fixed_and_translated": 0,
            "failed_files": 0,
            "translation_method": self.translation_service.method
        }
    
    def smart_fix_json(self, content):
        """智能修复JSON内容"""
        original_content = content
        
        # 1. 基础清理
        content = content.strip()
        
        # 2. 替换中文标点符号
        replacements = {
            '，': ',',  # 中文逗号
            '：': ':',  # 中文冒号
            '"': '"',  # 中文左引号
            '"': '"',  # 中文右引号
            ''': "'",  # 中文单引号
            ''': "'",  # 中文单引号
            '《': '"',  # 书名号左
            '》': '"',  # 书名号右
            '；': ',',  # 分号
        }
        
        for old, new in replacements.items():
            content = content.replace(old, new)
        
        # 3. 修复字段名不一致
        field_fixes = {
            '"姿势"': '"姿态"',
            '"关税类型"': '"边框类型"',
            '"文化标志"': '"文化语义"',
            '"文化标记"': '"文化语义"',
        }
        
        for old, new in field_fixes.items():
            content = re.sub(old, new, content)
        
        # 4. 修复JSON语法问题
        # 移除对象/数组末尾多余的逗号
        content = re.sub(r',(\s*[}\]])', r'\1', content)
        
        # 5. 确保字符串正确引用
        # 修复未引用的键名（如果有的话）
        content = re.sub(r'(\w+)(\s*:)', r'"\1"\2', content)
        
        # 6. 修复特殊情况
        # 处理可能的换行问题
        content = re.sub(r'\n\s*', ' ', content)
        
        # 7. 尝试提取JSON部分（如果有额外内容）
        if not content.startswith('{'):
            json_match = re.search(r'\{.*\}', content, re.DOTALL)
            if json_match:
                content = json_match.group()
        
        return content
    
    def extract_knowledge_with_fix(self, file_path):
        """提取知识数据，自动修复JSON格式问题"""
        if not os.path.exists(file_path):
            return None
        
        # 尝试不同编码
        encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig']
        content = None
        
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    content = f.read().strip()
                break
            except UnicodeDecodeError:
                continue
        
        if not content:
            return None
        
        # 首先尝试直接解析
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            pass
        
        # 如果失败，尝试修复后解析
        try:
            fixed_content = self.smart_fix_json(content)
            return json.loads(fixed_content)
        except json.JSONDecodeError as e:
            # 如果还是失败，记录详细错误信息
            print(f"    ❌ JSON修复失败: {os.path.basename(file_path)} - {e}")
            print(f"       内容预览: {content[:100]}...")
            return None
    
    def process_knowledge_files(self):
        """处理知识层文件"""
        print("🔄 智能处理知识层文件...")
        
        knowledge_output_dir = os.path.join(self.output_dir, "knowledge")
        os.makedirs(knowledge_output_dir, exist_ok=True)
        
        translated_knowledge = {}
        
        # 遍历知识层目录
        for root, dirs, files in os.walk(self.knowledge_dir):
            for file in files:
                if file.endswith('.rtf'):
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, self.knowledge_dir)
                    
                    self.stats["total_files"] += 1
                    
                    # 智能提取知识数据
                    knowledge_data = self.extract_knowledge_with_fix(file_path)
                    
                    if knowledge_data:
                        try:
                            # 翻译知识数据
                            translated_data = self.translation_service.translate_knowledge_data(knowledge_data)
                            
                            # 保存翻译结果
                            category = os.path.dirname(rel_path).replace(os.sep, '_')
                            file_key = f"{category}_{os.path.splitext(file)[0]}"
                            
                            translated_knowledge[file_key] = {
                                "original_path": rel_path,
                                "original_data": knowledge_data,
                                "translated_data": translated_data,
                                "translation_time": datetime.now().isoformat(),
                                "translation_method": self.translation_service.method
                            }
                            
                            self.stats["fixed_and_translated"] += 1
                            print(f"  ✅ 修复并翻译: {rel_path}")
                            
                        except Exception as e:
                            print(f"  ❌ 翻译失败: {rel_path} - {e}")
                            self.stats["failed_files"] += 1
                    else:
                        self.stats["failed_files"] += 1
        
        # 保存翻译结果
        knowledge_output_file = os.path.join(knowledge_output_dir, "translated_knowledge.json")
        with open(knowledge_output_file, 'w', encoding='utf-8') as f:
            json.dump(translated_knowledge, f, indent=2, ensure_ascii=False)
        
        print(f"✅ 知识层智能处理完成，保存到: {knowledge_output_file}")
        print(f"   成功处理: {len(translated_knowledge)} 个文件")
        
        return translated_knowledge
    
    def process_craft_data(self):
        """处理工艺层数据"""
        print("🔄 处理工艺层数据...")
        
        craft_output_dir = os.path.join(self.output_dir, "craft")
        os.makedirs(craft_output_dir, exist_ok=True)
        
        translated_craft = {}
        
        # 处理CSV文件
        craft_csv_path = os.path.join(self.craft_dir, "craft_summary.csv")
        if os.path.exists(craft_csv_path):
            try:
                # 尝试不同编码读取CSV
                encodings = ['gbk', 'gb2312', 'utf-8', 'utf-8-sig']
                df = None
                
                for encoding in encodings:
                    try:
                        df = pd.read_csv(craft_csv_path, encoding=encoding)
                        print(f"  ✅ 使用 {encoding} 编码读取CSV文件")
                        break
                    except UnicodeDecodeError:
                        continue
                
                if df is not None:
                    print(f"  📊 处理工艺CSV文件: {len(df)} 条记录")
                    
                    for index, row in tqdm(df.iterrows(), total=len(df), desc="翻译工艺数据"):
                        sample_id = row['sample_id']
                        stitch_type = row['stitch_type']
                        
                        if isinstance(stitch_type, str) and stitch_type.strip():
                            # 翻译针法类型
                            translated_stitch = self.translation_service.translate(stitch_type)
                            
                            translated_craft[sample_id] = {
                                "original_stitch_type": stitch_type,
                                "translated_stitch_type": translated_stitch,
                                "density": float(row.get('density', 0)) / 1000000,
                                "complexity": float(row.get('complexity', 0.5)),
                                "feasibility": float(row.get('feasibility', 1.0)),
                                "translation_time": datetime.now().isoformat(),
                                "translation_method": self.translation_service.method
                            }
                
            except Exception as e:
                print(f"  ❌ 处理工艺CSV失败: {e}")
        
        # 保存翻译结果
        craft_output_file = os.path.join(craft_output_dir, "translated_craft.json")
        with open(craft_output_file, 'w', encoding='utf-8') as f:
            json.dump(translated_craft, f, indent=2, ensure_ascii=False)
        
        print(f"✅ 工艺层处理完成，保存到: {craft_output_file}")
        print(f"   翻译记录数: {len(translated_craft)}")
        
        return translated_craft
    
    def create_unified_prompts(self, translated_knowledge, translated_craft):
        """创建统一的提示词映射"""
        print("🔄 创建统一提示词映射...")
        
        unified_prompts = {}
        
        for knowledge_key, knowledge_info in tqdm(translated_knowledge.items(), desc="生成提示词"):
            translated_data = knowledge_info["translated_data"]
            
            # 提取类别信息
            category_parts = knowledge_key.split('_')
            if len(category_parts) >= 2:
                category = '_'.join(category_parts[:-1])
            else:
                category = knowledge_key
            
            # 查找对应的工艺数据
            craft_data = None
            for craft_key, craft_info in translated_craft.items():
                if category.replace('_', '') in craft_key or craft_key in category:
                    craft_data = craft_info
                    break
            
            # 生成详细提示词
            prompt_parts = []
            
            # 添加类别（翻译）
            translated_category = self.translation_service.translate(category.replace('_', ' '))
            prompt_parts.append(translated_category)
            
            # 添加翻译后的知识信息
            for key, value in translated_data.items():
                if isinstance(value, dict):
                    for sub_key, sub_value in value.items():
                        if isinstance(sub_value, str) and sub_value.strip():
                            prompt_parts.append(f"{sub_key} {sub_value}")
                elif isinstance(value, str) and value.strip():
                    prompt_parts.append(f"{key} {value}")
            
            # 添加工艺信息
            if craft_data:
                prompt_parts.append(craft_data["translated_stitch_type"])
                
                density = craft_data.get("density", 0.5)
                complexity = craft_data.get("complexity", 0.5)
                
                if density > 0.8:
                    prompt_parts.append("very high density stitching")
                elif density > 0.6:
                    prompt_parts.append("high density stitching")
                else:
                    prompt_parts.append("fine density stitching")
                
                if complexity > 0.8:
                    prompt_parts.append("extremely complex pattern work")
                elif complexity > 0.6:
                    prompt_parts.append("complex pattern work")
                else:
                    prompt_parts.append("elegant pattern work")
            
            # 添加基础描述
            base_terms = [
                "traditional Chinese gold thread embroidery",
                "imperial court rank badge",
                "fine silk threads",
                "intricate needlework",
                "high quality craftsmanship"
            ]
            prompt_parts.extend(base_terms)
            
            # 组合提示词
            full_prompt = ", ".join(prompt_parts)
            if len(full_prompt) > 400:
                full_prompt = full_prompt[:400]
            
            unified_prompts[knowledge_key] = {
                "category": category,
                "detailed_prompt": full_prompt,
                "knowledge_file": knowledge_info["original_path"],
                "craft_data": craft_data,
                "creation_time": datetime.now().isoformat(),
                "translation_method": self.translation_service.method
            }
        
        # 保存统一提示词
        prompts_output_file = os.path.join(self.output_dir, "unified_prompts.json")
        with open(prompts_output_file, 'w', encoding='utf-8') as f:
            json.dump(unified_prompts, f, indent=2, ensure_ascii=False)
        
        print(f"✅ 统一提示词创建完成，保存到: {prompts_output_file}")
        print(f"   提示词数量: {len(unified_prompts)}")
        
        return unified_prompts
    
    def run_smart_translation(self):
        """执行智能预翻译流程"""
        print("🚀 开始智能预翻译流程")
        print("=" * 60)
        print(f"🔧 使用翻译方法: {self.translation_service.method}")
        
        # 1. 智能处理知识层
        translated_knowledge = self.process_knowledge_files()
        
        # 2. 处理工艺层
        translated_craft = self.process_craft_data()
        
        # 3. 创建统一提示词
        unified_prompts = self.create_unified_prompts(translated_knowledge, translated_craft)
        
        # 4. 显示结果
        print(f"\n📊 智能翻译完成统计:")
        print(f"  翻译方法: {self.stats['translation_method']}")
        print(f"  总文件数: {self.stats['total_files']}")
        print(f"  成功处理: {self.stats['fixed_and_translated']}")
        print(f"  处理失败: {self.stats['failed_files']}")
        print(f"  成功率: {self.stats['fixed_and_translated'] / max(self.stats['total_files'], 1) * 100:.1f}%")
        
        print(f"\n📁 输出文件:")
        print(f"  知识层翻译: {self.output_dir}/knowledge/translated_knowledge.json")
        print(f"  工艺层翻译: {self.output_dir}/craft/translated_craft.json")
        print(f"  统一提示词: {self.output_dir}/unified_prompts.json")
        
        print(f"\n✅ 智能预翻译完成！生成了 {len(unified_prompts)} 个统一提示词。")
        
        return unified_prompts

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="智能预翻译知识层和工艺层内容")
    parser.add_argument("--knowledge_dir", type=str, default="data/知识层1")
    parser.add_argument("--craft_dir", type=str, default="output/results/craft")
    parser.add_argument("--output_dir", type=str, default="data/pretranslated")
    parser.add_argument("--translation_method", type=str, default="google",
                       choices=["auto", "baidu", "youdao", "google", "local", "dict"])
    
    args = parser.parse_args()
    
    # 创建智能预翻译处理器
    processor = SmartPreTranslationProcessor(
        knowledge_dir=args.knowledge_dir,
        craft_dir=args.craft_dir,
        output_dir=args.output_dir,
        translation_method=args.translation_method
    )
    
    # 执行智能翻译
    try:
        unified_prompts = processor.run_smart_translation()
        print(f"\n🎉 智能预翻译成功完成！")
    except Exception as e:
        print(f"\n❌ 智能预翻译失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main() 