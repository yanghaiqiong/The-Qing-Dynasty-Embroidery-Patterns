import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from src.data_processing.image_processing import ImageProcessor, compare_multilight_images
import os
import random

def process_all_dirs(root_dir, rel_path, processor):
    abs_path = os.path.join(root_dir, rel_path)
    has_image = any(f.lower().endswith(('.png', '.jpg', '.jpeg')) for f in os.listdir(abs_path))
    if has_image:
        processor.process_image_directory(rel_path)
    for sub in os.listdir(abs_path):
        sub_path = os.path.join(abs_path, sub)
        if os.path.isdir(sub_path):
            process_all_dirs(root_dir, os.path.join(rel_path, sub), processor)

data_dir = 'data/图像层'
output_dir = 'output/results/image_processing'
processor = ImageProcessor(data_dir, output_dir)
for cate in os.listdir(data_dir):
    if not os.path.isdir(os.path.join(data_dir, cate)):
        continue
    process_all_dirs(data_dir, cate, processor)

# 处理完所有图片后自动评估
print("所有图片处理完成，开始评估数据集...")
avg_ssim, avg_delta_e, ssim_values, delta_e_values, resolutions = processor.evaluate_dataset(data_dir, output_dir)
print("评估完成，结果和可视化图表已输出。")

# 自动批量可视化（只抽取5张）
# print("开始批量可视化...")
# compare_candidates = []
# for root, _, files in os.walk(output_dir):
#     for file in files:
#         if file.endswith('_SR.png') or file.endswith('_fused_SR.png'):
#             processed_path = os.path.join(root, file)
#             rel_path = os.path.relpath(root, output_dir)
#             base_name = file.replace('_SR.png', '.png').replace('_fused_SR.png', '.png')
#             original_path = os.path.join(data_dir, rel_path, base_name)
#             if os.path.exists(original_path):
#                 compare_candidates.append((original_path, processed_path, os.path.join(root, file.replace('.png', '_compare.png'))))

# if len(compare_candidates) > 0:
#     for original_path, processed_path, vis_path in random.sample(compare_candidates, min(2, len(compare_candidates))):
#         processor.visualize_comparison(original_path, processed_path, vis_path)

# # 色彩误差分布直方图
# if delta_e_values:
#     processor.plot_delta_e_hist(delta_e_values, os.path.join(output_dir, 'delta_e_hist.png'))
# # 分辨率提升趋势
# if resolutions:
#     processor.plot_resolution_trend(resolutions, os.path.join(output_dir, 'resolution_trend.png'))
# print("全部可视化输出完成。")

# # 可选：如有多光源图片，可自动生成多光源对比图
# # for root, _, files in os.walk(data_dir):
# #     for file in files:
# #         if file.endswith('_diffuse.png'):
# #             base = file.replace('_diffuse.png', '')
# #             paths = {
# #                 '漫射光': os.path.join(root, f'{base}_diffuse.png'),
# #                 '侧光': os.path.join(root, f'{base}_side.png'),
# #                 '偏振光': os.path.join(root, f'{base}_polarized.png'),
# #             }
# #             if all(os.path.exists(p) for p in paths.values()):
# #                 out_path = os.path.join(output_dir, rel_path, f'{base}_multilight_compare.png')
# #                 compare_multilight_images(paths, out_path)
# print("全部可视化输出完成。") 