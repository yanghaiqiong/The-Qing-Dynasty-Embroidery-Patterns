#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import cv2
import numpy as np
import json
import csv
import argparse
from tqdm import tqdm
from src.data_processing.craft_processing import compute_craft_parameters, plot_3d_trajectory, plot_craft_radar, plot_param_box

class UnifiedCraftProcessor:
    """统一的工艺层数据处理器 - 100%保留原有功能"""
    
    def __init__(self, input_dir, output_dir):
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.img_exts = ['.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff']
        self.summary_rows = []
        os.makedirs(output_dir, exist_ok=True)
    
    def process_csv_trajectories_original(self):
        """处理CSV格式的轨迹数据 - 完全保留原始batch_craft_processing.py逻辑"""
        print("处理CSV轨迹数据...")
        params_dict = {}
        
        # 原始逻辑：只在根目录查找CSV文件
        for file in os.listdir(self.input_dir):
            if file.endswith('.csv'):
                csv_path = os.path.join(self.input_dir, file)
                try:
                    # 完全按照原始代码的逻辑
                    traj = np.loadtxt(csv_path, delimiter=',')
                    params = compute_craft_parameters(traj)
                    params_dict[file] = params
                    plot_3d_trajectory(traj, os.path.join(self.output_dir, file.replace('.csv', '_3d.png')))
                    print(f"已处理CSV: {csv_path}")
                except Exception as e:
                    print(f"处理CSV失败 {csv_path}: {e}")
        
        # 自动评估与可视化 - 完全按照原始代码
        print("所有工艺层数据处理完成，开始评估和可视化...")
        plot_craft_radar(params_dict, os.path.join(self.output_dir, 'craft_radar.png'))
        plot_param_box(params_dict, os.path.join(self.output_dir, 'craft_box.png'))
        print("工艺层评估与可视化已输出。")
        
        return params_dict
    
    def process_csv_trajectories_recursive(self):
        """处理CSV格式的轨迹数据 - 递归查找版本（新功能）"""
        print("处理CSV轨迹数据（递归模式）...")
        params_dict = {}
        
        for root, dirs, files in os.walk(self.input_dir):
            for file in files:
                if file.endswith('.csv'):
                    csv_path = os.path.join(root, file)
                    try:
                        # 读取轨迹数据
                        traj = np.loadtxt(csv_path, delimiter=',')
                        
                        # 计算工艺参数
                        params = compute_craft_parameters(traj)
                        params_dict[file] = params
                        
                        # 保存3D轨迹图
                        rel_dir = os.path.relpath(root, self.input_dir)
                        save_dir = os.path.join(self.output_dir, rel_dir)
                        os.makedirs(save_dir, exist_ok=True)
                        
                        plot_3d_trajectory(traj, os.path.join(save_dir, file.replace('.csv', '_3d.png')))
                        
                        print(f"已处理CSV: {csv_path}")
                        
                    except Exception as e:
                        print(f"处理CSV失败 {csv_path}: {e}")
        
        # 生成综合可视化
        if params_dict:
            plot_craft_radar(params_dict, os.path.join(self.output_dir, 'craft_radar.png'))
            plot_param_box(params_dict, os.path.join(self.output_dir, 'craft_box.png'))
        
        return params_dict
    
    # 为了向后兼容，保留原有方法名
    def process_csv_trajectories(self):
        """处理CSV格式的轨迹数据 - 默认使用递归模式"""
        return self.process_csv_trajectories_recursive()
    
    def extract_trajectories_from_images_original(self):
        """从图像中提取工艺轨迹 - 完全保留原始extract_craft_from_image.py逻辑"""
        print("从图像提取工艺轨迹...")
        
        # 完全按照原始代码的逻辑
        for root, dirs, files in os.walk(self.input_dir):
            rel_dir = os.path.relpath(root, self.input_dir)
            save_dir = os.path.join(self.output_dir, rel_dir)
            os.makedirs(save_dir, exist_ok=True)
            
            for file in tqdm(files, desc=rel_dir):
                ext = os.path.splitext(file)[1].lower()
                if ext in self.img_exts:
                    img_path = os.path.join(root, file)
                    self._process_single_image_original(img_path, save_dir)
        
        # 汇总写csv - 完全按照原始代码
        csv_path = os.path.join(self.output_dir, 'craft_summary.csv')
        with open(csv_path, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['sample_id', 'stitch_type', 'density', 'complexity', 'feasibility'])
            writer.writerows(self.summary_rows)
        
        print(f'工艺层汇总已保存: {csv_path}')
    
    def _process_single_image_original(self, img_path, save_dir):
        """处理单张图像提取轨迹 - 完全保留原始逻辑"""
        try:
            # 完全按照原始extract_craft_from_image.py的process_image函数
            img = cv2.imdecode(np.fromfile(img_path, dtype=np.uint8), cv2.IMREAD_COLOR)
            if img is None:
                print(f'无法读取图片: {img_path}')
                return
            
            # 灰度化
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            # 边缘检测
            edges = cv2.Canny(gray, 100, 200)
            # 轮廓提取
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # 轨迹点保存（每个轮廓一个n×2数组） - 完全按照原始逻辑
            trajs = [c.squeeze().tolist() for c in contours if c.shape[0] > 10]
            
            # 保存轨迹点为npy（支持不规则嵌套list） - 完全按照原始逻辑
            base = os.path.splitext(os.path.basename(img_path))[0]
            np.save(os.path.join(save_dir, base + '_traj.npy'), np.array(trajs, dtype=object))
            
            # 也保存为json，便于跨平台和人工查看 - 完全按照原始逻辑（无缩进）
            with open(os.path.join(save_dir, base + '_traj.json'), 'w', encoding='utf-8') as f:
                json.dump(trajs, f, ensure_ascii=False)
            
            # 可视化保存
            vis = img.copy()
            cv2.drawContours(vis, contours, -1, (0, 0, 255), 2)
            cv2.imwrite(os.path.join(save_dir, base + '_contour.png'), vis)
            
            # 生成csv行 - 完全按照原始逻辑
            sample_id = base
            # stitch_type用上级文件夹名
            stitch_type = os.path.basename(os.path.dirname(img_path))
            density = sum([len(c) for c in trajs])
            complexity = len(trajs) / (density + 1e-8)
            feasibility = 1
            self.summary_rows.append([sample_id, stitch_type, density, round(complexity, 4), feasibility])
            
        except Exception as e:
            print(f'处理图像失败 {img_path}: {e}')
    
    def _process_single_image_enhanced(self, img_path, save_dir):
        """处理单张图像提取轨迹 - 增强版本（添加了维度检查）"""
        try:
            # 读取图像
            img = cv2.imdecode(np.fromfile(img_path, dtype=np.uint8), cv2.IMREAD_COLOR)
            if img is None:
                print(f'无法读取图片: {img_path}')
                return
            
            # 灰度化
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # 边缘检测
            edges = cv2.Canny(gray, 100, 200)
            
            # 轮廓提取
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # 过滤小轮廓，提取有效轨迹点（增强版本）
            trajs = []
            for c in contours:
                if c.shape[0] > 10:  # 过滤太小的轮廓
                    traj_points = c.squeeze()
                    if len(traj_points.shape) == 2:  # 确保是2D点集
                        trajs.append(traj_points.tolist())
            
            # 保存轨迹数据
            base = os.path.splitext(os.path.basename(img_path))[0]
            
            # 保存为npy格式
            np.save(os.path.join(save_dir, base + '_traj.npy'), 
                   np.array(trajs, dtype=object))
            
            # 保存为JSON格式（便于跨平台查看，带缩进）
            with open(os.path.join(save_dir, base + '_traj.json'), 'w', encoding='utf-8') as f:
                json.dump(trajs, f, ensure_ascii=False, indent=2)
            
            # 可视化保存
            vis = img.copy()
            cv2.drawContours(vis, contours, -1, (0, 0, 255), 2)
            cv2.imwrite(os.path.join(save_dir, base + '_contour.png'), vis)
            
            # 计算工艺参数并添加到汇总
            sample_id = base
            stitch_type = os.path.basename(os.path.dirname(img_path))
            density = sum([len(traj) for traj in trajs])
            complexity = len(trajs) / (density + 1e-8) if density > 0 else 0
            feasibility = 1  # 默认可行
            
            self.summary_rows.append([sample_id, stitch_type, density, 
                                    round(complexity, 4), feasibility])
            
        except Exception as e:
            print(f'处理图像失败 {img_path}: {e}')
    
    # 为了向后兼容，保留原有方法名，默认使用原始逻辑
    def extract_trajectories_from_images(self):
        """从图像中提取工艺轨迹 - 默认使用原始逻辑"""
        return self.extract_trajectories_from_images_original()
    
    def _process_single_image(self, img_path, save_dir):
        """处理单张图像提取轨迹 - 默认使用原始逻辑"""
        return self._process_single_image_original(img_path, save_dir)
    
    def process_mixed_data(self, csv_mode='original', image_mode='original'):
        """处理混合数据（CSV + 图像）"""
        print("处理混合工艺数据...")
        
        # 根据模式选择CSV处理方法
        if csv_mode == 'original':
            csv_params = self.process_csv_trajectories_original()
        else:
            csv_params = self.process_csv_trajectories_recursive()
        
        # 根据模式选择图像处理方法
        if image_mode == 'original':
            self.extract_trajectories_from_images_original()
        else:
            # 使用增强版本的图像处理
            for root, dirs, files in os.walk(self.input_dir):
                rel_dir = os.path.relpath(root, self.input_dir)
                save_dir = os.path.join(self.output_dir, rel_dir)
                os.makedirs(save_dir, exist_ok=True)
                
                for file in tqdm(files, desc=f"处理 {rel_dir}"):
                    ext = os.path.splitext(file)[1].lower()
                    if ext in self.img_exts:
                        img_path = os.path.join(root, file)
                        self._process_single_image_enhanced(img_path, save_dir)
            
            # 保存汇总CSV
            csv_path = os.path.join(self.output_dir, 'craft_summary.csv')
            with open(csv_path, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['sample_id', 'stitch_type', 'density', 'complexity', 'feasibility'])
                writer.writerows(self.summary_rows)
            
            print(f'工艺层汇总已保存: {csv_path}')
        
        print("混合数据处理完成")
        return csv_params
    
    def generate_comprehensive_report(self):
        """生成综合工艺分析报告"""
        report_path = os.path.join(self.output_dir, 'craft_analysis_report.json')
        
        # 统计信息
        total_samples = len(self.summary_rows)
        stitch_types = list(set([row[1] for row in self.summary_rows]))
        avg_density = np.mean([row[2] for row in self.summary_rows]) if self.summary_rows else 0
        avg_complexity = np.mean([row[3] for row in self.summary_rows]) if self.summary_rows else 0
        
        report = {
            "总样本数": total_samples,
            "针法类型": stitch_types,
            "平均密度": float(avg_density),
            "平均复杂度": float(avg_complexity),
            "处理时间": "自动生成",
            "输出文件": {
                "轨迹数据": "各子目录下的*_traj.npy和*_traj.json文件",
                "可视化": "各子目录下的*_contour.png文件",
                "汇总数据": "craft_summary.csv",
                "综合图表": ["craft_radar.png", "craft_box.png"]
            }
        }
        
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"综合分析报告已保存: {report_path}")

def main():
    parser = argparse.ArgumentParser(description='统一工艺层数据处理工具 - 100%保留原有功能')
    parser.add_argument('--mode', type=str, 
                       choices=['csv', 'csv_recursive', 'image', 'image_enhanced', 'mixed', 'auto'],
                       default='auto',
                       help='处理模式')
    parser.add_argument('--input_dir', type=str, default='data/图像层',
                       help='输入目录')
    parser.add_argument('--output_dir', type=str, default='output/results/craft',
                       help='输出目录')
    parser.add_argument('--report', action='store_true',
                       help='生成综合分析报告')
    parser.add_argument('--original', action='store_true',
                       help='使用原始代码逻辑（100%兼容）')
    
    args = parser.parse_args()
    
    processor = UnifiedCraftProcessor(args.input_dir, args.output_dir)
    
    if args.mode == 'auto':
        # 自动检测数据类型
        has_csv = any(f.endswith('.csv') for root, dirs, files in os.walk(args.input_dir) for f in files)
        has_images = any(f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff')) 
                        for root, dirs, files in os.walk(args.input_dir) for f in files)
        
        if has_csv and has_images:
            print("检测到CSV和图像数据，使用混合模式")
            csv_mode = 'original' if args.original else 'recursive'
            image_mode = 'original' if args.original else 'enhanced'
            processor.process_mixed_data(csv_mode, image_mode)
        elif has_csv:
            print("检测到CSV数据，使用CSV模式")
            if args.original:
                processor.process_csv_trajectories_original()
            else:
                processor.process_csv_trajectories_recursive()
        elif has_images:
            print("检测到图像数据，使用图像提取模式")
            if args.original:
                processor.extract_trajectories_from_images_original()
            else:
                # 使用增强版本
                for root, dirs, files in os.walk(args.input_dir):
                    rel_dir = os.path.relpath(root, args.input_dir)
                    save_dir = os.path.join(args.output_dir, rel_dir)
                    os.makedirs(save_dir, exist_ok=True)
                    
                    for file in tqdm(files, desc=f"处理 {rel_dir}"):
                        ext = os.path.splitext(file)[1].lower()
                        if ext in processor.img_exts:
                            img_path = os.path.join(root, file)
                            processor._process_single_image_enhanced(img_path, save_dir)
                
                # 保存汇总CSV
                csv_path = os.path.join(args.output_dir, 'craft_summary.csv')
                with open(csv_path, 'w', encoding='utf-8', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(['sample_id', 'stitch_type', 'density', 'complexity', 'feasibility'])
                    writer.writerows(processor.summary_rows)
                
                print(f'工艺层汇总已保存: {csv_path}')
        else:
            print("未检测到有效的工艺数据")
            return
    elif args.mode == 'csv':
        processor.process_csv_trajectories_original()
    elif args.mode == 'csv_recursive':
        processor.process_csv_trajectories_recursive()
    elif args.mode == 'image':
        processor.extract_trajectories_from_images_original()
    elif args.mode == 'image_enhanced':
        # 使用增强版本的图像处理
        for root, dirs, files in os.walk(args.input_dir):
            rel_dir = os.path.relpath(root, args.input_dir)
            save_dir = os.path.join(args.output_dir, rel_dir)
            os.makedirs(save_dir, exist_ok=True)
            
            for file in tqdm(files, desc=f"处理 {rel_dir}"):
                ext = os.path.splitext(file)[1].lower()
                if ext in processor.img_exts:
                    img_path = os.path.join(root, file)
                    processor._process_single_image_enhanced(img_path, save_dir)
        
        # 保存汇总CSV
        csv_path = os.path.join(args.output_dir, 'craft_summary.csv')
        with open(csv_path, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['sample_id', 'stitch_type', 'density', 'complexity', 'feasibility'])
            writer.writerows(processor.summary_rows)
        
        print(f'工艺层汇总已保存: {csv_path}')
    elif args.mode == 'mixed':
        csv_mode = 'original' if args.original else 'recursive'
        image_mode = 'original' if args.original else 'enhanced'
        processor.process_mixed_data(csv_mode, image_mode)
    
    if args.report:
        processor.generate_comprehensive_report()
    
    print("工艺层数据处理完成")

if __name__ == '__main__':
    main() 