#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工艺层CSV数据可视化工具
基于craft_summary.csv生成雷达图、箱线图、热力图等
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import argparse
import logging
import json
from datetime import datetime
import re

# 中文字体设置
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei']
plt.rcParams['axes.unicode_minus'] = False

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class CraftCSVVisualizer:
    """工艺层CSV数据可视化器"""
    
    def __init__(self, csv_path, output_dir="output/craft_visualization"):
        """
        初始化可视化器
        
        参数:
            csv_path (str): craft_summary.csv文件路径
            output_dir (str): 输出目录
        """
        self.csv_path = Path(csv_path)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 加载数据
        self.df = self._load_csv_with_encoding(csv_path)
        logger.info(f"加载数据完成: {len(self.df)} 个样本")
        
        # 数据预处理
        self._preprocess_data()
        
    def _load_csv_with_encoding(self, csv_path):
        """尝试多种编码加载CSV文件"""
        encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig', 'latin1']
        
        for encoding in encodings:
            try:
                df = pd.read_csv(csv_path, encoding=encoding)
                logger.info(f"成功使用编码 {encoding} 加载CSV文件")
                return df
            except UnicodeDecodeError:
                logger.debug(f"编码 {encoding} 失败，尝试下一个")
                continue
            except Exception as e:
                logger.debug(f"使用编码 {encoding} 时出现其他错误: {e}")
                continue
        
        # 如果所有编码都失败，抛出错误
        raise ValueError(f"无法使用任何编码读取CSV文件: {csv_path}")
    
    def _preprocess_data(self):
        """数据预处理"""
        # 提取样本类别
        self.df['category'] = self.df['sample_id'].str.extract(r'(清代[^0-9]+)')
        
        # 处理针法类型字符串，统一格式
        self.df['stitch_types_clean'] = self.df['stitch_type'].apply(self._clean_stitch_types)
        
        # 添加主要针法标识
        self.df['has_平针绣'] = self.df['stitch_types_clean'].str.contains('平针绣')
        self.df['has_盘金绣'] = self.df['stitch_types_clean'].str.contains('盘金绣')
        self.df['has_套针绣'] = self.df['stitch_types_clean'].str.contains('套针绣')
        self.df['has_打籽绣'] = self.df['stitch_types_clean'].str.contains('打籽绣')
        
        # 归一化数值特征
        for col in ['density', 'complexity']:
            self.df[f'{col}_normalized'] = (self.df[col] - self.df[col].min()) / (self.df[col].max() - self.df[col].min())
        
        logger.info("数据预处理完成")
        
    def _clean_stitch_types(self, stitch_str):
        """清理针法类型字符串"""
        if pd.isna(stitch_str):
            return ""
        
        # 移除多余字符
        cleaned = re.sub(r'[，,、\s]+', ',', str(stitch_str))
        cleaned = re.sub(r'["""]', '', cleaned)
        cleaned = cleaned.strip(',')
        
        return cleaned
    
    def plot_category_radar(self, save_path=None):
        """
        绘制不同类别的工艺参数雷达图
        
        参数:
            save_path (str): 保存路径，默认为output_dir/category_radar.png
        """
        if save_path is None:
            save_path = self.output_dir / 'category_radar.png'
        
        # 按类别分组计算平均值
        category_stats = self.df.groupby('category').agg({
            'density': 'mean',
            'complexity': 'mean', 
            'feasibility': 'mean'
        }).reset_index()
        
        # 归一化到0-1范围
        for col in ['density', 'complexity', 'feasibility']:
            max_val = category_stats[col].max()
            min_val = category_stats[col].min()
            if max_val > min_val:
                category_stats[f'{col}_norm'] = (category_stats[col] - min_val) / (max_val - min_val)
            else:
                category_stats[f'{col}_norm'] = 0.5
        
        # 设置雷达图参数
        labels = ['Density', 'Complexity', 'Feasibility']
        num_vars = len(labels)
        angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()
        angles += angles[:1]  # 闭合图形
        
        # 创建图表
        fig, ax = plt.subplots(figsize=(10, 8), subplot_kw=dict(projection='polar'))
        
        colors = plt.cm.Set3(np.linspace(0, 1, len(category_stats)))
        
        for i, row in category_stats.iterrows():
            values = [row['density_norm'], row['complexity_norm'], row['feasibility_norm']]
            values += values[:1]  # 闭合图形
            
            # 将中文类别名转为英文
            category_en = self._translate_category_to_english(row['category'])
            ax.plot(angles, values, 'o-', linewidth=2, label=category_en, color=colors[i])
            ax.fill(angles, values, alpha=0.25, color=colors[i])
        
        # 设置坐标轴
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(labels, fontsize=12)
        ax.set_ylim(0, 1)
        ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
        ax.set_yticklabels(['0', '0.25', '0.5', '0.75', '1.0'], fontsize=10)
        ax.grid(True)
        
        # 标题和图例
        plt.title('Craft Parameters Radar Chart by Category', fontsize=16, fontweight='bold', pad=20)
        plt.legend(loc='upper right', bbox_to_anchor=(1.2, 1.0), fontsize=10)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"类别雷达图已保存: {save_path}")
        return save_path
    
    def _translate_category_to_english(self, category):
        """将中文类别名翻译为英文"""
        translation_map = {
            '清代文官官补': 'Qing Civil Official Badges',
            '清代武官官补': 'Qing Military Official Badges', 
            '清代皇族龙补': 'Qing Imperial Dragon Badges',
            '清代獬豸官补': 'Qing Xiezhi Official Badges',
            '清代团花补': 'Qing Floral Pattern Badges'
        }
        return translation_map.get(category, category)
    
    def _translate_stitch_to_english(self, stitch_name):
        """将中文针法名翻译为英文"""
        translation_map = {
            '平针绣': 'Flat Stitch',
            '盘金绣': 'Couching Stitch',
            '套针绣': 'Encroaching Stitch',
            '打籽绣': 'Seed Stitch'
        }
        return translation_map.get(stitch_name, stitch_name)
    
    def plot_stitch_type_radar(self, save_path=None):
        """
        绘制不同针法类型的参数雷达图
        
        参数:
            save_path (str): 保存路径
        """
        if save_path is None:
            save_path = self.output_dir / 'stitch_type_radar.png'
        
        # 按主要针法类型分组
        stitch_groups = {
            'Flat Stitch': self.df[self.df['has_平针绣']],
            'Couching Stitch': self.df[self.df['has_盘金绣']],
            'Encroaching Stitch': self.df[self.df['has_套针绣']],
            'Seed Stitch': self.df[self.df['has_打籽绣']]
        }
        
        # 计算各组平均值
        stitch_stats = {}
        for name, group in stitch_groups.items():
            if len(group) > 0:
                stitch_stats[name] = {
                    'density': group['density'].mean(),
                    'complexity': group['complexity'].mean(),
                    'feasibility': group['feasibility'].mean()
                }
        
        if len(stitch_stats) == 0:
            logger.warning("没有找到有效的针法分组数据")
            return None
        
        # 归一化处理
        all_densities = [stats['density'] for stats in stitch_stats.values()]
        all_complexities = [stats['complexity'] for stats in stitch_stats.values()]
        all_feasibilities = [stats['feasibility'] for stats in stitch_stats.values()]
        
        density_range = (min(all_densities), max(all_densities))
        complexity_range = (min(all_complexities), max(all_complexities))
        feasibility_range = (min(all_feasibilities), max(all_feasibilities))
        
        # 设置雷达图参数
        labels = ['Line Density', 'Curve Complexity', 'Craft Feasibility']
        num_vars = len(labels)
        angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()
        angles += angles[:1]
        
        # 创建图表
        fig, ax = plt.subplots(figsize=(10, 8), subplot_kw=dict(projection='polar'))
        
        colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4']
        
        for i, (name, stats) in enumerate(stitch_stats.items()):
            # 归一化值
            density_norm = (stats['density'] - density_range[0]) / (density_range[1] - density_range[0]) if density_range[1] > density_range[0] else 0.5
            complexity_norm = (stats['complexity'] - complexity_range[0]) / (complexity_range[1] - complexity_range[0]) if complexity_range[1] > complexity_range[0] else 0.5
            feasibility_norm = (stats['feasibility'] - feasibility_range[0]) / (feasibility_range[1] - feasibility_range[0]) if feasibility_range[1] > feasibility_range[0] else 0.5
            
            values = [density_norm, complexity_norm, feasibility_norm]
            values += values[:1]
            
            ax.plot(angles, values, 'o-', linewidth=3, label=name, color=colors[i % len(colors)])
            ax.fill(angles, values, alpha=0.15, color=colors[i % len(colors)])
        
        # 设置坐标轴
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(labels, fontsize=12)
        ax.set_ylim(0, 1)
        ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
        ax.set_yticklabels(['Low', 'Low-Med', 'Medium', 'Med-High', 'High'], fontsize=10)
        ax.grid(True, alpha=0.3)
        
        # 标题和图例
        plt.title('Craft Parameters Comparison by Stitch Type', fontsize=16, fontweight='bold', pad=20)
        plt.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0), fontsize=12)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"针法类型雷达图已保存: {save_path}")
        return save_path
    
    def plot_correlation_heatmap(self, save_path=None):
        """
        绘制工艺参数相关性热力图
        
        参数:
            save_path (str): 保存路径
        """
        if save_path is None:
            save_path = self.output_dir / 'correlation_heatmap.png'
        
        # 计算相关性矩阵
        numeric_cols = ['density', 'complexity', 'feasibility']
        corr_matrix = self.df[numeric_cols].corr()
        
        # 创建热力图
        plt.figure(figsize=(8, 6))
        sns.heatmap(corr_matrix, 
                   annot=True, 
                   cmap='RdYlBu_r', 
                   center=0,
                   square=True,
                   fmt='.3f',
                   cbar_kws={'shrink': 0.8})
        
        plt.title('Craft Parameters Correlation Heatmap', fontsize=14, fontweight='bold')
        plt.xlabel('Craft Parameters', fontsize=12)
        plt.ylabel('Craft Parameters', fontsize=12)
        
        # 设置英文标签
        plt.xticks([0.5, 1.5, 2.5], ['Density', 'Complexity', 'Feasibility'])
        plt.yticks([0.5, 1.5, 2.5], ['Density', 'Complexity', 'Feasibility'])
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"相关性热力图已保存: {save_path}")
        return save_path
    
    def plot_parameter_boxplots(self, save_path=None):
        """
        绘制参数分布箱线图
        
        参数:
            save_path (str): 保存路径
        """
        if save_path is None:
            save_path = self.output_dir / 'parameter_boxplots.png'
        
        # 创建图表
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        
        # 为类别创建英文标签
        category_mapping = {cat: self._translate_category_to_english(cat) for cat in self.df['category'].unique() if pd.notna(cat)}
        df_with_english = self.df.copy()
        df_with_english['category_en'] = df_with_english['category'].map(category_mapping)
        
        # 密度箱线图
        df_with_english.boxplot(column='density', by='category_en', ax=axes[0])
        axes[0].set_title('Density Distribution')
        axes[0].set_xlabel('Category')
        axes[0].set_ylabel('Density Value')
        axes[0].tick_params(axis='x', rotation=45)
        
        # 复杂度箱线图
        df_with_english.boxplot(column='complexity', by='category_en', ax=axes[1])
        axes[1].set_title('Complexity Distribution')
        axes[1].set_xlabel('Category')
        axes[1].set_ylabel('Complexity Value')
        axes[1].tick_params(axis='x', rotation=45)
        
        # 可行性箱线图
        df_with_english.boxplot(column='feasibility', by='category_en', ax=axes[2])
        axes[2].set_title('Feasibility Distribution')
        axes[2].set_xlabel('Category')
        axes[2].set_ylabel('Feasibility Value')
        axes[2].tick_params(axis='x', rotation=45)
        
        plt.suptitle('Craft Parameters Distribution Boxplots', fontsize=16, fontweight='bold')
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"参数箱线图已保存: {save_path}")
        return save_path
    
    def generate_statistics_report(self, save_path=None):
        """
        生成统计报告
        
        参数:
            save_path (str): 保存路径
        """
        if save_path is None:
            save_path = self.output_dir / 'statistics_report.json'
        
        # 基本统计
        basic_stats = {
            'total_samples': len(self.df),
            'categories': self.df['category'].value_counts().to_dict(),
            'parameter_statistics': {
                'density': {
                    'mean': float(self.df['density'].mean()),
                    'std': float(self.df['density'].std()),
                    'min': float(self.df['density'].min()),
                    'max': float(self.df['density'].max())
                },
                'complexity': {
                    'mean': float(self.df['complexity'].mean()),
                    'std': float(self.df['complexity'].std()),
                    'min': float(self.df['complexity'].min()),
                    'max': float(self.df['complexity'].max())
                },
                'feasibility': {
                    'mean': float(self.df['feasibility'].mean()),
                    'std': float(self.df['feasibility'].std()),
                    'min': float(self.df['feasibility'].min()),
                    'max': float(self.df['feasibility'].max())
                }
            }
        }
        
        # 按类别统计
        category_stats = {}
        for category in self.df['category'].unique():
            if pd.notna(category):
                category_data = self.df[self.df['category'] == category]
                category_stats[category] = {
                    'count': len(category_data),
                    'density_mean': float(category_data['density'].mean()),
                    'complexity_mean': float(category_data['complexity'].mean()),
                    'feasibility_mean': float(category_data['feasibility'].mean())
                }
        
        basic_stats['category_statistics'] = category_stats
        
        # 针法类型统计
        stitch_stats = {
            'Flat Stitch samples': int(self.df['has_平针绣'].sum()),
            'Couching Stitch samples': int(self.df['has_盘金绣'].sum()),
            'Encroaching Stitch samples': int(self.df['has_套针绣'].sum()),
            'Seed Stitch samples': int(self.df['has_打籽绣'].sum())
        }
        
        basic_stats['stitch_type_statistics'] = stitch_stats
        basic_stats['generation_time'] = datetime.now().isoformat()
        
        # 保存报告
        with open(save_path, 'w', encoding='utf-8') as f:
            json.dump(basic_stats, f, indent=2, ensure_ascii=False)
        
        logger.info(f"统计报告已保存: {save_path}")
        return basic_stats
    
    def run_full_visualization(self):
        """
        运行完整的可视化流程
        
        返回:
            dict: 生成的文件路径
        """
        logger.info("开始完整可视化流程...")
        
        generated_files = {}
        
        # 1. 类别雷达图
        try:
            generated_files['category_radar'] = self.plot_category_radar()
        except Exception as e:
            logger.error(f"生成类别雷达图失败: {e}")
        
        # 2. 针法类型雷达图  
        try:
            generated_files['stitch_radar'] = self.plot_stitch_type_radar()
        except Exception as e:
            logger.error(f"生成针法雷达图失败: {e}")
        
        # 3. 相关性热力图
        try:
            generated_files['correlation_heatmap'] = self.plot_correlation_heatmap()
        except Exception as e:
            logger.error(f"生成相关性热力图失败: {e}")
        
        # 4. 参数箱线图
        try:
            generated_files['boxplots'] = self.plot_parameter_boxplots()
        except Exception as e:
            logger.error(f"生成箱线图失败: {e}")
        
        # 5. 统计报告
        try:
            stats = self.generate_statistics_report()
            generated_files['statistics'] = self.output_dir / 'statistics_report.json'
        except Exception as e:
            logger.error(f"生成统计报告失败: {e}")
        
        logger.info(f"完整可视化流程完成，生成文件: {len(generated_files)} 个")
        
        # 生成总结报告
        self._generate_summary_report(generated_files)
        
        return generated_files
    
    def _generate_summary_report(self, generated_files):
        """生成Markdown格式的总结报告"""
        report_path = self.output_dir / 'visualization_report.md'
        
        content = f"""# Craft Layer Data Visualization Analysis Report

## 📊 Data Overview
- **Data Source**: {self.csv_path}
- **Total Samples**: {len(self.df)}
- **Number of Categories**: {len(self.df['category'].unique())}
- **Generation Time**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 🎯 Visualization Results

### 1. Category Radar Chart
- **File**: `category_radar.png`
- **Description**: Shows the average performance of different embroidery categories across density, complexity, and feasibility dimensions

### 2. Stitch Type Radar Chart  
- **File**: `stitch_type_radar.png`
- **Description**: Compares craft parameter characteristics across different stitch types (Flat Stitch, Couching Stitch, Encroaching Stitch, Seed Stitch)

### 3. Parameter Correlation Heatmap
- **File**: `correlation_heatmap.png`
- **Description**: Analyzes correlations between density, complexity, and feasibility parameters

### 4. Parameter Distribution Boxplots
- **File**: `parameter_boxplots.png`
- **Description**: Shows distribution and variance of craft parameters across different categories

### 5. Statistical Analysis Report
- **File**: `statistics_report.json`
- **Description**: Detailed numerical statistics including means, standard deviations, min/max values

## 📁 Output Files
"""
        
        for name, path in generated_files.items():
            if path:
                content += f"- `{Path(path).name}`\n"
        
        content += f"""
## 🔍 Key Findings

### Data Distribution Characteristics
- Density Range: {self.df['density'].min():.0f} - {self.df['density'].max():.0f}
- Complexity Range: {self.df['complexity'].min():.4f} - {self.df['complexity'].max():.4f}
- Feasibility: {self.df['feasibility'].value_counts().to_dict()}

### Category Characteristics
"""
        
        for category in self.df['category'].unique():
            if pd.notna(category):
                category_data = self.df[self.df['category'] == category]
                category_en = self._translate_category_to_english(category)
                content += f"- **{category_en}**: {len(category_data)} samples\n"
        
        content += f"""
### Stitch Type Distribution
- Samples with Flat Stitch: {self.df['has_平针绣'].sum()}
- Samples with Couching Stitch: {self.df['has_盘金绣'].sum()}
- Samples with Encroaching Stitch: {self.df['has_套针绣'].sum()}
- Samples with Seed Stitch: {self.df['has_打籽绣'].sum()}

---
*Report generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        logger.info(f"可视化总结报告已保存: {report_path}")


def main():
    parser = argparse.ArgumentParser(description="Craft Layer CSV Data Visualization Tool")
    parser.add_argument("--csv_path", type=str, default="output/results/craft/craft_summary.csv", 
                       help="CSV file path")
    parser.add_argument("--output_dir", type=str, default="output/craft_visualization", 
                       help="Output directory")
    parser.add_argument("--mode", type=str, choices=['all', 'radar', 'heatmap', 'boxplot'], 
                       default='all', help="Generation mode")
    
    args = parser.parse_args()
    
    # 检查CSV文件是否存在
    if not Path(args.csv_path).exists():
        logger.error(f"CSV file does not exist: {args.csv_path}")
        return
    
    # 创建可视化器
    visualizer = CraftCSVVisualizer(args.csv_path, args.output_dir)
    
    # 根据模式运行
    if args.mode == 'all':
        generated_files = visualizer.run_full_visualization()
        logger.info("✅ Full visualization pipeline completed!")
        
        print(f"\n📊 Craft Layer Visualization Completed!")
        print(f"📁 Output Directory: {args.output_dir}")
        print(f"📋 Generated Files: {len(generated_files)}")
        print("\n🎯 Main Visualizations:")
        print("  - Craft parameters radar chart by category")
        print("  - Stitch type comparison radar chart") 
        print("  - Craft parameters correlation heatmap")
        print("  - Parameter distribution boxplots")
        print("  - Detailed statistical analysis report")
        
    elif args.mode == 'radar':
        visualizer.plot_category_radar()
        visualizer.plot_stitch_type_radar()
        logger.info("✅ Radar charts generation completed!")
        
    elif args.mode == 'heatmap':
        visualizer.plot_correlation_heatmap()
        logger.info("✅ Heatmap generation completed!")
        
    elif args.mode == 'boxplot':
        visualizer.plot_parameter_boxplots()
        logger.info("✅ Boxplots generation completed!")


if __name__ == "__main__":
    main() 