#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import sys
import pandas as pd
import re
from tqdm import tqdm
from datetime import datetime

# 添加项目路径
sys.path.append('src')
from models.translation_service import TranslationServiceFactory

class PreTranslationProcessor:
    """预翻译处理器 - 支持断点续传的版本"""
    
    def __init__(self, knowledge_dir="data/知识层1", craft_dir="output/results/craft", 
                 output_dir="data/pretranslated", translation_method="auto", **translation_config):
        self.knowledge_dir = knowledge_dir
        self.craft_dir = craft_dir
        self.output_dir = output_dir
        
        # 初始化翻译服务
        print(f"🔧 初始化翻译服务: {translation_method}")
        try:
            self.translation_service = TranslationServiceFactory.create_service(
                translation_method, **translation_config
            )
            print(f"✅ 翻译服务初始化成功: {self.translation_service.method}")
        except Exception as e:
            print(f"⚠️  翻译服务初始化失败，使用词典翻译: {e}")
            self.translation_service = TranslationServiceFactory.create_service("dict")
        
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # 统计信息
        self.stats = {
            "total_files": 0,
            "already_translated": 0,
            "newly_translated": 0,
            "failed_files": 0,
            "skipped_files": 0,
            "total_terms": 0,
            "translation_method": self.translation_service.method,
            "start_time": datetime.now()
        }
    
    def smart_fix_json(self, content):
        """智能修复JSON内容"""
        # 1. 基础清理
        content = content.strip()
        
        # 2. 处理字符串内部的中文引号问题
        # 这是最关键的修复：将字符串值内部的中文引号转换为英文单引号
        import re
        
        # 找到所有的字符串值（在冒号后面的引号内容）
        def fix_quotes_in_string(match):
            full_match = match.group(0)
            key_part = match.group(1)  # 键名部分
            value_part = match.group(2)  # 值部分
            
            # 将值部分的中文引号替换为英文单引号
            fixed_value = value_part.replace('"', "'").replace('"', "'")
            fixed_value = fixed_value.replace('（', '(').replace('）', ')')
            
            return f'{key_part}"{fixed_value}"'
        
        # 匹配 "键名": "值内容" 的模式
        content = re.sub(r'("[\w\u4e00-\u9fff]+"\s*:\s*)"([^"]*(?:"[^"]*"[^"]*)*)"', fix_quotes_in_string, content)
        
        # 3. 替换其他中文标点符号
        replacements = {
            '，': ',',  # 中文逗号
            '：': ':',  # 中文冒号
            '；': ',',  # 分号
        }
        
        for old, new in replacements.items():
            content = content.replace(old, new)
        
        # 4. 修复字段名不一致
        field_fixes = {
            '"姿势"': '"姿态"',
            '"关税类型"': '"边框类型"',
            '"文化标志"': '"文化语义"',
            '"文化标记"': '"文化语义"',
        }
        
        for old, new in field_fixes.items():
            content = re.sub(old, new, content)
        
        # 5. 修复JSON语法问题
        content = re.sub(r',(\s*[}\]])', r'\1', content)
        content = re.sub(r'\n\s*', ' ', content)
        
        # 6. 尝试提取JSON部分
        if not content.startswith('{'):
            json_match = re.search(r'\{.*\}', content, re.DOTALL)
            if json_match:
                content = json_match.group()
        
        return content
    
    def extract_knowledge_with_fix(self, file_path):
        """提取知识数据，自动修复JSON格式问题"""
        if not os.path.exists(file_path):
            return None
        
        # 尝试不同编码
        encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig']
        content = None
        used_encoding = None
        
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    content = f.read().strip()
                used_encoding = encoding
                break
            except UnicodeDecodeError:
                continue
        
        if not content:
            print(f"    ❌ 无法读取文件内容: {os.path.basename(file_path)}")
            return None
        
        # 首先尝试直接解析
        try:
            data = json.loads(content)
            # 验证数据不为空
            if data and isinstance(data, dict):
                return data
            else:
                print(f"    ❌ JSON为空或格式错误: {os.path.basename(file_path)}")
                return None
        except json.JSONDecodeError as e:
            print(f"    🔧 JSON解析失败，尝试修复: {os.path.basename(file_path)} - {e}")
        
        # 如果失败，尝试修复后解析
        try:
            fixed_content = self.smart_fix_json(content)
            data = json.loads(fixed_content)
            if data and isinstance(data, dict):
                print(f"    ✅ JSON修复成功: {os.path.basename(file_path)}")
                return data
            else:
                print(f"    ❌ 修复后JSON仍为空: {os.path.basename(file_path)}")
                return None
        except json.JSONDecodeError as e:
            print(f"    ❌ JSON修复失败: {os.path.basename(file_path)} - {e}")
            print(f"       使用编码: {used_encoding}")
            print(f"       内容预览: {content[:200]}...")
            return None
    
    def get_translation_status_file(self, category_dir):
        """获取翻译状态文件路径"""
        return os.path.join(category_dir, ".translated.json")
    
    def load_translation_status(self, category_dir):
        """加载翻译状态"""
        status_file = self.get_translation_status_file(category_dir)
        if os.path.exists(status_file):
            try:
                with open(status_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def save_translation_status(self, category_dir, status_data):
        """保存翻译状态"""
        status_file = self.get_translation_status_file(category_dir)
        try:
            with open(status_file, 'w', encoding='utf-8') as f:
                json.dump(status_data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"⚠️  保存翻译状态失败: {e}")
    
    def translate_knowledge_files(self):
        """翻译所有知识层文件 - 支持断点续传，直接翻译整个JSON"""
        print("🔄 开始翻译知识层文件（支持断点续传）...")
        
        knowledge_output_dir = os.path.join(self.output_dir, "knowledge")
        os.makedirs(knowledge_output_dir, exist_ok=True)
        
        all_translated_knowledge = {}
        
        # 遍历知识层目录
        for category_name in os.listdir(self.knowledge_dir):
            category_path = os.path.join(self.knowledge_dir, category_name)
            if not os.path.isdir(category_path):
                continue
            
            print(f"\n📁 处理类别: {category_name}")
            
            # 加载该类别的翻译状态
            translation_status = self.load_translation_status(category_path)
            
            # 获取该类别下的所有RTF文件
            rtf_files = [f for f in os.listdir(category_path) if f.endswith('.rtf')]
            
            category_translated = {}
            status_updated = False
            
            for rtf_file in rtf_files:
                file_path = os.path.join(category_path, rtf_file)
                file_key = os.path.splitext(rtf_file)[0]
                
                self.stats["total_files"] += 1
                
                # 检查是否已经翻译过
                if file_key in translation_status:
                    print(f"  ⏭️  跳过已翻译: {rtf_file}")
                    self.stats["already_translated"] += 1
                    self.stats["skipped_files"] += 1
                    
                    # 加载已有翻译结果
                    category_translated[f"{category_name}_{file_key}"] = translation_status[file_key]
                    continue
                
                try:
                    # 提取知识数据
                    knowledge_data = self.extract_knowledge_with_fix(file_path)
                    
                    if knowledge_data:
                        # 直接翻译整个JSON内容
                        json_text = json.dumps(knowledge_data, ensure_ascii=False, indent=2)
                        
                        # 使用翻译服务翻译整个JSON文本
                        try:
                            translated_json_text = self.translation_service.translate(json_text)
                            
                            # 尝试解析翻译后的JSON
                            try:
                                translated_data = json.loads(translated_json_text)
                            except json.JSONDecodeError:
                                # 如果翻译后的JSON格式有问题，使用修复逻辑
                                fixed_translated_text = self.smart_fix_json(translated_json_text)
                                translated_data = json.loads(fixed_translated_text)
                            
                        except Exception as e:
                            print(f"    ⚠️  整体翻译失败，使用逐字段翻译: {e}")
                            # 如果整体翻译失败，回退到逐字段翻译
                            translated_data = self.translation_service.translate_knowledge_data(knowledge_data)
                        
                        # 构建翻译结果
                        translation_result = {
                            "original_path": os.path.join(category_name, rtf_file),
                            "original_data": knowledge_data,
                            "translated_data": translated_data,
                            "translation_time": datetime.now().isoformat(),
                            "translation_method": self.translation_service.method,
                            "translation_type": "whole_json"  # 标记翻译类型
                        }
                        
                        # 保存到总结果中
                        full_key = f"{category_name}_{file_key}"
                        category_translated[full_key] = translation_result
                        
                        # 更新翻译状态
                        translation_status[file_key] = translation_result
                        status_updated = True
                        
                        self.stats["newly_translated"] += 1
                        print(f"  ✅ 新翻译完成: {rtf_file}")
                        
                        # 每翻译5个文件就保存一次状态
                        if self.stats["newly_translated"] % 5 == 0:
                            self.save_translation_status(category_path, translation_status)
                            print(f"    💾 保存翻译状态 ({self.stats['newly_translated']} 个文件)")
                        
                    else:
                        print(f"  ❌ 无法提取数据: {rtf_file}")
                        self.stats["failed_files"] += 1
                        
                except Exception as e:
                    print(f"  ❌ 翻译失败: {rtf_file} - {e}")
                    self.stats["failed_files"] += 1
            
            # 保存该类别的翻译状态
            if status_updated:
                self.save_translation_status(category_path, translation_status)
                print(f"  💾 保存类别翻译状态: {category_name}")
            
            # 合并到总结果
            all_translated_knowledge.update(category_translated)
        
        # 保存汇总的翻译结果
        knowledge_output_file = os.path.join(knowledge_output_dir, "translated_knowledge.json")
        with open(knowledge_output_file, 'w', encoding='utf-8') as f:
            json.dump(all_translated_knowledge, f, indent=2, ensure_ascii=False)
        
        print(f"\n✅ 知识层翻译完成，保存到: {knowledge_output_file}")
        print(f"   总文件数: {self.stats['total_files']}")
        print(f"   已翻译: {self.stats['already_translated']}")
        print(f"   新翻译: {self.stats['newly_translated']}")
        print(f"   翻译失败: {self.stats['failed_files']}")
        
        return all_translated_knowledge
    
    def translate_craft_data(self):
        """翻译工艺层数据"""
        print("\n🔄 开始翻译工艺层数据...")
        
        craft_output_dir = os.path.join(self.output_dir, "craft")
        os.makedirs(craft_output_dir, exist_ok=True)
        
        # 检查是否已有翻译结果
        craft_output_file = os.path.join(craft_output_dir, "translated_craft.json")
        if os.path.exists(craft_output_file):
            try:
                with open(craft_output_file, 'r', encoding='utf-8') as f:
                    existing_craft = json.load(f)
                print(f"  📋 发现已有工艺翻译: {len(existing_craft)} 条记录")
                
                # 询问是否重新翻译
                print("  ❓ 是否重新翻译工艺数据？(y/n): ", end="")
                response = input().strip().lower()
                if response not in ['y', 'yes', '是']:
                    print("  ⏭️  跳过工艺层翻译，使用已有结果")
                    return existing_craft
            except:
                pass
        
        translated_craft = {}
        
        # 处理CSV文件
        craft_csv_path = os.path.join(self.craft_dir, "craft_summary.csv")
        if os.path.exists(craft_csv_path):
            try:
                # 尝试不同编码
                encodings = ['gbk', 'gb2312', 'utf-8', 'utf-8-sig']
                df = None
                
                for encoding in encodings:
                    try:
                        df = pd.read_csv(craft_csv_path, encoding=encoding)
                        print(f"  ✅ 成功使用 {encoding} 编码读取CSV文件")
                        break
                    except UnicodeDecodeError:
                        continue
                
                if df is None:
                    print(f"  ❌ 无法读取CSV文件，尝试了所有编码")
                    return translated_craft
                
                print(f"  📊 处理工艺CSV文件: {len(df)} 条记录")
                
                for index, row in tqdm(df.iterrows(), total=len(df), desc="翻译工艺数据"):
                    sample_id = row['sample_id']
                    stitch_type = row['stitch_type']
                    
                    # 翻译针法类型
                    if isinstance(stitch_type, str) and stitch_type.strip():
                        # 使用翻译服务翻译针法
                        translated_stitch = self.translation_service.translate(stitch_type)
                        
                        translated_craft[sample_id] = {
                            "original_stitch_type": stitch_type,
                            "translated_stitch_type": translated_stitch,
                            "density": float(row.get('density', 0)) / 1000000,  # 归一化
                            "complexity": float(row.get('complexity', 0.5)),
                            "feasibility": float(row.get('feasibility', 1.0)),
                            "translation_time": datetime.now().isoformat(),
                            "translation_method": self.translation_service.method
                        }
                        
                        self.stats["total_terms"] += 1
                
            except Exception as e:
                print(f"  ❌ 处理工艺CSV失败: {e}")
        
        # 保存翻译结果
        with open(craft_output_file, 'w', encoding='utf-8') as f:
            json.dump(translated_craft, f, indent=2, ensure_ascii=False)
        
        print(f"✅ 工艺层翻译完成，保存到: {craft_output_file}")
        print(f"   翻译记录数: {len(translated_craft)}")
        
        return translated_craft
    
    def create_unified_prompts(self, translated_knowledge, translated_craft):
        """创建统一的提示词映射 - 使用完整翻译后的JSON，改进工艺数据匹配"""
        print("\n🔄 创建统一提示词映射...")
        
        unified_prompts = {}
        
        # 为每个知识文件创建详细提示词
        for knowledge_key, knowledge_info in tqdm(translated_knowledge.items(), desc="生成提示词"):
            translated_data = knowledge_info["translated_data"]
            
            # 提取类别信息
            category_parts = knowledge_key.split('_')
            if len(category_parts) >= 2:
                category = '_'.join(category_parts[:-1])  # 去掉文件名部分
            else:
                category = knowledge_key
            
            # 改进的工艺数据匹配逻辑
            craft_data = None
            
            # 从知识层键名中提取信息
            # 知识层格式: "一品文官 仙鹤_一品文官 仙鹤描述1"
            # 工艺层格式: "一品文官仙鹤1"
            
            # 提取文件编号
            file_number = None
            if '_' in knowledge_key:
                file_part = knowledge_key.split('_')[-1]  # "一品文官 仙鹤描述1"
                number_match = re.search(r'(\d+)$', file_part)
                if number_match:
                    file_number = number_match.group(1)
            
            # 方法1: 精确匹配 - 构建工艺层键名
            if file_number:
                # 从类别名构建工艺层键名
                # "一品文官 仙鹤" -> "一品文官仙鹤1"
                craft_key_candidate = category.replace(' ', '') + file_number
                if craft_key_candidate in translated_craft:
                    craft_data = translated_craft[craft_key_candidate]
                    print(f"  🔗 精确匹配工艺数据: {knowledge_key} -> {craft_key_candidate}")
            
            # 方法2: 如果精确匹配失败，尝试模糊匹配
            if craft_data is None:
                category_clean = category.replace('_', '').replace(' ', '').lower()
                for craft_key, craft_info in translated_craft.items():
                    craft_key_clean = craft_key.replace('_', '').replace(' ', '').lower()
                    # 检查是否包含相同的核心信息
                    if category_clean in craft_key_clean or craft_key_clean in category_clean:
                        craft_data = craft_info
                        print(f"  🔗 模糊匹配工艺数据: {knowledge_key} -> {craft_key}")
                        break
            
            # 方法3: 按品级匹配
            if craft_data is None:
                # 从知识数据中提取品级信息
                grade_mapping = {
                    "一品": "1", "二品": "2", "三品": "3", "四品": "4", "五品": "5",
                    "六品": "6", "七品": "7", "八品": "8", "九品": "9"
                }
                
                for grade_chinese, grade_num in grade_mapping.items():
                    if grade_chinese in category:
                        # 查找包含相同品级的工艺数据
                        for craft_key, craft_info in translated_craft.items():
                            if grade_chinese in craft_key:
                                craft_data = craft_info
                                print(f"  🔗 按品级匹配工艺数据: {knowledge_key} -> {craft_key}")
                                break
                        if craft_data:
                            break
            
            # 方法4: 如果还没匹配到，使用第一个可用的工艺数据作为默认
            if craft_data is None and translated_craft:
                craft_data = list(translated_craft.values())[0]
                print(f"  🔗 使用默认工艺数据: {knowledge_key}")
            
            # 生成详细提示词 - 精选关键词策略，质量优于数量
            prompt_parts = []
            
            # 1. 添加类别（翻译）- 最高优先级
            translated_category = self.translation_service.translate(category.replace('_', ' '))
            prompt_parts.append(translated_category)
            
            # 2. 精选翻译内容 - 提取最重要的描述
            def extract_key_descriptions(data, max_items=3):
                """提取最重要的描述，避免冗余"""
                key_texts = []
                if isinstance(data, dict):
                    # 优先级顺序：文化语义 > 中心纹样 > 其他
                    priority_keys = ['Cultural Semantics', 'cultural semantics', '文化语义', 
                                   'Central Pattern', 'central pattern', '中心纹样',
                                   'Name', 'name', '名称']
                    
                    # 先处理高优先级字段
                    for key in priority_keys:
                        if key in data and isinstance(data[key], str):
                            text = data[key].strip()
                            if text and len(text) > 10:  # 只要有意义的描述
                                # 截取前100字符，避免过长
                                key_texts.append(text[:100])
                                if len(key_texts) >= max_items:
                                    break
                    
                    # 如果还没够，处理其他字段
                    if len(key_texts) < max_items:
                        for key, value in data.items():
                            if key not in priority_keys and isinstance(value, str):
                                text = value.strip()
                                if text and len(text) > 5:
                                    key_texts.append(text[:50])  # 次要内容更短
                                    if len(key_texts) >= max_items:
                                        break
                
                return key_texts
            
            # 提取关键翻译内容（最多3个重要描述）
            key_descriptions = extract_key_descriptions(translated_data, max_items=3)
            
            # 3. 添加工艺信息 - 精选最重要的
            craft_terms = []
            if craft_data:
                # 添加翻译后的针法（简化）
                if craft_data.get("translated_stitch_type"):
                    stitch_type = craft_data["translated_stitch_type"]
                    # 只取前3种针法，避免过长
                    stitches = [s.strip() for s in stitch_type.split(',')[:3]]
                    craft_terms.extend(stitches)
                
                # 根据参数添加1-2个关键描述
                density = craft_data.get("density", 0.5)
                complexity = craft_data.get("complexity", 0.5)
                
                if density > 1.0:
                    craft_terms.append("high density stitching")
                elif density > 0.5:
                    craft_terms.append("medium density stitching")
                
                if complexity > 0.015:
                    craft_terms.append("complex pattern work")
                elif complexity > 0.01:
                    craft_terms.append("intricate design")
            
            # 4. 添加核心基础术语（精选）
            core_terms = [
                "traditional Chinese gold thread embroidery",
                "imperial court rank badge", 
                "fine craftsmanship",
                "detailed needlework"
            ]
            
            # 5. 组合所有部分，控制总量
            all_parts = [translated_category] + key_descriptions + craft_terms + core_terms
            
            # 6. 智能去重和长度控制
            unique_parts = []
            seen_lower = set()
            total_length = 0
            max_total_length = 300  # 控制在约60-70个tokens以内
            
            for part in all_parts:
                if part and isinstance(part, str):
                    # 清理并检查重复
                    cleaned_part = part.replace("'", "").replace('"', '').strip()
                    cleaned_lower = cleaned_part.lower()
                    
                    # 避免重复，控制长度
                    if (cleaned_part and len(cleaned_part) > 2 and 
                        cleaned_lower not in seen_lower and
                        total_length + len(cleaned_part) + 2 < max_total_length):  # +2 for ", "
                        
                        unique_parts.append(cleaned_part)
                        seen_lower.add(cleaned_lower)
                        total_length += len(cleaned_part) + 2
            
            # 7. 生成最终提示词
            full_prompt = ", ".join(unique_parts)
            
            # 确保不超过安全长度（约75 tokens）
            if len(full_prompt) > 350:
                # 在逗号处智能截断
                truncated = full_prompt[:350]
                last_comma = truncated.rfind(',')
                if last_comma > 250:  # 保留大部分内容
                    full_prompt = truncated[:last_comma]
                else:
                    full_prompt = truncated
            
            unified_prompts[knowledge_key] = {
                "category": category,
                "detailed_prompt": full_prompt,
                "knowledge_file": knowledge_info["original_path"],
                "original_data": knowledge_info["original_data"],
                "translated_data": translated_data,
                "craft_data": craft_data,
                "creation_time": datetime.now().isoformat(),
                "translation_method": self.translation_service.method
            }
        
        # 保存统一提示词
        prompts_output_file = os.path.join(self.output_dir, "unified_prompts.json")
        with open(prompts_output_file, 'w', encoding='utf-8') as f:
            json.dump(unified_prompts, f, indent=2, ensure_ascii=False)
        
        print(f"✅ 统一提示词创建完成，保存到: {prompts_output_file}")
        print(f"   提示词数量: {len(unified_prompts)}")
        
        # 统计工艺数据匹配情况
        matched_count = sum(1 for prompt in unified_prompts.values() if prompt["craft_data"] is not None)
        print(f"   工艺数据匹配: {matched_count}/{len(unified_prompts)} ({matched_count/len(unified_prompts)*100:.1f}%)")
        
        return unified_prompts
    
    def generate_translation_report(self):
        """生成翻译报告"""
        end_time = datetime.now()
        duration = end_time - self.stats["start_time"]
        
        report = {
            "translation_summary": {
                "start_time": self.stats["start_time"].isoformat(),
                "end_time": end_time.isoformat(),
                "duration_seconds": duration.total_seconds(),
                "total_files_processed": self.stats["total_files"],
                "already_translated": self.stats["already_translated"],
                "newly_translated": self.stats["newly_translated"],
                "failed_translations": self.stats["failed_files"],
                "skipped_files": self.stats["skipped_files"],
                "total_terms_translated": self.stats["total_terms"],
                "success_rate": (self.stats["newly_translated"] + self.stats["already_translated"]) / max(self.stats["total_files"], 1) * 100,
                "translation_method": self.stats["translation_method"],
                "supports_resume": True
            },
            "output_files": {
                "knowledge_translations": "knowledge/translated_knowledge.json",
                "craft_translations": "craft/translated_craft.json", 
                "unified_prompts": "unified_prompts.json"
            },
            "resume_info": {
                "description": "翻译状态保存在各类别目录下的 .translated.json 文件中",
                "resume_command": "再次运行相同命令即可从中断处继续翻译"
            }
        }
        
        report_file = os.path.join(self.output_dir, "translation_report.json")
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        return report
    
    def run_full_translation(self):
        """执行完整的预翻译流程 - 支持断点续传"""
        print("🚀 开始完整预翻译流程（支持断点续传）")
        print("=" * 60)
        print(f"🔧 使用翻译方法: {self.translation_service.method}")
        
        # 1. 翻译知识层（支持断点续传）
        translated_knowledge = self.translate_knowledge_files()
        
        # 2. 翻译工艺层
        translated_craft = self.translate_craft_data()
        
        # 3. 创建统一提示词
        unified_prompts = self.create_unified_prompts(translated_knowledge, translated_craft)
        
        # 4. 生成报告
        report = self.generate_translation_report()
        
        # 5. 显示结果
        print("\n📊 翻译完成统计:")
        print(f"  翻译方法: {report['translation_summary']['translation_method']}")
        print(f"  总文件数: {report['translation_summary']['total_files_processed']}")
        print(f"  已有翻译: {report['translation_summary']['already_translated']}")
        print(f"  新增翻译: {report['translation_summary']['newly_translated']}")
        print(f"  翻译失败: {report['translation_summary']['failed_translations']}")
        print(f"  翻译术语数: {report['translation_summary']['total_terms_translated']}")
        print(f"  总成功率: {report['translation_summary']['success_rate']:.1f}%")
        print(f"  耗时: {report['translation_summary']['duration_seconds']:.2f} 秒")
        
        print(f"\n📁 输出文件:")
        print(f"  知识层翻译: {self.output_dir}/knowledge/translated_knowledge.json")
        print(f"  工艺层翻译: {self.output_dir}/craft/translated_craft.json")
        print(f"  统一提示词: {self.output_dir}/unified_prompts.json")
        print(f"  翻译报告: {self.output_dir}/translation_report.json")
        
        print(f"\n💡 断点续传说明:")
        print(f"  - 翻译状态保存在各类别目录下的 .translated.json 文件中")
        print(f"  - 如果翻译被中断，再次运行相同命令即可从中断处继续")
        print(f"  - 已翻译的文件会被自动跳过，节省时间")
        
        print(f"\n✅ 预翻译完成！现在可以在训练时直接加载翻译好的内容。")
        
        return unified_prompts

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="预翻译知识层和工艺层内容（支持断点续传）")
    parser.add_argument("--knowledge_dir", type=str, default="data/知识层1", 
                       help="知识层目录路径")
    parser.add_argument("--craft_dir", type=str, default="output/results/craft",
                       help="工艺层目录路径") 
    parser.add_argument("--output_dir", type=str, default="data/pretranslated",
                       help="翻译输出目录")
    parser.add_argument("--translation_method", type=str, default="auto",
                       choices=["auto", "baidu", "youdao", "google", "local", "dict"],
                       help="翻译方法")
    
    # 翻译服务配置参数
    parser.add_argument("--baidu_app_id", type=str, help="百度翻译APP ID")
    parser.add_argument("--baidu_secret_key", type=str, help="百度翻译密钥")
    parser.add_argument("--youdao_app_key", type=str, help="有道翻译APP Key")
    parser.add_argument("--youdao_app_secret", type=str, help="有道翻译APP Secret")
    
    args = parser.parse_args()
    
    # 构建翻译配置
    translation_config = {}
    if args.baidu_app_id and args.baidu_secret_key:
        translation_config.update({
            'baidu_app_id': args.baidu_app_id,
            'baidu_secret_key': args.baidu_secret_key
        })
    if args.youdao_app_key and args.youdao_app_secret:
        translation_config.update({
            'youdao_app_key': args.youdao_app_key,
            'youdao_app_secret': args.youdao_app_secret
        })
    
    # 创建预翻译处理器
    processor = PreTranslationProcessor(
        knowledge_dir=args.knowledge_dir,
        craft_dir=args.craft_dir,
        output_dir=args.output_dir,
        translation_method=args.translation_method,
        **translation_config
    )
    
    # 执行翻译
    try:
        unified_prompts = processor.run_full_translation()
        print(f"\n🎉 预翻译成功完成！生成了 {len(unified_prompts)} 个统一提示词。")
    except KeyboardInterrupt:
        print(f"\n⚠️  翻译被用户中断")
        print(f"💡 翻译进度已保存，下次运行时将从中断处继续")
    except Exception as e:
        print(f"\n❌ 预翻译失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main() 