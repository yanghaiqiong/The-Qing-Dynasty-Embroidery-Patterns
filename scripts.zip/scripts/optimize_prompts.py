#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os
import re
import logging
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class PromptOptimizer:
    """提示词优化器 - 将复杂提示词转换为SDXL友好的简洁版本"""
    
    def __init__(self):
        # SDXL擅长理解的核心术语
        self.sdxl_friendly_terms = {
            # 基础类型
            "补子": "Chinese rank badge",
            "文官": "civil official",
            "武官": "military official",
            "官服": "official robe",
            
            # 等级简化
            "一品": "first rank",
            "二品": "second rank",
            "三品": "third rank",
            "四品": "fourth rank",
            "五品": "fifth rank",
            "六品": "sixth rank",
            "七品": "seventh rank",
            
            # 动物主体
            "仙鹤": "crane",
            "锦鸡": "golden pheasant", 
            "孔雀": "peacock",
            "云雁": "wild goose",
            "白鹇": "silver pheasant",
            "鹭鸶": "egret",
            "鹌鹑": "quail",
            "麒麟": "qilin",
            "狮子": "lion",
            "豹子": "leopard",
            "虎": "tiger",
            "熊": "bear",
            
            # 工艺术语（简化）
            "金线刺绣": "gold embroidery",
            "刺绣": "embroidery", 
            "金线": "gold thread",
            "丝线": "silk thread",
            "针法": "stitching",
            "平绣": "satin stitch",
            "盘金": "couching",
            
            # 质量词
            "精细": "detailed",
            "精美": "elegant", 
            "华丽": "ornate",
            "传统": "traditional",
            "立体": "textured",
            "工艺精湛": "fine craftsmanship"
        }
        
        # 高质量基础模板
        self.base_templates = {
            "crane": "Chinese imperial rank badge, crane bird, traditional gold embroidery, silk fabric, detailed needlework, ornate design, museum quality, fine craftsmanship",
            "pheasant": "Chinese imperial rank badge, golden pheasant bird, traditional gold embroidery, silk fabric, detailed needlework, ornate design, museum quality, fine craftsmanship",
            "peacock": "Chinese imperial rank badge, peacock bird, traditional gold embroidery, silk fabric, detailed needlework, ornate design, museum quality, fine craftsmanship",
            "default": "Chinese imperial rank badge, traditional gold embroidery, silk fabric, detailed needlework, ornate design, museum quality, fine craftsmanship"
        }
        
        # 负面提示词
        self.negative_prompt = "blurry, low quality, distorted, deformed, text, watermark, signature, modern art, cartoon, anime, abstract, bad anatomy"
    
    def extract_key_elements(self, category, original_prompt):
        """从类别和原始提示词中提取关键元素"""
        elements = {
            "rank": None,
            "animal": None, 
            "type": "rank badge"
        }
        
        # 提取等级
        for chinese_rank, english_rank in self.sdxl_friendly_terms.items():
            if chinese_rank in category and "rank" in english_rank:
                elements["rank"] = english_rank
                break
        
        # 提取动物
        for chinese_animal, english_animal in self.sdxl_friendly_terms.items():
            if chinese_animal in category and chinese_animal in ["仙鹤", "锦鸡", "孔雀", "云雁", "白鹇", "鹭鸶", "鹌鹑"]:
                elements["animal"] = english_animal
                break
        
        return elements
    
    def create_optimized_prompt(self, category, original_prompt, knowledge_data=None):
        """创建优化的提示词"""
        # 提取关键元素
        elements = self.extract_key_elements(category, original_prompt)
        
        # 构建提示词组件
        parts = []
        
        # 1. 基础类型
        parts.append("Chinese imperial rank badge")
        
        # 2. 等级（如果有）
        if elements["rank"]:
            parts.append(f"{elements['rank']} official")
        
        # 3. 动物主体
        if elements["animal"]:
            parts.append(f"{elements['animal']} bird")
        
        # 4. 核心工艺
        parts.extend([
            "traditional gold embroidery",
            "silk fabric",
            "detailed needlework",
            "ornate design"
        ])
        
        # 5. 质量增强
        parts.extend([
            "museum quality",
            "fine craftsmanship",
            "imperial court style"
        ])
        
        # 组合并确保长度适中
        optimized_prompt = ", ".join(parts)
        
        # SDXL最佳长度控制
        if len(optimized_prompt) > 160:
            optimized_prompt = optimized_prompt[:160]
        
        return optimized_prompt
    
    def batch_optimize(self, input_file, output_file):
        """批量优化提示词"""
        logger.info(f"开始批量优化提示词: {input_file} -> {output_file}")
        
        # 加载原始数据
        with open(input_file, 'r', encoding='utf-8') as f:
            original_data = json.load(f)
        
        optimized_data = {}
        stats = defaultdict(int)
        
        for key, prompt_info in original_data.items():
            try:
                category = prompt_info.get("category", "")
                original_prompt = prompt_info.get("detailed_prompt", "")
                
                # 创建优化提示词
                optimized_prompt = self.create_optimized_prompt(
                    category, original_prompt, prompt_info.get("translated_data", {})
                )
                
                # 保存优化结果
                optimized_data[key] = {
                    "category": category,
                    "original_prompt": original_prompt,
                    "optimized_prompt": optimized_prompt,
                    "negative_prompt": self.negative_prompt,
                    "translated_data": prompt_info.get("translated_data", {}),
                    "craft_data": prompt_info.get("craft_data", {}),
                    "optimization_applied": True
                }
                
                stats["optimized"] += 1
                
                # 分析动物类型统计
                for animal in ["crane", "pheasant", "peacock", "goose"]:
                    if animal in optimized_prompt:
                        stats[f"animal_{animal}"] += 1
                        break
                
            except Exception as e:
                logger.warning(f"优化失败 {key}: {e}")
                # 保留原始数据
                optimized_data[key] = prompt_info
                optimized_data[key]["optimization_applied"] = False
                stats["failed"] += 1
        
        # 保存优化结果
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(optimized_data, f, indent=2, ensure_ascii=False)
        
        # 输出统计信息
        logger.info("✅ 提示词优化完成")
        logger.info(f"📊 优化统计:")
        logger.info(f"   成功优化: {stats['optimized']} 个")
        logger.info(f"   优化失败: {stats['failed']} 个")
        logger.info(f"   总计: {len(optimized_data)} 个")
        
        # 动物分布统计
        logger.info(f"🦅 动物分布:")
        for key, count in stats.items():
            if key.startswith("animal_"):
                animal_name = key.replace("animal_", "")
                logger.info(f"   {animal_name}: {count} 个")
        
        return optimized_data, stats
    
    def analyze_prompt_quality(self, data):
        """分析提示词质量"""
        logger.info("📈 分析提示词质量...")
        
        quality_metrics = {
            "avg_length": 0,
            "has_animal": 0,
            "has_rank": 0,
            "has_craft_terms": 0,
            "too_long": 0,
            "too_short": 0
        }
        
        total_length = 0
        craft_terms = ["embroidery", "gold", "silk", "needlework", "craftsmanship"]
        
        for key, prompt_info in data.items():
            prompt = prompt_info.get("optimized_prompt", "")
            
            # 长度统计
            length = len(prompt)
            total_length += length
            
            if length > 200:
                quality_metrics["too_long"] += 1
            elif length < 50:
                quality_metrics["too_short"] += 1
            
            # 内容分析
            prompt_lower = prompt.lower()
            
            if any(animal in prompt_lower for animal in ["crane", "pheasant", "peacock", "goose"]):
                quality_metrics["has_animal"] += 1
            
            if "rank" in prompt_lower:
                quality_metrics["has_rank"] += 1
            
            if any(term in prompt_lower for term in craft_terms):
                quality_metrics["has_craft_terms"] += 1
        
        quality_metrics["avg_length"] = total_length / len(data) if data else 0
        
        # 输出质量报告
        logger.info("🎯 质量分析结果:")
        logger.info(f"   平均长度: {quality_metrics['avg_length']:.1f} 字符")
        logger.info(f"   包含动物: {quality_metrics['has_animal']}/{len(data)} ({quality_metrics['has_animal']/len(data)*100:.1f}%)")
        logger.info(f"   包含等级: {quality_metrics['has_rank']}/{len(data)} ({quality_metrics['has_rank']/len(data)*100:.1f}%)")
        logger.info(f"   包含工艺术语: {quality_metrics['has_craft_terms']}/{len(data)} ({quality_metrics['has_craft_terms']/len(data)*100:.1f}%)")
        logger.info(f"   过长提示词: {quality_metrics['too_long']} 个")
        logger.info(f"   过短提示词: {quality_metrics['too_short']} 个")
        
        return quality_metrics
    
    def create_sample_prompts(self, output_file="data/optimized_samples.json"):
        """创建示例优化提示词"""
        logger.info("创建示例优化提示词...")
        
        sample_categories = [
            "一品文官 仙鹤",
            "二品文官 锦鸡", 
            "三品文官 孔雀",
            "四品文官 云雁",
            "五品文官 白鹇",
            "六品文官 鹭鸶",
            "七品文官 鹌鹑"
        ]
        
        samples = {}
        
        for i, category in enumerate(sample_categories):
            key = f"{category}_示例{i+1}"
            
            optimized_prompt = self.create_optimized_prompt(
                category, f"{category}传统刺绣", {}
            )
            
            samples[key] = {
                "category": category,
                "optimized_prompt": optimized_prompt,
                "negative_prompt": self.negative_prompt,
                "quality_score": "high",
                "is_sample": True
            }
        
        # 保存示例
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(samples, f, indent=2, ensure_ascii=False)
        
        logger.info(f"✅ 示例提示词已保存: {output_file}")
        logger.info("📋 示例内容:")
        for key, sample in samples.items():
            logger.info(f"   {sample['category']}: {sample['optimized_prompt'][:60]}...")
        
        return samples

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="提示词优化器")
    parser.add_argument("--input", type=str, default="data/pretranslated/unified_prompts.json",
                       help="输入文件路径")
    parser.add_argument("--output", type=str, default="data/pretranslated/optimized_prompts.json", 
                       help="输出文件路径")
    parser.add_argument("--mode", type=str, choices=["optimize", "analyze", "samples"], 
                       default="optimize", help="运行模式")
    
    args = parser.parse_args()
    
    optimizer = PromptOptimizer()
    
    if args.mode == "optimize":
        if not os.path.exists(args.input):
            logger.error(f"输入文件不存在: {args.input}")
            return
        
        # 批量优化
        optimized_data, stats = optimizer.batch_optimize(args.input, args.output)
        
        # 质量分析
        quality_metrics = optimizer.analyze_prompt_quality(optimized_data)
        
        logger.info("🎯 优化建议:")
        if quality_metrics["avg_length"] > 180:
            logger.info("   - 提示词过长，建议进一步简化")
        if quality_metrics["has_animal"] < len(optimized_data) * 0.8:
            logger.info("   - 部分提示词缺少动物主体，可能影响生成效果")
        if quality_metrics["has_craft_terms"] < len(optimized_data) * 0.9:
            logger.info("   - 建议增加更多工艺术语")
    
    elif args.mode == "analyze":
        if not os.path.exists(args.output):
            logger.error(f"优化文件不存在: {args.output}")
            return
        
        with open(args.output, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        optimizer.analyze_prompt_quality(data)
    
    elif args.mode == "samples":
        optimizer.create_sample_prompts()

if __name__ == "__main__":
    main() 