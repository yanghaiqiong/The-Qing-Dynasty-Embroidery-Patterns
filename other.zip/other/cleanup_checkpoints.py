#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
清理重复的检查点
删除中间步骤的检查点，只保留epoch检查点以节省硬盘空间
"""

import os
import shutil
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_dir_size(path):
    """获取目录大小（MB）"""
    if not os.path.exists(path):
        return 0
    
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(path):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            try:
                total_size += os.path.getsize(filepath)
            except:
                pass
    return total_size / (1024 * 1024)  # 转换为MB

def cleanup_checkpoints(models_dir="output/models"):
    """清理检查点目录"""
    logger.info("开始清理检查点...")
    
    if not os.path.exists(models_dir):
        logger.info("模型目录不存在，无需清理")
        return
    
    total_freed = 0
    
    # 遍历所有模型目录
    for model_name in os.listdir(models_dir):
        model_path = os.path.join(models_dir, model_name)
        if not os.path.isdir(model_path):
            continue
        
        logger.info(f"检查模型目录: {model_name}")
        
        # 获取所有检查点
        checkpoints = []
        for item in os.listdir(model_path):
            if item.startswith("checkpoint-") and os.path.isdir(os.path.join(model_path, item)):
                checkpoints.append(item)
        
        if not checkpoints:
            logger.info(f"  没有找到检查点")
            continue
        
        # 分类检查点
        epoch_checkpoints = []
        step_checkpoints = []
        pipeline_dirs = []
        
        for checkpoint in checkpoints:
            checkpoint_path = os.path.join(model_path, checkpoint)
            
            if "epoch" in checkpoint:
                epoch_checkpoints.append(checkpoint)
            else:
                # 数字检查点（中间步骤）
                try:
                    int(checkpoint.split("checkpoint-")[1])
                    step_checkpoints.append(checkpoint)
                except:
                    pass
            
            # 检查是否有pipeline目录
            pipeline_path = os.path.join(checkpoint_path, "pipeline")
            if os.path.exists(pipeline_path):
                pipeline_dirs.append(pipeline_path)
        
        logger.info(f"  找到 {len(epoch_checkpoints)} 个epoch检查点")
        logger.info(f"  找到 {len(step_checkpoints)} 个中间步骤检查点")
        logger.info(f"  找到 {len(pipeline_dirs)} 个pipeline目录")
        
        # 删除中间步骤检查点
        for checkpoint in step_checkpoints:
            checkpoint_path = os.path.join(model_path, checkpoint)
            size = get_dir_size(checkpoint_path)
            
            logger.info(f"  删除中间检查点: {checkpoint} ({size:.1f} MB)")
            try:
                shutil.rmtree(checkpoint_path)
                total_freed += size
            except Exception as e:
                logger.error(f"    删除失败: {e}")
        
        # 删除pipeline目录
        for pipeline_path in pipeline_dirs:
            size = get_dir_size(pipeline_path)
            
            logger.info(f"  删除pipeline目录: {os.path.basename(os.path.dirname(pipeline_path))}/pipeline ({size:.1f} MB)")
            try:
                shutil.rmtree(pipeline_path)
                total_freed += size
            except Exception as e:
                logger.error(f"    删除失败: {e}")
        
        # 显示保留的检查点
        if epoch_checkpoints:
            logger.info(f"  保留的epoch检查点:")
            for checkpoint in sorted(epoch_checkpoints):
                checkpoint_path = os.path.join(model_path, checkpoint)
                size = get_dir_size(checkpoint_path)
                logger.info(f"    {checkpoint} ({size:.1f} MB)")
    
    logger.info(f"清理完成！释放了 {total_freed:.1f} MB 硬盘空间")

def show_current_usage():
    """显示当前硬盘使用情况"""
    logger.info("当前硬盘使用情况:")
    
    directories = {
        "checkpoints": "checkpoints",
        "训练输出": "output/models",
        "生成结果": "output/results"
    }
    
    total_size = 0
    for name, path in directories.items():
        size = get_dir_size(path)
        total_size += size
        logger.info(f"  {name}: {size:.1f} MB ({path})")
    
    logger.info(f"  总计: {total_size:.1f} MB")

if __name__ == "__main__":
    print("=" * 60)
    print("检查点清理工具")
    print("=" * 60)
    
    # 显示清理前的使用情况
    logger.info("清理前:")
    show_current_usage()
    
    print("\n" + "=" * 60)
    
    # 执行清理
    cleanup_checkpoints()
    
    print("\n" + "=" * 60)
    
    # 显示清理后的使用情况
    logger.info("清理后:")
    show_current_usage()
    
    print("=" * 60)
    print("✅ 清理完成！现在只保留epoch检查点，节省了硬盘空间")
    print("=" * 60) 