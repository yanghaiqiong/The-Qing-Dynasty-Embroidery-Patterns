#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
金线刺绣生成模型对比实验主脚本
SDXL vs DALL-E 3 完整自动化对比实验

使用方法:
1. 基础运行（使用模拟模式）:
   python run_comparison_experiment.py

2. 使用真实DALL-E 3 API:
   python run_comparison_experiment.py --openai_api_key YOUR_API_KEY

3. 自定义配置:
   python run_comparison_experiment.py --config config/my_config.json

4. 指定输出目录:
   python run_comparison_experiment.py --output_dir output/my_experiments
"""

import os
import sys
import argparse
import logging
from datetime import datetime

# 添加项目路径
sys.path.append('src')

def setup_logging():
    """设置日志"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(f'experiment_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
        ]
    )

def check_dependencies():
    """检查依赖项"""
    required_packages = [
        'torch', 'torchvision', 'transformers', 'diffusers',
        'PIL', 'numpy', 'opencv-python', 'scikit-image',
        'matplotlib', 'seaborn', 'pandas', 'scipy', 'tqdm'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print(f"❌ 缺少以下依赖包: {', '.join(missing_packages)}")
        print("请运行: pip install " + " ".join(missing_packages))
        return False
    
    print("✅ 所有依赖包已安装")
    return True

def check_models():
    """检查模型可用性"""
    print("🔍 检查模型可用性...")
    
    # 检查SDXL模型
    sdxl_model_path = "checkpoints/stable-diffusion-xl-base-1.0"
    if os.path.exists(sdxl_model_path):
        print("✅ SDXL模型已就绪")
        sdxl_available = True
    else:
        print("⚠️  SDXL模型未找到，请先运行 setup_local_pipeline.py")
        sdxl_available = False
    
    # 检查DALL-E 3 API
    dalle3_api_key = os.getenv('OPENAI_API_KEY')
    if dalle3_api_key:
        print("✅ DALL-E 3 API密钥已设置")
        dalle3_available = True
    else:
        print("⚠️  DALL-E 3 API密钥未设置，将使用模拟模式")
        dalle3_available = False
    
    return sdxl_available, dalle3_available

def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="金线刺绣生成模型对比实验 - SDXL vs DALL-E 3",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument(
        "--config", 
        type=str, 
        default="config/comparison_config.json",
        help="配置文件路径 (默认: config/comparison_config.json)"
    )
    
    parser.add_argument(
        "--output_dir", 
        type=str, 
        default="output/experiments",
        help="输出目录 (默认: output/experiments)"
    )
    
    parser.add_argument(
        "--openai_api_key", 
        type=str,
        help="OpenAI API密钥 (用于DALL-E 3)"
    )
    
    parser.add_argument(
        "--test_mode", 
        action="store_true",
        help="测试模式 (使用较少的提示词和图像)"
    )
    
    parser.add_argument(
        "--skip_generation", 
        action="store_true",
        help="跳过图像生成，直接评估已有图像"
    )
    
    parser.add_argument(
        "--models", 
        nargs='+', 
        choices=['sdxl', 'dalle3'], 
        default=['sdxl', 'dalle3'],
        help="要测试的模型 (默认: sdxl dalle3)"
    )
    
    args = parser.parse_args()
    
    # 设置日志
    setup_logging()
    logger = logging.getLogger(__name__)
    
    print("🚀 金线刺绣生成模型对比实验")
    print("=" * 60)
    print(f"📅 开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"📁 输出目录: {args.output_dir}")
    print(f"⚙️  配置文件: {args.config}")
    print(f"🤖 测试模型: {', '.join(args.models)}")
    
    # 检查依赖
    if not check_dependencies():
        sys.exit(1)
    
    # 检查模型
    sdxl_available, dalle3_available = check_models()
    
    # 设置API密钥
    if args.openai_api_key:
        os.environ['OPENAI_API_KEY'] = args.openai_api_key
        print("✅ OpenAI API密钥已设置")
    
    # 检查模型可用性
    if 'sdxl' in args.models and not sdxl_available:
        print("❌ SDXL模型不可用，但在测试列表中")
        response = input("是否继续？(y/n): ")
        if response.lower() not in ['y', 'yes', '是']:
            sys.exit(1)
    
    if 'dalle3' in args.models and not dalle3_available:
        print("⚠️  DALL-E 3将使用模拟模式")
    
    try:
        # 导入实验类
        from experiments.automated_comparison import AutomatedComparisonExperiment
        
        # 创建实验
        experiment = AutomatedComparisonExperiment(config_path=args.config)
        
        # 测试模式配置
        if args.test_mode:
            print("🧪 启用测试模式")
            experiment.config["test_prompts"] = experiment.config["test_prompts"][:3]
            experiment.config["generation_params"]["sdxl"]["num_images_per_prompt"] = 1
            experiment.config["generation_params"]["dalle3"]["num_images_per_prompt"] = 1
        
        # 运行实验
        print("\n🎯 开始运行对比实验...")
        report = experiment.run_full_experiment()
        
        # 显示结果
        print("\n" + "=" * 60)
        print("🎉 实验完成！")
        print(f"📊 最佳模型: {report['summary']['best_performing_model']}")
        print(f"📈 显著差异指标: {len(report['summary']['significant_differences'])} 个")
        print(f"📁 结果目录: {experiment.output_dir}")
        
        # 显示关键结果
        print("\n📋 关键结果:")
        for metric, results in report['detailed_results']['statistical_analysis'].items():
            sdxl_mean = results['sdxl_mean']
            dalle3_mean = results['dalle3_mean']
            significant = "✓" if results['significant'] else "✗"
            winner = "SDXL" if sdxl_mean > dalle3_mean else "DALL-E 3"
            print(f"  {metric}: {winner} ({significant})")
        
        # 显示文件路径
        print(f"\n📝 详细报告: {os.path.join(experiment.dirs['reports'], 'experiment_report.md')}")
        print(f"📊 可视化图表: {experiment.dirs['visualizations']}")
        print(f"📈 统计分析: {os.path.join(experiment.dirs['evaluation'], 'statistical_analysis.json')}")
        
        # 建议
        print(f"\n💡 建议:")
        for recommendation in report['recommendations']:
            print(f"  • {recommendation}")
        
        return 0
        
    except KeyboardInterrupt:
        print("\n⚠️  实验被用户中断")
        return 1
        
    except Exception as e:
        logger.error(f"❌ 实验失败: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code) 