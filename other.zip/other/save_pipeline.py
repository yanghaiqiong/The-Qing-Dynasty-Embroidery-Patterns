#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
手动保存完整pipeline到检查点
"""

import sys
import os
import torch
sys.path.append('src/models')

from advanced_gold_thread_trainer import AdvancedGoldThreadTrainer
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def save_pipeline_to_checkpoint():
    """手动保存pipeline到最新检查点"""
    
    # 初始化训练器
    trainer = AdvancedGoldThreadTrainer(config_path="config/advanced_config_safe.json")
    
    # 初始化模型（训练模式）
    trainer.initialize_models(for_generation=False)
    
    # 加载最新检查点的权重
    if not trainer.load_latest_checkpoint(for_generation=False):
        logger.error("无法加载检查点")
        return False
    
    # 找到最新检查点目录
    output_dir = trainer.config["output_dir"]
    checkpoints = []
    for item in os.listdir(output_dir):
        if item.startswith("checkpoint-") and os.path.isdir(os.path.join(output_dir, item)):
            checkpoints.append(item)
    
    if not checkpoints:
        logger.error("未找到检查点")
        return False
    
    # 排序获取最新的
    def sort_key(checkpoint):
        if "epoch-" in checkpoint:
            try:
                return (1, int(checkpoint.split("epoch-")[1]))
            except:
                return (0, 0)
        elif "checkpoint-" in checkpoint:
            try:
                return (0, int(checkpoint.split("checkpoint-")[1]))
            except:
                return (0, 0)
        return (0, 0)
    
    latest_checkpoint = sorted(checkpoints, key=sort_key)[-1]
    checkpoint_path = os.path.join(output_dir, latest_checkpoint)
    
    logger.info(f"保存pipeline到检查点: {latest_checkpoint}")
    
    try:
        # 保存完整pipeline
        pipeline_dir = os.path.join(checkpoint_path, "pipeline")
        trainer.pipeline.save_pretrained(pipeline_dir)
        logger.info(f"完整pipeline已保存到: {pipeline_dir}")
        return True
        
    except Exception as e:
        logger.error(f"保存pipeline失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    logger.info("开始保存完整pipeline...")
    
    if save_pipeline_to_checkpoint():
        logger.info("Pipeline保存成功！现在可以使用生成模式了")
    else:
        logger.error("Pipeline保存失败") 