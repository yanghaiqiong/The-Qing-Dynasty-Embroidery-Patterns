#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import re
import shutil
from datetime import datetime

def fix_rtf_json_format():
    """修复RTF文件中的JSON格式问题"""
    print("🔧 修复RTF文件JSON格式问题")
    print("=" * 60)
    
    knowledge_dir = "data/知识层1"
    backup_dir = "data/知识层1_backup"
    
    # 创建备份
    if not os.path.exists(backup_dir):
        print("📦 创建备份...")
        shutil.copytree(knowledge_dir, backup_dir)
        print(f"✅ 备份完成: {backup_dir}")
    
    stats = {
        "total_files": 0,
        "fixed_files": 0,
        "already_valid": 0,
        "failed_fixes": 0
    }
    
    fixed_files = []
    failed_files = []
    
    # 遍历所有RTF文件
    for root, dirs, files in os.walk(knowledge_dir):
        for file in files:
            if file.endswith('.rtf'):
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, knowledge_dir)
                stats["total_files"] += 1
                
                try:
                    # 读取原始内容
                    with open(file_path, 'r', encoding='utf-8') as f:
                        original_content = f.read().strip()
                    
                    if not original_content:
                        continue
                    
                    # 尝试直接解析
                    try:
                        json.loads(original_content)
                        stats["already_valid"] += 1
                        continue
                    except json.JSONDecodeError:
                        pass
                    
                    # 修复JSON格式
                    fixed_content = fix_json_content(original_content)
                    
                    # 验证修复后的内容
                    try:
                        json.loads(fixed_content)
                        
                        # 写回文件
                        with open(file_path, 'w', encoding='utf-8') as f:
                            f.write(fixed_content)
                        
                        stats["fixed_files"] += 1
                        fixed_files.append(rel_path)
                        print(f"✅ 修复: {rel_path}")
                        
                    except json.JSONDecodeError as e:
                        stats["failed_fixes"] += 1
                        failed_files.append((rel_path, str(e)))
                        print(f"❌ 修复失败: {rel_path} - {e}")
                        
                except Exception as e:
                    stats["failed_fixes"] += 1
                    failed_files.append((rel_path, str(e)))
                    print(f"❌ 处理失败: {rel_path} - {e}")
    
    # 显示统计结果
    print(f"\n📊 修复结果统计:")
    print(f"  总文件数: {stats['total_files']}")
    print(f"  已有效: {stats['already_valid']}")
    print(f"  成功修复: {stats['fixed_files']}")
    print(f"  修复失败: {stats['failed_fixes']}")
    print(f"  修复率: {stats['fixed_files'] / max(stats['total_files'] - stats['already_valid'], 1) * 100:.1f}%")
    
    # 保存修复报告
    report = {
        "timestamp": datetime.now().isoformat(),
        "statistics": stats,
        "fixed_files": fixed_files,
        "failed_files": failed_files
    }
    
    with open("rtf_fix_report.json", 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 修复报告已保存: rtf_fix_report.json")
    return stats

def fix_json_content(content):
    """修复JSON内容的格式问题"""
    
    # 1. 替换中文标点符号
    content = content.replace('，', ',')  # 中文逗号 -> 英文逗号
    content = content.replace('：', ':')  # 中文冒号 -> 英文冒号
    content = content.replace('"', '"')  # 中文左引号 -> 英文引号
    content = content.replace('"', '"')  # 中文右引号 -> 英文引号
    content = content.replace(''', "'")  # 中文单引号
    content = content.replace(''', "'")  # 中文单引号
    
    # 2. 修复特殊字符问题
    content = content.replace('《', '"')  # 《 -> "
    content = content.replace('》', '"')  # 》 -> "
    
    # 3. 修复字段名不一致问题
    content = re.sub(r'"姿势"', '"姿态"', content)  # 统一使用"姿态"
    content = re.sub(r'"关税类型"', '"边框类型"', content)  # 修复错误字段名
    content = re.sub(r'"文化标志"', '"文化语义"', content)  # 修复错误字段名
    
    # 4. 修复多余的逗号和分号
    content = re.sub(r',\s*}', '}', content)  # 移除对象末尾的逗号
    content = re.sub(r',\s*]', ']', content)  # 移除数组末尾的逗号
    content = content.replace('；', ',')  # 分号 -> 逗号
    
    # 5. 修复引号问题
    # 确保所有字符串都用双引号包围
    content = re.sub(r"'([^']*)'", r'"\1"', content)
    
    # 6. 修复特殊情况
    content = re.sub(r'}\s*，\s*{', '}, {', content)  # 修复对象间的中文逗号
    
    # 7. 清理多余的空白字符
    content = re.sub(r'\s+', ' ', content)  # 多个空格 -> 单个空格
    content = content.strip()
    
    # 8. 确保JSON格式正确
    # 如果不是以{开头，尝试找到JSON部分
    if not content.startswith('{'):
        json_match = re.search(r'\{.*\}', content, re.DOTALL)
        if json_match:
            content = json_match.group()
    
    return content

def test_fix_examples():
    """测试修复示例"""
    print("\n🧪 测试修复示例:")
    
    test_cases = [
        # 中文标点符号
        '{"品级": "一品"，"名称": "仙鹤"}',
        
        # 字段名不一致
        '{"品级": "一品", "中心纹样": {"姿势": "回首望日"}}',
        
        # 特殊字符
        '{"品级": "一品", "中心纹样": {"《姿势》": "回首望日"}}',
        
        # 错误字段名
        '{"品级": "一品", "关税类型": "万字纹"}',
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n  测试 {i}:")
        print(f"    原始: {test_case}")
        
        fixed = fix_json_content(test_case)
        print(f"    修复: {fixed}")
        
        try:
            json.loads(fixed)
            print(f"    结果: ✅ 有效JSON")
        except json.JSONDecodeError as e:
            print(f"    结果: ❌ 仍有错误 - {e}")

if __name__ == "__main__":
    # 先测试修复示例
    test_fix_examples()
    
    # 询问是否继续修复
    print(f"\n⚠️  即将修复所有RTF文件，是否继续？(y/n): ", end="")
    response = input().strip().lower()
    
    if response in ['y', 'yes', '是']:
        fix_rtf_json_format()
    else:
        print("❌ 取消修复操作") 