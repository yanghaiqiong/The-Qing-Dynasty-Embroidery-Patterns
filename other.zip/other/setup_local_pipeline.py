#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
设置本地pipeline - 从现有pipeline文件夹复制
"""

import os
import shutil
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def setup_local_pipeline():
    """从现有pipeline文件夹复制到checkpoints目录"""
    
    # 源pipeline目录（从图中看到的）
    source_pipeline = "output/models/advanced/checkpoint-epoch-5/pipeline"
    
    # 目标checkpoints目录
    checkpoints_dir = "checkpoints"
    target_pipeline = os.path.join(checkpoints_dir, "stable-diffusion-xl-base-1.0")
    
    if os.path.exists(target_pipeline):
        logger.info(f"Pipeline已存在: {target_pipeline}")
        return target_pipeline
    
    # 检查源pipeline是否存在
    if not os.path.exists(source_pipeline):
        logger.error(f"源pipeline不存在: {source_pipeline}")
        logger.info("可用的检查点:")
        
        # 查找其他可能的pipeline位置
        advanced_dir = "output/models/advanced"
        if os.path.exists(advanced_dir):
            for item in os.listdir(advanced_dir):
                checkpoint_path = os.path.join(advanced_dir, item)
                pipeline_path = os.path.join(checkpoint_path, "pipeline")
                if os.path.exists(pipeline_path):
                    logger.info(f"  - {pipeline_path}")
                    source_pipeline = pipeline_path
                    break
        
        if not os.path.exists(source_pipeline):
            logger.error("未找到任何pipeline文件夹")
            return None
    
    os.makedirs(checkpoints_dir, exist_ok=True)
    
    logger.info(f"从 {source_pipeline} 复制pipeline到 {target_pipeline}")
    logger.info("这是一次性操作，复制后将供所有功能使用")
    
    try:
        # 复制整个pipeline目录
        shutil.copytree(source_pipeline, target_pipeline)
        
        logger.info("✅ Pipeline复制完成！")
        logger.info(f"📁 保存位置: {os.path.abspath(target_pipeline)}")
        logger.info("🚀 现在所有功能都将使用本地pipeline，无需重复下载")
        
        return target_pipeline
        
    except Exception as e:
        logger.error(f"复制pipeline失败: {e}")
        import traceback
        traceback.print_exc()
        return None

def check_local_pipeline():
    """检查本地pipeline是否存在"""
    pipeline_dir = "checkpoints/stable-diffusion-xl-base-1.0"
    
    if os.path.exists(pipeline_dir):
        # 检查关键文件
        required_files = [
            "model_index.json",
            "unet/config.json",
            "vae/config.json",
            "text_encoder/config.json",
            "text_encoder_2/config.json"
        ]
        
        missing_files = []
        for file in required_files:
            if not os.path.exists(os.path.join(pipeline_dir, file)):
                missing_files.append(file)
        
        if missing_files:
            logger.warning(f"Pipeline不完整，缺少文件: {missing_files}")
            return False
        else:
            logger.info(f"✅ 本地pipeline完整: {pipeline_dir}")
            return True
    else:
        logger.info("❌ 本地pipeline不存在")
        return False

if __name__ == "__main__":
    logger.info("=== Stable Diffusion XL Pipeline 本地设置 ===")
    
    # 检查是否已存在
    if check_local_pipeline():
        logger.info("本地pipeline已准备就绪，无需重新下载")
    else:
        logger.info("开始设置本地pipeline...")
        result = setup_local_pipeline()
        
        if result:
            logger.info("🎉 设置成功！现在可以使用训练和生成功能了")
        else:
            logger.error("❌ 设置失败，请检查网络连接和磁盘空间") 