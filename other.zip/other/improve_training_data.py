#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
改进训练数据和配置
"""

import json
import os
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_improved_config():
    """创建改进的训练配置"""
    
    improved_config = {
        "model_id": "checkpoints/stable-diffusion-xl-base-1.0",
        "learning_rate": 5e-5,  # 降低学习率
        "batch_size": 1,
        "num_epochs": 3,  # 减少epoch避免过拟合
        "save_steps": 50,
        "gradient_accumulation_steps": 8,
        "image_size": 512,
        "feature_dim": 512,
        "output_dir": "output/models/improved",
        "max_samples": 100,  # 增加样本数量
        "use_mixed_precision": False,
        "early_stopping": True,  # 添加早停
        "loss_weights": {
            "mse": 0.8,  # 降低MSE权重
            "lpips": 0.5,  # 增加感知损失权重
            "feature": 0.3,  # 增加特征损失权重
            "consistency": 0.2
        },
        "generation_settings": {
            "num_inference_steps": 50,  # 增加推理步数
            "guidance_scale": 8.0,  # 增加引导强度
            "negative_prompt": "low quality, blurry, distorted, modern style, digital art, painting, drawing"
        }
    }
    
    # 保存改进配置
    os.makedirs("config", exist_ok=True)
    with open("config/improved_config.json", 'w', encoding='utf-8') as f:
        json.dump(improved_config, f, indent=2, ensure_ascii=False)
    
    logger.info("✅ 改进配置已保存: config/improved_config.json")
    return improved_config

def create_enhanced_prompts():
    """创建增强的提示词数据库"""
    
    enhanced_prompts = {
        "base_prompts": [
            "traditional Chinese gold thread embroidery",
            "imperial court embroidery art",
            "ancient Chinese silk embroidery",
            "luxury gold wire needlework"
        ],
        "subject_prompts": [
            "crane bird with spread wings",
            "elegant flying crane",
            "imperial crane motif",
            "traditional crane pattern"
        ],
        "technique_prompts": [
            "metallic gold threads on silk",
            "intricate hand-stitched details",
            "shimmering gold wire work",
            "fine needlework craftsmanship"
        ],
        "style_prompts": [
            "museum quality textile art",
            "royal court embroidery style",
            "traditional Chinese handicraft",
            "imperial dynasty artwork"
        ],
        "negative_prompts": [
            "low quality, blurry, distorted",
            "modern style, digital art",
            "painting, drawing, illustration",
            "machine made, printed, fake"
        ]
    }
    
    # 保存提示词数据库
    with open("config/enhanced_prompts.json", 'w', encoding='utf-8') as f:
        json.dump(enhanced_prompts, f, indent=2, ensure_ascii=False)
    
    logger.info("✅ 增强提示词已保存: config/enhanced_prompts.json")
    return enhanced_prompts

if __name__ == "__main__":
    logger.info("=== 创建改进的训练配置 ===")
    
    # 创建改进配置
    config = create_improved_config()
    
    # 创建增强提示词
    prompts = create_enhanced_prompts()
    
    logger.info("\n📋 改进要点:")
    logger.info("1. 降低学习率避免过拟合")
    logger.info("2. 减少训练轮数到3个epoch")
    logger.info("3. 增加感知损失权重")
    logger.info("4. 增加推理步数提高质量")
    logger.info("5. 添加详细的负面提示词")
    
    logger.info("\n🚀 使用方法:")
    logger.info("python src/models/advanced_gold_thread_trainer.py --mode train --config config/improved_config.json") 