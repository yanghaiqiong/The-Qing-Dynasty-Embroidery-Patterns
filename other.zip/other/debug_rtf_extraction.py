#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import sys

def debug_rtf_extraction():
    """调试RTF文件提取问题"""
    print("🔍 调试RTF文件提取问题")
    print("=" * 60)
    
    knowledge_dir = "data/知识层1"
    
    # 统计信息
    stats = {
        "total_files": 0,
        "valid_json": 0,
        "empty_files": 0,
        "encoding_errors": 0,
        "json_errors": 0,
        "other_errors": 0
    }
    
    failed_files = []
    
    # 遍历所有RTF文件
    for root, dirs, files in os.walk(knowledge_dir):
        for file in files:
            if file.endswith('.rtf'):
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, knowledge_dir)
                stats["total_files"] += 1
                
                try:
                    # 尝试读取文件
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read().strip()
                    
                    if not content:
                        stats["empty_files"] += 1
                        failed_files.append((rel_path, "空文件"))
                        continue
                    
                    # 尝试解析JSON
                    try:
                        knowledge_data = json.loads(content)
                        if knowledge_data:  # 非空字典
                            stats["valid_json"] += 1
                        else:
                            stats["empty_files"] += 1
                            failed_files.append((rel_path, "空JSON对象"))
                    except json.JSONDecodeError as e:
                        stats["json_errors"] += 1
                        failed_files.append((rel_path, f"JSON解析错误: {e}"))
                        
                        # 显示文件内容前100字符用于调试
                        print(f"\n❌ JSON解析失败: {rel_path}")
                        print(f"   内容预览: {content[:100]}...")
                        
                except UnicodeDecodeError as e:
                    stats["encoding_errors"] += 1
                    failed_files.append((rel_path, f"编码错误: {e}"))
                    
                    # 尝试其他编码
                    for encoding in ['gbk', 'gb2312', 'latin1']:
                        try:
                            with open(file_path, 'r', encoding=encoding) as f:
                                content = f.read().strip()
                            print(f"⚠️  编码问题: {rel_path} - 可用编码: {encoding}")
                            break
                        except:
                            continue
                    
                except Exception as e:
                    stats["other_errors"] += 1
                    failed_files.append((rel_path, f"其他错误: {e}"))
    
    # 显示统计结果
    print(f"\n📊 RTF文件分析结果:")
    print(f"  总文件数: {stats['total_files']}")
    print(f"  有效JSON: {stats['valid_json']}")
    print(f"  空文件: {stats['empty_files']}")
    print(f"  编码错误: {stats['encoding_errors']}")
    print(f"  JSON错误: {stats['json_errors']}")
    print(f"  其他错误: {stats['other_errors']}")
    print(f"  成功率: {stats['valid_json'] / max(stats['total_files'], 1) * 100:.1f}%")
    
    # 显示失败文件详情
    if failed_files:
        print(f"\n❌ 失败文件详情 (前10个):")
        for i, (file_path, reason) in enumerate(failed_files[:10]):
            print(f"  {i+1}. {file_path}")
            print(f"     原因: {reason}")
    
    # 检查具体的问题文件
    problem_files = [
        "五品文官 白鹇/五品文官 白鹇描述1.rtf",
        "五品文官 白鹇/五品文官 白鹇描述10.rtf",
        "二品武官 狮子/二品武官 狮子描述1.rtf"
    ]
    
    print(f"\n🔍 检查具体问题文件:")
    for problem_file in problem_files:
        file_path = os.path.join(knowledge_dir, problem_file)
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                
                print(f"\n📄 {problem_file}:")
                print(f"   文件大小: {len(content)} 字符")
                print(f"   内容预览: {content[:200]}...")
                
                # 尝试解析JSON
                try:
                    data = json.loads(content)
                    print(f"   ✅ JSON解析成功，键: {list(data.keys())}")
                except json.JSONDecodeError as e:
                    print(f"   ❌ JSON解析失败: {e}")
                    
            except Exception as e:
                print(f"   ❌ 读取失败: {e}")
        else:
            print(f"   ⚠️  文件不存在: {problem_file}")

if __name__ == "__main__":
    debug_rtf_extraction() 