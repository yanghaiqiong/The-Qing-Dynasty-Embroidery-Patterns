#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import shutil
import logging
from pathlib import Path

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_dir_size(path):
    """获取目录大小（MB）"""
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(path):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            if os.path.exists(filepath):
                total_size += os.path.getsize(filepath)
    return total_size / (1024 * 1024)  # 转换为MB

def cleanup_models_directory():
    """清理models目录，删除不必要的大文件"""
    
    models_dir = Path("output/models")
    if not models_dir.exists():
        logger.error("models目录不存在")
        return
    
    total_freed = 0
    
    # 1. 删除早期的大型完整模型检查点
    large_checkpoints_to_delete = [
        "checkpoint-0",
        "checkpoint-10", 
        "epoch-1",
        "epoch-2", 
        "epoch-3",
        "epoch-4",
        "checkpoint-20"
    ]
    
    logger.info("=== 删除早期大型检查点 ===")
    for checkpoint in large_checkpoints_to_delete:
        checkpoint_path = models_dir / checkpoint
        if checkpoint_path.exists():
            size_mb = get_dir_size(checkpoint_path)
            try:
                shutil.rmtree(checkpoint_path)
                total_freed += size_mb
                logger.info(f"已删除 {checkpoint}/ - 释放空间: {size_mb:.1f}MB")
            except Exception as e:
                logger.error(f"删除 {checkpoint} 失败: {e}")
    
    # 2. 删除中间的step检查点，只保留最新的几个
    logger.info("\n=== 清理中间step检查点 ===")
    
    # 获取所有checkpoint-数字目录
    step_checkpoints = []
    for item in models_dir.iterdir():
        if item.is_dir() and item.name.startswith("checkpoint-"):
            try:
                step_num = int(item.name.split("-")[1])
                step_checkpoints.append((step_num, item))
            except ValueError:
                continue
    
    # 按step数排序
    step_checkpoints.sort(key=lambda x: x[0])
    
    # 保留最新的5个step检查点，删除其他的
    if len(step_checkpoints) > 5:
        to_delete = step_checkpoints[:-5]  # 除了最后5个，其他都删除
        
        for step_num, checkpoint_path in to_delete:
            if checkpoint_path.exists():
                size_mb = get_dir_size(checkpoint_path)
                try:
                    shutil.rmtree(checkpoint_path)
                    total_freed += size_mb
                    logger.info(f"已删除 {checkpoint_path.name}/ - 释放空间: {size_mb:.1f}MB")
                except Exception as e:
                    logger.error(f"删除 {checkpoint_path.name} 失败: {e}")
    
    # 3. 删除空目录
    logger.info("\n=== 清理空目录 ===")
    for item in models_dir.iterdir():
        if item.is_dir():
            try:
                # 检查是否为空目录
                if not any(item.iterdir()):
                    item.rmdir()
                    logger.info(f"已删除空目录: {item.name}/")
            except Exception as e:
                logger.debug(f"处理目录 {item.name} 时出错: {e}")
    
    # 4. 显示清理结果
    logger.info(f"\n=== 清理完成 ===")
    logger.info(f"总共释放空间: {total_freed:.1f}MB ({total_freed/1024:.1f}GB)")
    
    # 5. 显示保留的文件
    logger.info("\n=== 保留的文件 ===")
    remaining_items = []
    for item in models_dir.iterdir():
        if item.is_dir():
            size_mb = get_dir_size(item)
            remaining_items.append((item.name, size_mb))
        elif item.is_file():
            size_mb = item.stat().st_size / (1024 * 1024)
            remaining_items.append((item.name, size_mb))
    
    # 按大小排序显示
    remaining_items.sort(key=lambda x: x[1], reverse=True)
    for name, size_mb in remaining_items:
        if size_mb > 0.01:  # 只显示大于10KB的文件
            logger.info(f"保留: {name} - {size_mb:.2f}MB")
    
    total_remaining = sum(size for _, size in remaining_items)
    logger.info(f"\n剩余总大小: {total_remaining:.1f}MB ({total_remaining/1024:.1f}GB)")

def show_cleanup_preview():
    """显示清理预览，不实际删除文件"""
    
    models_dir = Path("output/models")
    if not models_dir.exists():
        logger.error("models目录不存在")
        return
    
    logger.info("=== 清理预览（不会实际删除文件） ===")
    
    # 计算将要删除的文件大小
    large_checkpoints_to_delete = [
        "checkpoint-0", "checkpoint-10", "epoch-1", "epoch-2", 
        "epoch-3", "epoch-4", "checkpoint-20"
    ]
    
    total_to_delete = 0
    
    logger.info("\n将要删除的大型检查点:")
    for checkpoint in large_checkpoints_to_delete:
        checkpoint_path = models_dir / checkpoint
        if checkpoint_path.exists():
            size_mb = get_dir_size(checkpoint_path)
            total_to_delete += size_mb
            logger.info(f"  {checkpoint}/ - {size_mb:.1f}MB")
    
    # 计算中间step检查点
    step_checkpoints = []
    for item in models_dir.iterdir():
        if item.is_dir() and item.name.startswith("checkpoint-"):
            try:
                step_num = int(item.name.split("-")[1])
                step_checkpoints.append((step_num, item))
            except ValueError:
                continue
    
    step_checkpoints.sort(key=lambda x: x[0])
    
    if len(step_checkpoints) > 5:
        to_delete = step_checkpoints[:-5]
        logger.info(f"\n将要删除的中间step检查点 (保留最新5个):")
        for step_num, checkpoint_path in to_delete:
            size_mb = get_dir_size(checkpoint_path)
            total_to_delete += size_mb
            logger.info(f"  {checkpoint_path.name}/ - {size_mb:.1f}MB")
    
    logger.info(f"\n预计释放空间: {total_to_delete:.1f}MB ({total_to_delete/1024:.1f}GB)")
    
    # 显示将要保留的文件
    logger.info(f"\n将要保留的重要文件:")
    keep_patterns = ["epoch-10", "epoch-9", "epoch-8", "training_stats.json", "training_loss.png"]
    for pattern in keep_patterns:
        item_path = models_dir / pattern
        if item_path.exists():
            if item_path.is_dir():
                size_mb = get_dir_size(item_path)
            else:
                size_mb = item_path.stat().st_size / (1024 * 1024)
            logger.info(f"  {pattern} - {size_mb:.2f}MB")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--preview":
        show_cleanup_preview()
    elif len(sys.argv) > 1 and sys.argv[1] == "--execute":
        print("确认要执行清理吗？这将永久删除文件！(y/N): ", end="")
        confirm = input().strip().lower()
        if confirm in ['y', 'yes']:
            cleanup_models_directory()
        else:
            print("清理已取消")
    else:
        print("使用方法:")
        print("  python cleanup_models.py --preview   # 预览将要删除的文件")
        print("  python cleanup_models.py --execute   # 执行清理操作") 