# 金线刺绣CPU训练指南

## 概述

这是一个专门为CPU环境优化的金线刺绣生成模型训练脚本。针对内存限制和CPU性能进行了大量优化，可以在普通PC上稳定运行。

## 主要优化特性

### 内存优化
- **小批次训练**: batch_size=1，最小化内存占用
- **图像尺寸缩减**: 256x256像素，相比512x512减少75%内存
- **梯度检查点**: 启用gradient_checkpointing节省内存
- **内存清理**: 定期执行垃圾回收和内存清理
- **延迟加载**: 模型组件按需加载

### 训练优化
- **参数选择性训练**: 只训练UNet的最后几层，减少计算量
- **梯度累积**: 通过gradient_accumulation_steps=8补偿小批次
- **简化文本编码**: 使用较短的序列长度和简化的编码流程
- **频繁保存**: 每10步保存检查点，防止训练中断丢失进度

### 系统优化
- **CPU线程限制**: 限制为2个线程避免过载
- **禁用CUDA**: 完全使用CPU，避免GPU相关开销
- **内存监控**: 实时监控系统内存使用情况

## 系统要求

### 最低配置
- **内存**: 4GB可用RAM（推荐8GB+）
- **CPU**: 4核心处理器（推荐8核心+）
- **存储**: 10GB可用空间
- **Python**: 3.8+

### 推荐配置
- **内存**: 16GB+ RAM
- **CPU**: 8核心+ 处理器
- **存储**: 20GB+ SSD
- **Python**: 3.10

## 快速开始

### 1. 环境准备

```bash
# 安装依赖
pip install -r requirements.txt

# 检查数据目录
# 确保 data/图像层 目录存在且包含训练图像
```

### 2. 运行训练

#### Windows用户
```cmd
# 双击运行批处理文件
run_cpu_training.bat

# 或在命令行中运行
python run_cpu_training.py
```

#### Linux/Mac用户
```bash
python run_cpu_training.py
```

#### 直接使用训练脚本
```bash
python src/models/model_trainer.py \
    --mode train \
    --config config/default_config.json \
    --data_dir "data/图像层" \
    --output_dir "output/results" \
    --image_size 256 \
    --batch_size 1
```

## 配置参数说明

### 关键参数
- `max_samples`: 最大训练样本数（默认None使用全部数据，可根据内存调整）
- `image_size`: 图像尺寸（默认256，不建议超过512）
- `batch_size`: 批次大小（默认1，CPU模式建议保持1）
- `num_epochs`: 训练轮数（默认5）
- `save_steps`: 保存间隔（默认10步）

### 内存相关参数
```json
{
    "batch_size": 1,
    "image_size": 256,
    "gradient_accumulation_steps": 8,
    "gradient_checkpointing": true,
    "mixed_precision": "no"
}
```

## 训练监控

### 实时监控
训练过程中会显示：
- 当前epoch和步数
- 实时损失值
- 内存使用情况
- 预计剩余时间

### 输出文件
训练完成后会生成：
- `output/results/training_loss.png`: 损失曲线图
- `output/results/training_stats.json`: 训练统计信息
- `output/results/epoch-X/`: 各epoch的检查点
- `cpu_training.log`: 详细训练日志

## 故障排除

### 内存不足
```
错误: 系统内存不足
解决: 
1. 关闭其他程序释放内存
2. 设置max_samples参数限制样本数（如--max_samples 10）
3. 降低image_size到128
```

### 训练中断
```
解决:
1. 检查cpu_training.log日志
2. 从最新检查点恢复训练
3. 调整参数重新开始
```

### 模型加载失败
```
错误: 模型权重不匹配
解决:
1. 清理HuggingFace缓存
2. 重新下载模型
3. 检查网络连接
```

## 性能优化建议

### 硬件优化
1. **关闭不必要程序**: 释放更多内存
2. **使用SSD**: 提高数据加载速度
3. **充足散热**: 避免CPU降频

### 软件优化
1. **调整虚拟内存**: 设置足够的页面文件
2. **关闭杀毒软件实时扫描**: 减少CPU占用
3. **使用性能模式**: Windows电源管理设置为高性能

## 预期训练时间

基于不同配置的预期训练时间：

| 配置 | 样本数 | 预计时间 |
|------|--------|----------|
| 4核8GB | 10-20 | 1-2小时 |
| 8核16GB | 50-100 | 3-6小时 |
| 16核32GB | 全部数据 | 根据数据量而定 |

## 注意事项

1. **首次运行**: 需要下载模型权重，可能需要较长时间
2. **网络要求**: 需要稳定的网络连接下载模型
3. **磁盘空间**: 模型和检查点会占用较多空间
4. **训练效果**: CPU训练的效果可能不如GPU训练
5. **中断恢复**: 支持从检查点恢复训练

## 技术支持

如遇到问题，请检查：
1. `cpu_training.log` 日志文件
2. 系统资源使用情况
3. Python环境和依赖版本

---

*本指南针对CPU环境优化，如有GPU可用，建议使用GPU版本以获得更好的训练效果。* 