import numpy as np
import matplotlib.pyplot as plt
import torch
import logging
from sklearn.metrics import confusion_matrix
import seaborn as sns

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def plot_clip_score_distribution(scores, output_path):
    """
    CLIP语义相似度得分分布箱线图
    """
    plt.figure(figsize=(8, 6))
    plt.boxplot(scores)
    plt.ylabel('CLIP语义相似度')
    plt.title('CLIP得分分布')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"CLIP得分分布箱线图已保存: {output_path}")

def plot_symbol_confusion_matrix(y_true, y_pred, labels, output_path):
    """
    符号识别准确率混淆矩阵热力图
    """
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='YlOrRd', xticklabels=labels, yticklabels=labels)
    plt.xlabel('预测')
    plt.ylabel('真实')
    plt.title('符号识别混淆矩阵')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"混淆矩阵热力图已保存: {output_path}") 