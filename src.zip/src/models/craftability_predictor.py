import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_curve, auc
from skimage.filters import laplace
from skimage.measure import find_contours
from scipy.fft import fft
import logging

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def extract_craft_features(image):
    """
    提取工艺可行性特征：线距密度、曲线复杂度、色彩渐变平滑度
    参数:
        image (np.ndarray): 输入图像
    返回:
        np.ndarray: 特征向量
    """
    # 线距密度（假设为二值化后线条数/面积）
    gray = image if image.ndim == 2 else np.mean(image, axis=2)
    edges = (gray > gray.mean()).astype(np.uint8)
    line_density = np.sum(edges) / edges.size
    # 曲线复杂度（傅里叶描述子）
    contours = find_contours(edges, 0.5)
    if contours:
        contour = max(contours, key=len)
        fd = np.abs(fft(contour[:, 0]))
        curve_complexity = np.mean(fd[1:10])
    else:
        curve_complexity = 0
    # 色彩渐变平滑度（Laplacian方差）
    lap_var = np.var(laplace(gray))
    return np.array([line_density, curve_complexity, lap_var])

def train_craftability_predictor(X, y):
    """
    训练工艺可行性逻辑回归模型
    参数:
        X (np.ndarray): 特征
        y (np.ndarray): 标签
    返回:
        model, coef
    """
    model = LogisticRegression()
    model.fit(X, y)
    return model, model.coef_[0]

def plot_feature_importance(coef, feature_names, output_path):
    """
    特征重要性条形图
    """
    plt.figure(figsize=(8, 6))
    plt.bar(feature_names, coef, color='teal')
    plt.ylabel('权重')
    plt.title('工艺可行性特征重要性')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"特征重要性图已保存: {output_path}")

def plot_roc_curve(model, X, y, output_path):
    """
    ROC曲线
    """
    y_score = model.predict_proba(X)[:, 1]
    fpr, tpr, _ = roc_curve(y, y_score)
    roc_auc = auc(fpr, tpr)
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC曲线 (AUC = {roc_auc:.2f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlabel('假阳性率')
    plt.ylabel('真正率')
    plt.title('工艺可行性预测ROC曲线')
    plt.legend(loc='lower right')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"ROC曲线已保存: {output_path}") 