import os
import torch
import numpy as np
from PIL import Image
import logging
import argparse
from tqdm import tqdm
import matplotlib.pyplot as plt
import json
import gc
from diffusion_model import GoldThreadDiffusionModel
from lora_adapter import DualChannelLoRAAdapter
from shape_grammar import ShapeGrammarController
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
from diffusers import StableDiffusionXLPipeline
from accelerate import Accelerator
import torch.nn.functional as F
import torchvision.transforms as T

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class GoldThreadDataset(Dataset):
    """金线刺绣数据集 - 内存优化版本"""
    
    def __init__(self, data_dir, transform=None, max_samples=None, image_size=256):
        """
        初始化数据集
        
        参数:
            data_dir (str): 数据目录
            transform (callable, optional): 数据转换函数
            max_samples (int, optional): 最大样本数，None表示使用所有样本
            image_size (int): 图像尺寸，默认256以节省内存
        """
        self.data_dir = data_dir
        self.transform = transform
        self.image_size = image_size
        self.samples = []
        
        # 遍历数据目录
        for root, _, files in os.walk(data_dir):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    # 获取相对路径作为标签
                    rel_path = os.path.relpath(root, data_dir)
                    label = rel_path.replace(os.sep, '_')
                    
                    self.samples.append({
                        'image_path': os.path.join(root, file),
                        'label': label
                    })
        
        # 限制样本数量
        if max_samples is not None and max_samples > 0:
            if max_samples < len(self.samples):
                logger.info(f"限制样本数量: {len(self.samples)} -> {max_samples}")
                self.samples = self.samples[:max_samples]
        
        logger.info(f"数据集加载完成，共 {len(self.samples)} 个样本，图像尺寸: {self.image_size}x{self.image_size}")
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        try:
            # 使用更小的图像尺寸以节省内存
            image = Image.open(sample['image_path']).convert('RGB')
            target_size = (self.image_size, self.image_size)
            image = image.resize(target_size, Image.BICUBIC)
            
            if self.transform:
                image = self.transform(image)
            
            # 保证输出为Tensor
            if not isinstance(image, torch.Tensor):
                image = T.ToTensor()(image)
            
            return {
                'image': image,
                'label': sample['label']
            }
        except Exception as e:
            logger.warning(f"加载图像失败 {sample['image_path']}: {e}")
            # 返回一个默认的黑色图像
            default_image = torch.zeros(3, self.image_size, self.image_size)
            return {
                'image': default_image,
                'label': sample['label']
            }

class GoldThreadModelTrainer:
    """金线刺绣生成模型训练器 - CPU优化版本"""
    
    def __init__(self, config_path=None):
        """
        初始化训练器
        
        参数:
            config_path (str, optional): 配置文件路径
        """
        # 设置内存优化
        torch.backends.cudnn.enabled = False
        torch.set_num_threads(2)  # 限制CPU线程数
        
        # 完全禁用CUDA，强制使用CPU
        os.environ['CUDA_VISIBLE_DEVICES'] = ''
        
        # 强制PyTorch使用CPU
        torch.cuda.is_available = lambda: False
        
        # 加载配置
        self.config = self.load_config(config_path)
        
        # 设置设备
        self.device = torch.device("cpu")
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 微软雅黑
        plt.rcParams['axes.unicode_minus'] = False
        
        # 延迟初始化模型以节省内存
        self.base_model = None
        self.lora_adapter = None
        self.shape_controller = None
        self.accelerator = None
        
        logger.info("训练器初始化完成，使用CPU模式")
    
    def load_config(self, config_path):
        """
        加载配置文件
        
        参数:
            config_path (str): 配置文件路径
            
        返回:
            dict: 配置字典
        """
        # CPU优化的默认配置
        default_config = {
            "model_id": "stabilityai/stable-diffusion-xl-base-1.0",
            "learning_rate": 1e-5,
            "batch_size": 1,  # CPU模式下使用最小batch_size
            "num_epochs": 5,  # 减少epoch数
            "save_steps": 10,  # 更频繁保存
            "gradient_accumulation_steps": 8,  # 增加梯度累积以补偿小batch_size
            "semantic_rank": 8,  # 减小LoRA rank
            "texture_rank": 4,
            "lora_alpha": 16,
            "output_dir": "output/models",
            "max_samples": None,  # 默认使用全部数据
            "image_size": 256,  # 使用更小的图像尺寸
            "mixed_precision": "no",
            "gradient_checkpointing": True
        }
        
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                # 强制覆盖一些CPU优化设置
                config["batch_size"] = min(config.get("batch_size", 1), 1)
                config["image_size"] = min(config.get("image_size", 256), 256)
                config["mixed_precision"] = "no"
                default_config.update(config)
        
        return default_config
    
    def initialize_models(self):
        """初始化模型组件 - 延迟加载"""
        if self.base_model is not None:
            return
            
        logger.info("初始化模型组件...")
        
        try:
            # 初始化基础扩散模型
            self.base_model = GoldThreadDiffusionModel(
                model_id=self.config["model_id"],
                device=self.device
            )
            
            # 确保加载pipeline
            self.base_model.load_pipeline()
            
            # 强制所有模型组件使用float32，避免类型不匹配
            if hasattr(self.base_model, 'unet') and self.base_model.unet is not None:
                self.base_model.unet = self.base_model.unet.float()
                self.base_model.unet.enable_gradient_checkpointing()
            
            if hasattr(self.base_model, 'vae') and self.base_model.vae is not None:
                self.base_model.vae = self.base_model.vae.float()
            
            if hasattr(self.base_model, 'text_encoder') and self.base_model.text_encoder is not None:
                self.base_model.text_encoder = self.base_model.text_encoder.float()
            
            if hasattr(self.base_model, 'text_encoder_2') and self.base_model.text_encoder_2 is not None:
                self.base_model.text_encoder_2 = self.base_model.text_encoder_2.float()
            
            # 初始化加速器 - 确保不使用混合精度
            self.accelerator = Accelerator(
                gradient_accumulation_steps=self.config["gradient_accumulation_steps"],
                mixed_precision="no",
                cpu=True  # 强制使用CPU模式
            )
            
            logger.info("模型组件初始化完成")
            
        except Exception as e:
            logger.error(f"模型初始化失败: {e}")
            raise
    
    def clear_memory(self):
        """清理内存"""
        try:
            # 强制垃圾回收
            gc.collect()
            
            # 清理PyTorch缓存
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            
            # 清理CPU张量缓存
            if hasattr(torch.backends, 'mkl') and torch.backends.mkl.is_available():
                torch.backends.mkl.empty_cache()
                
        except Exception as e:
            logger.debug(f"内存清理时出现警告: {e}")
    
    def prepare_dataset(self, data_dir):
        """
        准备训练数据集
        
        参数:
            data_dir (str): 数据目录
            
        返回:
            DataLoader: 数据加载器
        """
        # 创建数据集
        dataset = GoldThreadDataset(
            data_dir,
            transform=None,
            max_samples=self.config.get("max_samples", None),
            image_size=self.config.get("image_size", 256)
        )
        
        # 创建数据加载器
        dataloader = DataLoader(
            dataset,
            batch_size=self.config["batch_size"],
            shuffle=True,
            num_workers=0,  # CPU模式下使用0个worker
            pin_memory=False,  # 禁用pin_memory以节省内存
            drop_last=True  # 丢弃最后一个不完整的batch
        )
        
        return dataloader
    
    def train(self, data_dir):
        """
        训练模型 - CPU优化版本
        
        参数:
            data_dir (str): 训练数据目录
        """
        logger.info("开始CPU训练过程...")
        
        # 初始化模型
        self.initialize_models()
        
        # 准备数据加载器
        train_dataloader = self.prepare_dataset(data_dir)
        
        if len(train_dataloader) == 0:
            logger.error("数据加载器为空，请检查数据目录")
            return
        
        # 简化训练：只训练UNet的一小部分参数
        trainable_params = []
        param_count = 0
        
        # 只训练UNet的最后几层以减少内存使用
        for name, param in self.base_model.unet.named_parameters():
            if 'up_blocks.3' in name or 'conv_out' in name:  # 只训练最后的上采样块
                param.requires_grad = True
                trainable_params.append(param)
                param_count += param.numel()
            else:
                param.requires_grad = False
        
        logger.info(f"可训练参数数量: {param_count:,}")
        
        # 设置优化器
        optimizer = torch.optim.AdamW(
            trainable_params,
            lr=self.config["learning_rate"],
            weight_decay=0.01
        )
        
        # 准备训练
        self.base_model.unet, optimizer, train_dataloader = self.accelerator.prepare(
            self.base_model.unet, optimizer, train_dataloader
        )
        
        # 训练循环
        global_step = 0
        losses = []
        
        for epoch in range(self.config["num_epochs"]):
            epoch_loss = 0
            progress_bar = tqdm(train_dataloader, desc=f"Epoch {epoch+1}")
            
            for step, batch in enumerate(progress_bar):
                try:
                    # 前向传播
                    with self.accelerator.accumulate(self.base_model.unet):
                        # 获取条件输入，确保使用float32
                        image = batch['image'].to(self.device, dtype=torch.float32)
                        label = batch['label']
                        
                        # 归一化到[-1, 1]
                        image = image * 2.0 - 1.0
                        
                        # VAE编码为latent（使用no_grad以节省内存）
                        with torch.no_grad():
                            latent_dist = self.base_model.vae.encode(image)
                            latents = latent_dist.latent_dist.sample()
                            latents = latents * self.base_model.vae.config.scaling_factor
                        
                        # 加噪声，确保使用float32
                        noise = torch.randn_like(latents, dtype=torch.float32)
                        timesteps = torch.randint(
                            0, self.base_model.noise_scheduler.config.num_train_timesteps,
                            (latents.shape[0],), device=self.device, dtype=torch.long
                        )
                        noisy_latents = self.base_model.noise_scheduler.add_noise(
                            latents, noise, timesteps
                        )
                        
                        # 简化的文本编码（使用no_grad以节省内存）
                        with torch.no_grad():
                            # 使用两个text_encoder但简化处理
                            inputs = self.base_model.tokenizer(
                                list(label),
                                padding="max_length",
                                truncation=True,
                                max_length=77,  # 使用较短的序列长度
                                return_tensors="pt"
                            )
                            inputs = {k: v.to(self.device) for k, v in inputs.items()}
                            
                            inputs_2 = self.base_model.tokenizer_2(
                                list(label),
                                padding="max_length",
                                truncation=True,
                                max_length=77,  # 使用较短的序列长度
                                return_tensors="pt"
                            )
                            inputs_2 = {k: v.to(self.device) for k, v in inputs_2.items()}
                            
                            # 获取两个text_encoder的输出
                            text_encoder_out = self.base_model.text_encoder(**inputs)
                            text_encoder_2_out = self.base_model.text_encoder_2(**inputs_2)
                            
                            # 正确拼接两个text_encoder的hidden_states
                            # 确保序列长度一致
                            hidden_states_1 = text_encoder_out.last_hidden_state
                            hidden_states_2 = text_encoder_2_out.last_hidden_state
                            
                            # 如果序列长度不同，需要调整
                            if hidden_states_1.shape[1] != hidden_states_2.shape[1]:
                                min_len = min(hidden_states_1.shape[1], hidden_states_2.shape[1])
                                hidden_states_1 = hidden_states_1[:, :min_len, :]
                                hidden_states_2 = hidden_states_2[:, :min_len, :]
                            
                            encoder_hidden_states = torch.cat([
                                hidden_states_1,
                                hidden_states_2
                            ], dim=-1)
                            
                            # 使用text_encoder_2的pooled输出
                            pooled_prompt_embeds = text_encoder_2_out.text_embeds
                            
                            # 简化的time_ids，确保使用float32
                            time_ids = torch.tensor([256, 256, 0, 0, 256, 256], dtype=torch.float32, device=self.device).repeat(latents.shape[0], 1)
                        
                        # UNet前向传播
                        noise_pred = self.base_model.unet(
                            noisy_latents,
                            timesteps,
                            encoder_hidden_states=encoder_hidden_states,
                            added_cond_kwargs={"text_embeds": pooled_prompt_embeds, "time_ids": time_ids}
                        ).sample
                        
                        # 计算损失
                        loss = F.mse_loss(noise_pred, noise)
                        
                        # 反向传播
                        self.accelerator.backward(loss)
                        
                        # 梯度裁剪
                        if self.accelerator.sync_gradients:
                            self.accelerator.clip_grad_norm_(trainable_params, 1.0)
                        
                        # 更新参数
                        optimizer.step()
                        optimizer.zero_grad()
                    
                    # 更新进度条
                    current_loss = loss.item()
                    progress_bar.set_postfix(loss=current_loss)
                    epoch_loss += current_loss
                    losses.append(current_loss)
                    
                    # 清理内存
                    if step % 5 == 0:
                        self.clear_memory()
                    
                    # 保存检查点 - 减少保存频率以避免错误
                    if global_step % max(self.config["save_steps"], 20) == 0 and global_step > 0:
                        checkpoint_dir = os.path.join(
                            self.config["output_dir"],
                            f"checkpoint-{global_step}"
                        )
                        self.save_checkpoint(checkpoint_dir)
                    
                    global_step += 1
                    
                except Exception as e:
                    logger.error(f"训练步骤失败: {e}")
                    self.clear_memory()
                    continue
            
            # 计算epoch平均损失
            if len(train_dataloader) > 0:
                epoch_loss /= len(train_dataloader)
                logger.info(f"Epoch {epoch+1} 平均损失: {epoch_loss:.4f}")
            
            # 保存epoch检查点
            epoch_dir = os.path.join(
                self.config["output_dir"],
                f"epoch-{epoch+1}"
            )
            self.save_checkpoint(epoch_dir)
            
            # 清理内存
            self.clear_memory()
        
        # 可视化训练损失
        self.visualize_training_metrics(losses)
        
        logger.info("训练完成")
    
    def visualize_training_metrics(self, losses):
        """
        可视化训练指标
        
        参数:
            losses (list): 损失值列表
        """
        if not losses:
            return
            
        plt.figure(figsize=(10, 6))
        plt.plot(losses)
        plt.title('训练损失曲线')
        plt.xlabel('训练步数')
        plt.ylabel('损失值')
        plt.grid(True)
        
        # 保存图表
        output_dir = self.config["output_dir"]
        os.makedirs(output_dir, exist_ok=True)
        plt.savefig(os.path.join(output_dir, "training_loss.png"))
        plt.close()
        
        # 计算并记录统计信息
        avg_loss = np.mean(losses)
        min_loss = np.min(losses)
        final_loss = losses[-1] if losses else 0
        
        logger.info(f"训练统计 - 平均损失: {avg_loss:.4f}, 最小损失: {min_loss:.4f}, 最终损失: {final_loss:.4f}")
        
        # 保存训练统计
        stats = {
            "total_steps": len(losses),
            "average_loss": float(avg_loss),
            "minimum_loss": float(min_loss),
            "final_loss": float(final_loss),
            "losses": losses
        }
        
        with open(os.path.join(output_dir, "training_stats.json"), 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)
    
    def save_checkpoint(self, output_dir):
        """
        保存检查点 - 简化版本
        
        参数:
            output_dir (str): 输出目录
        """
        try:
            os.makedirs(output_dir, exist_ok=True)
            
            # 清理内存
            self.clear_memory()
            
            # 只保存可训练参数的状态字典以节省空间
            unet_model = self.accelerator.unwrap_model(self.base_model.unet)
            
            # 只保存可训练的参数
            trainable_state_dict = {}
            for name, param in unet_model.named_parameters():
                if param.requires_grad:
                    trainable_state_dict[name] = param.cpu().clone().detach()
            
            # 使用更安全的保存方式
            checkpoint_path = os.path.join(output_dir, "trainable_params.pt")
            torch.save(trainable_state_dict, checkpoint_path, _use_new_zipfile_serialization=False)
            
            # 保存训练配置
            config_path = os.path.join(output_dir, "config.json")
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            
            # 保存训练状态信息
            training_info = {
                "trainable_params_count": len(trainable_state_dict),
                "checkpoint_type": "trainable_only",
                "model_id": self.config["model_id"]
            }
            
            info_path = os.path.join(output_dir, "training_info.json")
            with open(info_path, 'w', encoding='utf-8') as f:
                json.dump(training_info, f, indent=2, ensure_ascii=False)
            
            logger.info(f"检查点已保存到: {output_dir}")
            logger.info(f"保存了 {len(trainable_state_dict)} 个可训练参数")
            
            # 清理临时变量
            del trainable_state_dict
            self.clear_memory()
            
        except Exception as e:
            logger.error(f"保存检查点失败: {e}")
            # 尝试清理可能损坏的文件
            try:
                checkpoint_path = os.path.join(output_dir, "trainable_params.pt")
                if os.path.exists(checkpoint_path):
                    os.remove(checkpoint_path)
                    logger.info("已清理损坏的检查点文件")
            except:
                pass
    
    def load_checkpoint(self, checkpoint_dir):
        """
        加载检查点 - 简化版本
        
        参数:
            checkpoint_dir (str): 检查点目录
        """
        try:
            # 尝试加载可训练参数
            trainable_path = os.path.join(checkpoint_dir, "trainable_params.pt")
            unet_path = os.path.join(checkpoint_dir, "unet_state_dict.pt")
            
            if os.path.exists(trainable_path):
                # 加载可训练参数
                state_dict = torch.load(trainable_path, map_location=self.device)
                self.base_model.unet.load_state_dict(state_dict, strict=False)
                logger.info(f"已加载可训练参数检查点: {checkpoint_dir}")
                logger.info(f"加载了 {len(state_dict)} 个参数")
            elif os.path.exists(unet_path):
                # 兼容旧格式
                state_dict = torch.load(unet_path, map_location=self.device)
                self.base_model.unet.load_state_dict(state_dict, strict=False)
                logger.info(f"已加载完整UNet检查点: {checkpoint_dir}")
            else:
                logger.warning(f"检查点文件不存在: {trainable_path} 或 {unet_path}")
                
        except Exception as e:
            logger.error(f"加载检查点失败: {e}")
    
    def generate(self, prompt, pattern_type=None, output_dir=None, num_images=1):
        """
        生成刺绣纹样 - 简化版本
        
        参数:
            prompt (str): 生成提示词
            pattern_type (str, optional): 图案类型
            output_dir (str, optional): 输出目录
            num_images (int): 生成图像数量
            
        返回:
            list: 生成的图像列表
        """
        # 如果模型未初始化，先初始化
        if not self.base_model:
            logger.info("初始化模型用于生成...")
            self.initialize_models()
        
        # 尝试加载最新的检查点
        self.load_latest_checkpoint()
            
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        
        # 简化生成过程
        images = []
        try:
            for i in range(num_images):
                logger.info(f"生成第 {i+1}/{num_images} 张图像...")
                # 使用基础模型生成
                image = self.base_model.generate(
                    prompt=prompt,
                    output_path=os.path.join(output_dir, f"generated_{i+1}.png") if output_dir else None
                )
                images.append(image)
                logger.info(f"图像 {i+1} 生成完成")
                
        except Exception as e:
            logger.error(f"生成图像失败: {e}")
        
        return images
    
    def load_latest_checkpoint(self):
        """
        加载最新的检查点
        """
        try:
            output_dir = self.config["output_dir"]
            if not os.path.exists(output_dir):
                logger.warning("未找到训练输出目录，将使用预训练模型")
                return
            
            # 查找最新的epoch检查点
            epoch_dirs = []
            for item in os.listdir(output_dir):
                if item.startswith("epoch-") and os.path.isdir(os.path.join(output_dir, item)):
                    try:
                        epoch_num = int(item.split("-")[1])
                        epoch_dirs.append((epoch_num, item))
                    except:
                        continue
            
            if epoch_dirs:
                # 按epoch数排序，取最新的
                epoch_dirs.sort(key=lambda x: x[0], reverse=True)
                latest_epoch_dir = os.path.join(output_dir, epoch_dirs[0][1])
                logger.info(f"找到最新检查点: {latest_epoch_dir}")
                self.load_checkpoint(latest_epoch_dir)
                return
            
            # 如果没有epoch检查点，查找step检查点
            step_dirs = []
            for item in os.listdir(output_dir):
                if item.startswith("checkpoint-") and os.path.isdir(os.path.join(output_dir, item)):
                    try:
                        step_num = int(item.split("-")[1])
                        step_dirs.append((step_num, item))
                    except:
                        continue
            
            if step_dirs:
                # 按step数排序，取最新的
                step_dirs.sort(key=lambda x: x[0], reverse=True)
                latest_step_dir = os.path.join(output_dir, step_dirs[0][1])
                logger.info(f"找到最新检查点: {latest_step_dir}")
                self.load_checkpoint(latest_step_dir)
                return
            
            logger.warning("未找到任何检查点，将使用预训练模型")
            
        except Exception as e:
            logger.error(f"加载检查点时出错: {e}")
            logger.warning("将使用预训练模型")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="金线刺绣模型训练与推理 - CPU优化版本")
    parser.add_argument("--mode", type=str, choices=["train", "generate"], 
                       required=True, help="运行模式: train, generate")
    parser.add_argument("--config", type=str, default=None, help="配置文件路径")
    parser.add_argument("--data_dir", type=str, default="data/图像层", help="训练数据目录")
    parser.add_argument("--output_dir", type=str, default="output/results", help="输出目录")
    parser.add_argument("--prompt", type=str, default="一品文官仙鹤金线刺绣", help="生成提示词")
    parser.add_argument("--pattern_type", type=str, default="一品文官仙鹤", help="图案类型")
    parser.add_argument("--num_images", type=int, default=1, help="生成图像数量")
    parser.add_argument("--max_samples", type=int, default=None, help="最大训练样本数，None表示使用全部数据")
    parser.add_argument("--image_size", type=int, default=256, help="图像尺寸")
    parser.add_argument("--batch_size", type=int, default=1, help="批次大小")
    
    args = parser.parse_args()
    
    try:
        trainer = GoldThreadModelTrainer(config_path=args.config)
        
        # 更新配置参数
        if args.max_samples is not None:
            trainer.config["max_samples"] = args.max_samples
        if args.image_size is not None:
            trainer.config["image_size"] = args.image_size
        if args.batch_size is not None:
            trainer.config["batch_size"] = args.batch_size
        
        logger.info(f"运行模式: {args.mode}")
        logger.info(f"配置参数: max_samples={trainer.config['max_samples']}, "
                   f"image_size={trainer.config['image_size']}, "
                   f"batch_size={trainer.config['batch_size']}")
        
        if args.mode == "train":
            trainer.train(args.data_dir)
        elif args.mode == "generate":
            output_dir = os.path.join(args.output_dir, "generation")
            trainer.generate(args.prompt, args.pattern_type, output_dir, args.num_images)
            
    except Exception as e:
        logger.error(f"程序执行失败: {e}")
        import traceback
        traceback.print_exc() 