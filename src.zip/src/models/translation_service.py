#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json
import time
import hashlib
import random
import re
from typing import Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)

class TranslationService:
    """翻译服务 - 集成多种翻译方案"""
    
    def __init__(self, method="baidu", **kwargs):
        """
        初始化翻译服务
        
        Args:
            method: 翻译方法 ("baidu", "youdao", "google", "local", "dict")
            **kwargs: 各种翻译服务的配置参数
        """
        self.method = method
        self.config = kwargs
        
        # 百度翻译配置
        self.baidu_app_id = kwargs.get('baidu_app_id')
        self.baidu_secret_key = kwargs.get('baidu_secret_key')
        
        # 有道翻译配置
        self.youdao_app_key = kwargs.get('youdao_app_key')
        self.youdao_app_secret = kwargs.get('youdao_app_secret')
        
        # 缓存翻译结果
        self.translation_cache = {}
        
        # 词典翻译（备用方案）
        self.translation_dict = self._load_translation_dict()
    
    def _load_translation_dict(self):
        """加载翻译词典"""
        return {
            # 官品等级
            "一品": "first rank", "二品": "second rank", "三品": "third rank", 
            "四品": "fourth rank", "五品": "fifth rank", "六品": "sixth rank",
            "七品": "seventh rank", "八品": "eighth rank", "九品": "ninth rank",
            
            # 文武官
            "文官": "civil official", "武官": "military official",
            
            # 动物名称
            "仙鹤": "crane", "锦鸡": "golden pheasant", "孔雀": "peacock",
            "云雁": "wild goose", "白鹇": "silver pheasant", "鹭鸶": "egret",
            "鸂鶒": "mandarin duck", "鹌鹑": "quail", "练鹊": "magpie",
            "麒麟": "qilin", "狮子": "lion", "豹子": "leopard",
            "虎": "tiger", "熊": "bear", "彪纹": "tiger stripes", "獬豸": "xiezhi",
            "犀牛": "rhinoceros", "海马": "seahorse",
            
            # 刺绣针法术语
            "平绣": "satin stitch", "打籽绣": "seed stitch", "盘金": "couching",
            "施金": "gold applique", "锁绣": "chain stitch", "贴金": "gold leaf application",
            "捻金线": "twisted gold thread", "勾勒轮廓": "outline stitching",
            
            # 文化语义
            "品德高尚": "noble character", "才能卓越": "outstanding talent",
            "镇守一方": "guarding a region", "象征": "symbolizes",
            "寓意": "meaning", "祥瑞": "auspicious", "吉祥": "lucky",
            "富贵": "wealth and honor", "长寿": "longevity", "清廉": "integrity",
            
            # 工艺描述
            "精细": "fine", "繁复": "intricate", "密布": "densely distributed",
            "层次分明": "distinct layers", "色彩丰富": "rich colors",
            "构图饱满": "full composition", "工艺精湛": "exquisite craftsmanship",
            
            # 补子相关
            "补子": "rank badge", "官服": "official robe", "朝服": "court dress",
            "中心纹样": "central pattern", "中心主体": "central motif",
            "背景地": "background field", "边框类型": "border type",
            
            # 颜色
            "金色": "golden", "红色": "red", "蓝色": "blue", "绿色": "green",
            "黄色": "yellow", "紫色": "purple", "黑色": "black", "白色": "white",
            
            # 纹样
            "江崖海水纹": "river cliff and sea wave pattern",
            "立水纹": "standing wave pattern", "回纹": "meander pattern",
            "祥云": "auspicious clouds", "杂宝": "various treasures",
            "如意": "ruyi scepter", "牡丹花": "peony flower", "莲花": "lotus flower"
        }
    
    def translate(self, text: str, from_lang: str = "zh", to_lang: str = "en") -> str:
        """
        翻译文本
        
        Args:
            text: 要翻译的文本
            from_lang: 源语言代码
            to_lang: 目标语言代码
        
        Returns:
            翻译后的文本
        """
        if not text or not text.strip():
            return text
        
        # 检查缓存
        cache_key = f"{self.method}_{from_lang}_{to_lang}_{text}"
        if cache_key in self.translation_cache:
            return self.translation_cache[cache_key]
        
        try:
            # 根据方法选择翻译服务
            if self.method == "baidu":
                result = self._translate_baidu(text, from_lang, to_lang)
            elif self.method == "youdao":
                result = self._translate_youdao(text, from_lang, to_lang)
            elif self.method == "google":
                result = self._translate_google(text, from_lang, to_lang)
            elif self.method == "local":
                result = self._translate_local(text)
            else:  # dict
                result = self._translate_dict(text)
            
            # 验证翻译结果
            if not result or result == text:
                # 如果翻译结果为空或与原文相同，尝试词典翻译
                if self.method != "dict":
                    logger.warning(f"翻译结果无效，降级到词典翻译: {text[:50]}...")
                    result = self._translate_dict(text)
            
            # 缓存结果
            self.translation_cache[cache_key] = result
            return result
            
        except Exception as e:
            logger.warning(f"翻译失败 ({self.method}): {e}")
            # 降级到词典翻译
            result = self._translate_dict(text)
            self.translation_cache[cache_key] = result
            return result
    
    def _translate_baidu(self, text: str, from_lang: str, to_lang: str) -> str:
        """百度翻译API"""
        if not self.baidu_app_id or not self.baidu_secret_key:
            raise ValueError("百度翻译需要配置 app_id 和 secret_key")
        
        url = "https://fanyi-api.baidu.com/api/trans/vip/translate"
        
        # 生成签名
        salt = str(random.randint(32768, 65536))
        sign_str = self.baidu_app_id + text + salt + self.baidu_secret_key
        sign = hashlib.md5(sign_str.encode('utf-8')).hexdigest()
        
        params = {
            'q': text,
            'from': from_lang,
            'to': to_lang,
            'appid': self.baidu_app_id,
            'salt': salt,
            'sign': sign
        }
        
        response = requests.get(url, params=params, timeout=10)
        result = response.json()
        
        if 'trans_result' in result:
            return result['trans_result'][0]['dst']
        else:
            raise Exception(f"百度翻译错误: {result}")
    
    def _translate_youdao(self, text: str, from_lang: str, to_lang: str) -> str:
        """有道翻译API"""
        if not self.youdao_app_key or not self.youdao_app_secret:
            raise ValueError("有道翻译需要配置 app_key 和 app_secret")
        
        url = "https://openapi.youdao.com/api"
        
        # 生成签名
        salt = str(int(time.time()))
        sign_str = self.youdao_app_key + text + salt + self.youdao_app_secret
        sign = hashlib.sha256(sign_str.encode('utf-8')).hexdigest()
        
        data = {
            'q': text,
            'from': from_lang,
            'to': to_lang,
            'appKey': self.youdao_app_key,
            'salt': salt,
            'sign': sign,
            'signType': 'v3',
            'curtime': str(int(time.time()))
        }
        
        response = requests.post(url, data=data, timeout=10)
        result = response.json()
        
        if result.get('errorCode') == '0':
            return result['translation'][0]
        else:
            raise Exception(f"有道翻译错误: {result}")
    
    def _translate_google(self, text: str, from_lang: str, to_lang: str) -> str:
        """Google翻译（免费接口，可能不稳定）"""
        try:
            from googletrans import Translator
            import time
            
            # 创建翻译器实例
            translator = Translator()
            
            # 修复语言代码映射
            lang_mapping = {
                'zh': 'zh-cn',
                'en': 'en'
            }
            
            src_lang = lang_mapping.get(from_lang, from_lang)
            dest_lang = lang_mapping.get(to_lang, to_lang)
            
            # 添加重试机制
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    # 确保同步调用
                    result = translator.translate(text, src=src_lang, dest=dest_lang)
                    
                    # 检查结果类型
                    if hasattr(result, 'text'):
                        return result.text
                    elif isinstance(result, str):
                        return result
                    else:
                        # 如果结果不是预期格式，降级到词典翻译
                        logger.warning(f"Google翻译返回格式异常: {type(result)}")
                        return self._translate_dict(text)
                        
                except Exception as e:
                    if attempt < max_retries - 1:
                        logger.warning(f"Google翻译重试 {attempt + 1}/{max_retries}: {e}")
                        time.sleep(1)  # 等待1秒后重试
                        continue
                    else:
                        raise e
                        
        except ImportError:
            raise Exception("需要安装 googletrans: pip install googletrans==4.0.0-rc1")
        except Exception as e:
            logger.warning(f"Google翻译失败: {e}")
            # 降级到词典翻译
            return self._translate_dict(text)
    
    def _translate_local(self, text: str) -> str:
        """本地翻译模型（需要安装transformers）"""
        try:
            from transformers import MarianMTModel, MarianTokenizer
            
            # 使用Helsinki-NLP的中英翻译模型
            model_name = "Helsinki-NLP/opus-mt-zh-en"
            tokenizer = MarianTokenizer.from_pretrained(model_name)
            model = MarianMTModel.from_pretrained(model_name)
            
            # 翻译
            inputs = tokenizer(text, return_tensors="pt", padding=True)
            translated = model.generate(**inputs)
            result = tokenizer.decode(translated[0], skip_special_tokens=True)
            
            return result
            
        except ImportError:
            raise Exception("需要安装 transformers: pip install transformers torch")
        except Exception as e:
            raise Exception(f"本地翻译错误: {e}")
    
    def _translate_dict(self, text: str) -> str:
        """词典翻译（备用方案）"""
        result = text
        for chinese, english in self.translation_dict.items():
            result = result.replace(chinese, english)
        return result
    
    def translate_batch(self, texts: list, from_lang: str = "zh", to_lang: str = "en") -> list:
        """批量翻译"""
        results = []
        for text in texts:
            try:
                result = self.translate(text, from_lang, to_lang)
                results.append(result)
                # 添加延迟避免API限制
                if self.method in ["baidu", "youdao"]:
                    time.sleep(0.1)
            except Exception as e:
                logger.warning(f"批量翻译失败: {text} - {e}")
                results.append(self._translate_dict(text))
        return results
    
    def translate_knowledge_data(self, knowledge_data: Dict[str, Any]) -> Dict[str, Any]:
        """翻译知识数据"""
        translated = {}
        
        for key, value in knowledge_data.items():
            if isinstance(value, dict):
                # 递归翻译嵌套字典
                translated[key] = self.translate_knowledge_data(value)
            elif isinstance(value, str) and value.strip():
                # 翻译字符串值
                if key == "文化语义" and len(value) > 50:
                    # 长文本分句翻译
                    sentences = re.split(r'[。！？]', value)
                    translated_sentences = []
                    for sentence in sentences:
                        if sentence.strip():
                            translated_sentence = self.translate(sentence.strip())
                            translated_sentences.append(translated_sentence)
                    translated[key] = '. '.join(translated_sentences)
                else:
                    # 普通翻译
                    translated[key] = self.translate(value)
            else:
                # 保持原值
                translated[key] = value
        
        return translated

# 翻译服务工厂
class TranslationServiceFactory:
    """翻译服务工厂"""
    
    @staticmethod
    def create_service(method: str = "auto", **kwargs) -> TranslationService:
        """
        创建翻译服务
        
        Args:
            method: 翻译方法
                - "auto": 自动选择最佳方案
                - "baidu": 百度翻译（需要API密钥）
                - "youdao": 有道翻译（需要API密钥）
                - "google": Google翻译（免费但可能不稳定）
                - "local": 本地翻译模型（需要下载模型）
                - "dict": 词典翻译（备用方案）
        """
        if method == "auto":
            # 自动选择最佳方案
            if kwargs.get('baidu_app_id') and kwargs.get('baidu_secret_key'):
                return TranslationService("baidu", **kwargs)
            elif kwargs.get('youdao_app_key') and kwargs.get('youdao_app_secret'):
                return TranslationService("youdao", **kwargs)
            else:
                # 尝试Google翻译
                try:
                    service = TranslationService("google", **kwargs)
                    # 测试翻译
                    service.translate("测试")
                    return service
                except:
                    # 降级到词典翻译
                    return TranslationService("dict", **kwargs)
        else:
            return TranslationService(method, **kwargs)

# 使用示例和配置
def get_translation_config():
    """获取翻译配置示例"""
    return {
        # 百度翻译配置（推荐）
        "baidu": {
            "baidu_app_id": "your_baidu_app_id",
            "baidu_secret_key": "your_baidu_secret_key"
        },
        
        # 有道翻译配置
        "youdao": {
            "youdao_app_key": "your_youdao_app_key", 
            "youdao_app_secret": "your_youdao_app_secret"
        },
        
        # Google翻译（免费但可能不稳定）
        "google": {},
        
        # 本地翻译模型
        "local": {},
        
        # 词典翻译（备用）
        "dict": {}
    }

if __name__ == "__main__":
    # 测试翻译服务
    print("🔍 测试翻译服务")
    
    test_texts = [
        "一品文官仙鹤",
        "武官一品补子，中心主体为麒麟，象征官员品德高尚、才能卓越、镇守一方",
        "平绣,打籽绣,盘金,施金",
        "文化语义：品德高尚，才能卓越，镇守一方"
    ]
    
    # 测试不同翻译方法
    methods = ["dict", "google"]  # 可用的方法
    
    for method in methods:
        print(f"\n📝 测试 {method} 翻译:")
        try:
            service = TranslationServiceFactory.create_service(method)
            for text in test_texts:
                result = service.translate(text)
                print(f"  原文: {text}")
                print(f"  译文: {result}")
                print()
        except Exception as e:
            print(f"  ❌ {method} 翻译失败: {e}") 