#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from PIL import Image
import logging
import json
from tqdm import tqdm
import matplotlib.pyplot as plt
from torch.utils.data import Dataset, DataLoader
from diffusers import StableDiffusionXLPipeline, UNet2DConditionModel, DDPMScheduler
from transformers import CLIPTextModel, CLIPTokenizer
import torchvision.transforms as T
from accelerate import Accelerator
import re
from safetensors.torch import save_file, load_file

# 导入LoRA相关组件 - 修复版本兼容性
try:
    from diffusers.models.attention_processor import LoRAAttnProcessor, AttnProcsLayers
except ImportError:
    try:
        from diffusers.models.lora import LoRAAttnProcessor, AttnProcsLayers
    except ImportError:
        # 如果都导入失败，使用基本的LoRA实现
        from diffusers.loaders import AttnProcsLayers
        from diffusers.models.attention_processor import AttnProcessor

        class LoRAAttnProcessor(AttnProcessor):
            def __init__(self, *args, **kwargs):
                super().__init__()
                # 简化的LoRA处理器
                pass

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class OptimizedPromptProcessor:
    """优化的提示词处理器 - 专门为SDXL设计的简洁高效提示词"""
    
    def __init__(self):
        # 核心刺绣术语映射 - 只保留SDXL能理解的关键词
        self.core_terms = {
            # 官品等级 - 简化
            "一品": "first rank",
            "二品": "second rank", 
            "三品": "third rank",
            "四品": "fourth rank",
            "五品": "fifth rank",
            "六品": "sixth rank",
            "七品": "seventh rank",
            
            # 动物 - 保持英文名
            "仙鹤": "crane",
            "锦鸡": "golden pheasant",
            "孔雀": "peacock",
            "云雁": "wild goose",
            "白鹇": "silver pheasant",
            "鹭鸶": "egret",
            "鹌鹑": "quail",
            
            # 刺绣工艺 - 简化为SDXL理解的术语
            "金线刺绣": "gold embroidery",
            "刺绣": "embroidery",
            "丝线": "silk thread",
            "金线": "gold thread",
            "补子": "rank badge",
            
            # 质量描述 - SDXL友好的形容词
            "精细": "detailed",
            "精美": "elegant",
            "传统": "traditional",
            "华丽": "ornate",
            "立体": "textured"
        }
        
        # 预定义的高质量提示词模板
        self.quality_templates = [
            "traditional Chinese embroidery",
            "silk fabric",
            "gold threads",
            "imperial court",
            "detailed needlework",
            "ornate design",
            "museum quality",
            "fine craftsmanship"
        ]
    
    def create_optimized_prompt(self, category, knowledge_data=None):
        """创建优化的提示词 - 简洁而有效"""
        parts = []
        
        # 1. 基础类型
        base_type = "Chinese imperial rank badge"
        parts.append(base_type)
        
        # 2. 动物主体
        for chinese, english in self.core_terms.items():
            if chinese in category:
                if english in ["crane", "golden pheasant", "peacock", "wild goose"]:
                    parts.append(f"{english} bird")
                break
        
        # 3. 等级
        for grade, grade_en in self.core_terms.items():
            if grade in category and "rank" in grade_en:
                parts.append(f"{grade_en} official")
                break
        
        # 4. 核心工艺术语
        parts.extend([
            "traditional gold embroidery",
            "silk fabric",
            "detailed needlework",
            "ornate design"
        ])
        
        # 5. 质量增强词
        parts.extend([
            "museum quality",
            "fine craftsmanship",
            "imperial court style"
        ])
        
        # 组合并限制长度
        prompt = ", ".join(parts)
        
        # 确保长度适中（SDXL最佳范围）
        if len(prompt) > 150:
            prompt = prompt[:150]
        
        return prompt
    
    def create_negative_prompt(self):
        """创建负面提示词"""
        return "blurry, low quality, distorted, deformed, text, watermark, signature, modern art, cartoon, anime, abstract"

class EmbroideryLoRADataset(Dataset):
    """专门为LoRA微调设计的刺绣数据集"""
    
    def __init__(self, data_dir, pretranslated_dir="data/pretranslated", 
                 image_size=256, max_samples=None):
        self.data_dir = data_dir
        self.image_size = image_size
        self.samples = []
        
        # 初始化提示词处理器
        self.prompt_processor = OptimizedPromptProcessor()
        
        # 数据增强 - 针对SDXL优化
        self.transform = T.Compose([
            T.Resize((image_size, image_size), interpolation=T.InterpolationMode.BILINEAR),
            T.RandomHorizontalFlip(p=0.3),  # 减少水平翻转，保持文化特征
            T.ToTensor(),
            T.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
        ])
        
        # 加载预翻译数据
        self.pretranslated_prompts = {}
        self._load_pretranslated_data(pretranslated_dir)
        
        # 只加载有预翻译数据的样本
        self._load_annotated_samples()
        
        if max_samples and max_samples < len(self.samples):
            self.samples = self.samples[:max_samples]
        
        logger.info(f"LoRA数据集加载完成，共 {len(self.samples)} 个样本")
    
    def _load_pretranslated_data(self, pretranslated_dir):
        """加载预翻译数据"""
        prompts_file = os.path.join(pretranslated_dir, "unified_prompts.json")
        
        if os.path.exists(prompts_file):
            try:
                with open(prompts_file, 'r', encoding='utf-8') as f:
                    self.pretranslated_prompts = json.load(f)
                logger.info(f"✅ 加载预翻译数据: {len(self.pretranslated_prompts)} 个提示词")
            except Exception as e:
                logger.warning(f"⚠️  加载预翻译数据失败: {e}")
    
    def _load_annotated_samples(self):
        """只加载有标注的样本"""
        logger.info("🎯 加载有标注的样本用于LoRA微调...")
        
        category_map = {
            '文官': '清代文官官补',
            '武官': '清代武官官补'
        }
        
        for prompt_key, prompt_info in self.pretranslated_prompts.items():
            try:
                category = prompt_info.get("category", "")
                if not category:
                    continue
                
                # 提取文件编号
                number_match = re.search(r'描述(\d+)$', prompt_key)
                if not number_match:
                    continue
                
                file_number = number_match.group(1)
                
                # 确定主目录
                main_dir = None
                for prefix, dir_name in category_map.items():
                    if prefix in category:
                        main_dir = dir_name
                        break
                
                if not main_dir:
                    continue
                
                # 构建图像路径
                image_category = category.replace(' ', '')
                image_filename = f"{image_category}{file_number}.png"
                
                # 尝试多个可能的路径
                possible_paths = [
                    os.path.join(self.data_dir, main_dir, image_category, image_filename),
                    os.path.join(self.data_dir, main_dir, category, image_filename),
                ]
                
                image_path = None
                for path in possible_paths:
                    if os.path.exists(path):
                        image_path = path
                        break
                
                if image_path:
                    # 创建优化的提示词
                    optimized_prompt = self.prompt_processor.create_optimized_prompt(
                        category, prompt_info.get('translated_data', {})
                    )
                    
                    self.samples.append({
                        'image_path': image_path,
                        'category': category,
                        'optimized_prompt': optimized_prompt,
                        'original_prompt': prompt_info.get('detailed_prompt', ''),
                        'prompt_key': prompt_key
                    })
                    
            except Exception as e:
                logger.debug(f"处理样本失败 {prompt_key}: {e}")
                continue
        
        logger.info(f"✅ 有效样本: {len(self.samples)} 个")
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        try:
            # 加载并预处理图像
            image = Image.open(sample['image_path']).convert('RGB')
            image = self.transform(image)
            
            return {
                'image': image,
                'prompt': sample['optimized_prompt'],
                'category': sample['category'],
                'image_path': sample['image_path']
            }
            
        except Exception as e:
            logger.warning(f"加载样本失败 {sample['image_path']}: {e}")
            # 返回默认数据
            return {
                'image': torch.zeros(3, self.image_size, self.image_size),
                'prompt': "traditional Chinese embroidery",
                'category': sample['category'],
                'image_path': sample['image_path']
            }

class EmbroideryLoRATrainer:
    """专门的刺绣LoRA微调器"""
    
    def __init__(self, model_id="checkpoints/stable-diffusion-xl-base-1.0", image_size=256):
        self.model_id = model_id
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.dtype = torch.float32  # 强制使用float32，避免混合精度问题
        
        # LoRA配置
        self.lora_config = {
            "rank": 64,
            "alpha": 64,
            "dropout": 0.1,
        }
        
        # 训练配置 - 优化速度和内存
        self.train_config = {
            "learning_rate": 5e-5,  # 降低学习率
            "batch_size": 1,
            "num_epochs": 3,        # 进一步减少epochs，LoRA收敛很快
            "gradient_accumulation_steps": 4,
            "save_steps": 25,       # 更频繁保存
            "num_inference_steps": 20,
            "image_size": image_size,      # 用户可自定义训练分辨率
            "inference_size": 1024, # 推理时可以用更高分辨率
            "max_grad_norm": 0.5,   # 梯度裁剪
            "warmup_steps": 50,     # 减少预热步数
        }
        
        self.pipeline = None
        self.lora_layers = None
        self.accelerator = None
        
        logger.info(f"LoRA训练器初始化完成，设备: {self.device}")
    
    def initialize_pipeline(self):
        """初始化pipeline和LoRA"""
        logger.info("初始化SDXL pipeline...")
        
        # 检查本地模型
        if not os.path.exists(self.model_id):
            logger.error(f"本地模型不存在: {self.model_id}")
            raise FileNotFoundError("请先下载SDXL模型")
        
        # 加载pipeline
        self.pipeline = StableDiffusionXLPipeline.from_pretrained(
            self.model_id,
            torch_dtype=self.dtype,
            use_safetensors=True,
            local_files_only=True
        ).to(self.device)
        
        # 启用内存优化
        if self.device.type == "cuda":
            self.pipeline.enable_attention_slicing()
            self.pipeline.enable_vae_slicing()
            self.pipeline.enable_model_cpu_offload()
        
        logger.info("Pipeline初始化完成")
    
    def setup_lora(self):
        """设置LoRA层 - 适配diffusers 0.33.1"""
        logger.info("设置LoRA层...")
        
        try:
            logger.info("步骤1: 尝试使用pipeline内置LoRA方法...")
            
            # 方法1: 尝试使用pipeline的内置LoRA配置（如果支持）
            try:
                # 直接尝试创建空的LoRA适配器
                self.pipeline.load_lora_weights("", adapter_name="training")
                self.pipeline.set_adapters(["training"], adapter_weights=[1.0])
                
                logger.info("使用内置LoRA方法设置成功")
                
                # 获取可训练参数
                self.lora_layers = [p for p in self.pipeline.unet.parameters() if p.requires_grad]
                logger.info(f"内置LoRA - 可训练参数数量: {sum(p.numel() for p in self.lora_layers):,}")
                return
                
            except Exception as e:
                logger.info(f"内置LoRA方法失败: {e}")
            
            logger.info("步骤2: 尝试使用简化LoRA实现...")
            
            # 直接使用简化的LoRA实现
            self._setup_simple_lora()
            
        except Exception as e:
            logger.error(f"LoRA设置失败: {e}")
            import traceback
            traceback.print_exc()
            raise
    
    def _setup_simple_lora(self):
        """简化的LoRA设置作为后备方案"""
        logger.info("使用简化LoRA实现...")
        
        # 创建一个简单的LoRA层列表
        lora_params = []
        selected_param_names = set()  # 使用名称来跟踪已选择的参数
        
        logger.info("正在扫描UNet参数...")
        total_params = 0
        trainable_count = 0
        
        # 首先查看UNet的实际结构
        attention_layers = []
        for name, param in self.pipeline.unet.named_parameters():
            total_params += 1
            if "attn" in name and ("to_q" in name or "to_k" in name or "to_v" in name):
                attention_layers.append(name)
        
        logger.info(f"发现 {len(attention_layers)} 个注意力层")
        if len(attention_layers) > 0:
            logger.info("前10个注意力层示例:")
            for i, layer_name in enumerate(attention_layers[:10]):
                logger.info(f"  {i+1}: {layer_name}")
        
        # LoRA超轻量策略：极简参数选择
        # 1. 只选择最后一个up_block（up_blocks.3，最接近输出）
        # 2. 只选择attn2（cross-attention，文本到图像的关键连接）
        # 3. 只选择to_v（Value矩阵，最关键的权重）
        # 4. 限制在2-3个参数层以内
        
        target_patterns = [
            # 最高优先级：最后一个up_block的cross-attention
            ("up_blocks.3", "attn2"),
            # 备选：倒数第二个up_block
            ("up_blocks.2", "attn2"),
        ]
        
        max_trainable_params = 3  # 极限：最多3个参数层
        target_param_types = ["to_v"]  # 只选择to_v（Value矩阵）
        
        for pattern_group, attn_type in target_patterns:
            if len(lora_params) >= max_trainable_params:
                break
                
            logger.info(f"搜索 {pattern_group} 中的 {attn_type} 层（只选择 {target_param_types}）...")
            
            for name, param in self.pipeline.unet.named_parameters():
                if len(lora_params) >= max_trainable_params:
                    break
                    
                # 匹配模式：只选择to_v（最关键的权重矩阵）
                if (pattern_group in name and 
                    attn_type in name and
                    any(target_type in name for target_type in target_param_types) and
                    name not in selected_param_names):
                    
                    param.requires_grad = True
                    lora_params.append(param)
                    selected_param_names.add(name)
                    trainable_count += 1
                    logger.info(f"✅ 启用训练: {name} - 参数数量: {param.numel():,}")
        
        # 如果还是没找到参数，使用最保守的降级策略
        if len(lora_params) == 0:
            logger.warning("精确匹配失败，使用最保守的降级策略...")
            
            # 选择任何包含up_blocks且to_v的层，但极限数量
            count = 0
            for name, param in self.pipeline.unet.named_parameters():
                if count >= 2:  # 最多2个参数层
                    break
                    
                if ("up_blocks" in name and "to_v" in name):  # 只选择to_v
                    param.requires_grad = True
                    lora_params.append(param)
                    selected_param_names.add(name)
                    count += 1
                    logger.info(f"🔄 降级选择: {name} - 参数数量: {param.numel():,}")
                    
                    # 如果第一个参数就超过10M，立即停止
                    if param.numel() > 10_000_000:
                        logger.warning(f"单个参数层过大: {param.numel():,}，停止添加更多层")
                        break
        
        # 确保其他参数不被训练
        for name, param in self.pipeline.unet.named_parameters():
            if name not in selected_param_names:
                param.requires_grad = False
        
        logger.info(f"UNet参数扫描完成: 总计 {total_params} 个参数，启用训练 {len(lora_params)} 个")
        
        # 创建参数组
        class SimpleLoRALayers:
            def __init__(self, params):
                self.params = params
            
            def parameters(self):
                return self.params
        
        self.lora_layers = SimpleLoRALayers(lora_params)
        
        param_count = sum(p.numel() for p in lora_params)
        logger.info(f"🎯 LoRA设置完成，可训练参数: {param_count:,}")
        
        # LoRA参数数量检查 - 极严格的标准
        if param_count > 10_000_000:  # 1000万参数硬限制
            logger.error(f"❌ 参数过多: {param_count:,}，超出内存限制")
            raise RuntimeError("LoRA参数数量过多，建议控制在10M以内")
        elif param_count > 5_000_000:  # 500万参数警告
            logger.warning(f"⚠️  参数较多: {param_count:,}，接近上限")
        else:
            logger.info(f"✅ 参数数量合理: {param_count:,}，符合轻量LoRA理念")
        
        if param_count == 0:
            raise RuntimeError("没有找到可训练的参数，LoRA设置失败")
        
        return True
    
    def train(self, data_dir, knowledge_dir="data/知识层1", output_dir="output/lora_models"):
        """训练LoRA"""
        logger.info("开始LoRA微调训练...")
        
        # 清理GPU内存
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
            
            # 显示初始内存状态
            memory_allocated = torch.cuda.memory_allocated() / (1024**3)
            memory_reserved = torch.cuda.memory_reserved() / (1024**3)
            memory_total = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            
            logger.info(f"GPU内存状态 - 总计: {memory_total:.2f}GB, 已分配: {memory_allocated:.2f}GB, 已保留: {memory_reserved:.2f}GB")
        
        # 初始化
        self.initialize_pipeline()
        self.setup_lora()
        
        # 再次检查内存
        if torch.cuda.is_available():
            memory_allocated = torch.cuda.memory_allocated() / (1024**3)
            logger.info(f"LoRA设置后GPU内存: {memory_allocated:.2f}GB")
        
        # 准备数据
        dataset = EmbroideryLoRADataset(
            data_dir=data_dir,
            image_size=self.train_config["image_size"],
            max_samples=166  # 使用所有有效样本，不限制数量
        )
        
        dataloader = DataLoader(
            dataset,
            batch_size=self.train_config["batch_size"],
            shuffle=True,
            num_workers=0
        )
        
        # 优化器 - 只训练LoRA参数
        # 获取可训练参数（兼容不同LoRA实现）
        if hasattr(self.lora_layers, 'parameters'):
            trainable_params = self.lora_layers.parameters()
        elif isinstance(self.lora_layers, list):
            trainable_params = self.lora_layers
        else:
            # 从UNet中获取可训练参数
            trainable_params = [p for p in self.pipeline.unet.parameters() if p.requires_grad]
        
        optimizer = torch.optim.AdamW(
            trainable_params,
            lr=self.train_config["learning_rate"],
            weight_decay=0.01
        )
        
        # 初始化加速器 - 禁用混合精度以避免NaN
        self.accelerator = Accelerator(
            gradient_accumulation_steps=self.train_config["gradient_accumulation_steps"],
            mixed_precision="no"  # 强制禁用混合精度
        )
        
        # 学习率调度器 - 添加预热
        num_training_steps = len(dataloader) * self.train_config["num_epochs"]
        warmup_steps = min(self.train_config["warmup_steps"], num_training_steps // 10)
        
        def lr_lambda(step):
            if step < warmup_steps:
                return step / warmup_steps
            else:
                return max(0.1, (num_training_steps - step) / (num_training_steps - warmup_steps))
        
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
        
        # 准备训练 - 根据不同的lora_layers类型选择不同的准备方式
        if hasattr(self.lora_layers, 'parameters'):
            self.lora_layers, optimizer, dataloader = self.accelerator.prepare(
                self.lora_layers, optimizer, dataloader
            )
        else:
            # 如果lora_layers是参数列表，直接准备优化器和数据加载器
            optimizer, dataloader = self.accelerator.prepare(optimizer, dataloader)
        
        # 训练循环
        global_step = 0
        losses = []
        
        os.makedirs(output_dir, exist_ok=True)
        
        for epoch in range(self.train_config["num_epochs"]):
            epoch_losses = []
            
            progress_bar = tqdm(dataloader, desc=f"Epoch {epoch+1}/{self.train_config['num_epochs']}")
            
            for step, batch in enumerate(progress_bar):
                try:
                    # 根据lora_layers类型选择accumulate对象
                    accumulate_obj = self.lora_layers if hasattr(self.lora_layers, 'parameters') else self.pipeline.unet
                    
                    with self.accelerator.accumulate(accumulate_obj):
                        # 获取数据
                        images = batch['image'].to(self.device, dtype=self.dtype)
                        prompts = batch['prompt']
                        
                        # 数据验证 - 检查是否有异常值
                        if torch.isnan(images).any() or torch.isinf(images).any():
                            logger.warning("检测到图像数据中有NaN或Inf，跳过此批次")
                            continue
                        
                        # 确保图像数据在正确范围内
                        images = torch.clamp(images, -1.0, 1.0)
                        
                        # VAE编码
                        with torch.no_grad():
                            latents = self.pipeline.vae.encode(images).latent_dist.sample()
                            latents = latents * self.pipeline.vae.config.scaling_factor
                            
                            # 检查latents是否正常
                            if torch.isnan(latents).any() or torch.isinf(latents).any():
                                logger.warning("VAE编码产生异常值，跳过此批次")
                                continue
                        
                        # 添加噪声
                        noise = torch.randn_like(latents)
                        timesteps = torch.randint(
                            0, self.pipeline.scheduler.config.num_train_timesteps,
                            (latents.shape[0],), device=self.device
                        )
                        noisy_latents = self.pipeline.scheduler.add_noise(latents, noise, timesteps)
                        
                        # 检查噪声数据
                        if torch.isnan(noisy_latents).any() or torch.isinf(noisy_latents).any():
                            logger.warning("噪声添加后产生异常值，跳过此批次")
                            continue
                        
                        # 文本编码
                        with torch.no_grad():
                            # 主要文本编码器
                            text_inputs = self.pipeline.tokenizer(
                                prompts,
                                padding="max_length",
                                max_length=77,
                                truncation=True,
                                return_tensors="pt"
                            ).to(self.device)
                            
                            text_inputs_2 = self.pipeline.tokenizer_2(
                                prompts,
                                padding="max_length", 
                                max_length=77,
                                truncation=True,
                                return_tensors="pt"
                            ).to(self.device)
                            
                            # 获取文本嵌入
                            text_embeds_1 = self.pipeline.text_encoder(**text_inputs).last_hidden_state
                            text_embeds_2 = self.pipeline.text_encoder_2(**text_inputs_2).last_hidden_state
                            pooled_embeds = self.pipeline.text_encoder_2(**text_inputs_2).text_embeds
                            
                            # 拼接文本嵌入
                            encoder_hidden_states = torch.cat([text_embeds_1, text_embeds_2], dim=-1)
                            
                            # time_ids (SDXL特定)
                            time_ids = torch.tensor(
                                [self.train_config["image_size"], self.train_config["image_size"], 
                                 0, 0, self.train_config["image_size"], self.train_config["image_size"]], 
                                dtype=self.dtype, device=self.device
                            ).repeat(latents.shape[0], 1)
                        
                        # UNet预测噪声
                        noise_pred = self.pipeline.unet(
                            noisy_latents,
                            timesteps,
                            encoder_hidden_states=encoder_hidden_states,
                            added_cond_kwargs={"text_embeds": pooled_embeds, "time_ids": time_ids}
                        ).sample
                        
                        # 计算损失
                        loss = F.mse_loss(noise_pred, noise)
                        
                        # NaN检测和处理
                        if torch.isnan(loss) or torch.isinf(loss):
                            logger.warning(f"检测到异常损失值: {loss.item()}, 跳过此批次")
                            continue
                        
                        # 检查输入数据的有效性
                        if torch.isnan(noise_pred).any() or torch.isnan(noise).any():
                            logger.warning("检测到NaN在预测或目标中，跳过此批次")
                            continue
                        
                        # 反向传播
                        self.accelerator.backward(loss)
                        
                        # 检查梯度
                        if self.accelerator.sync_gradients:
                            # 检查梯度是否包含NaN
                            grad_norm = 0.0
                            nan_grad_count = 0
                            total_params = 0
                            
                            if hasattr(self.lora_layers, 'parameters'):
                                params_to_check = list(self.lora_layers.parameters())
                            else:
                                params_to_check = trainable_params
                            
                            for param in params_to_check:
                                if param.grad is not None:
                                    total_params += 1
                                    param_norm = param.grad.data.norm(2)
                                    if torch.isnan(param_norm) or torch.isinf(param_norm):
                                        nan_grad_count += 1
                                        param.grad.data.zero_()  # 清零异常梯度
                                    else:
                                        grad_norm += param_norm.item() ** 2
                            
                            grad_norm = grad_norm ** (1. / 2)
                            
                            if nan_grad_count > 0:
                                logger.warning(f"发现 {nan_grad_count}/{total_params} 个参数的梯度异常，已清零")
                            
                            # 梯度裁剪 - 使用更保守的阈值
                            if grad_norm > 0:
                                if hasattr(self.lora_layers, 'parameters'):
                                    self.accelerator.clip_grad_norm_(self.lora_layers.parameters(), self.train_config["max_grad_norm"])
                                else:
                                    self.accelerator.clip_grad_norm_(trainable_params, self.train_config["max_grad_norm"])
                        
                        optimizer.step()
                        scheduler.step()
                        optimizer.zero_grad()
                    
                    # 记录损失
                    current_loss = loss.item()
                    epoch_losses.append(current_loss)
                    
                    # 内存监控（每10步检查一次）
                    if global_step % 10 == 0 and torch.cuda.is_available():
                        memory_allocated = torch.cuda.memory_allocated() / (1024**3)
                        memory_reserved = torch.cuda.memory_reserved() / (1024**3)
                        
                        if memory_allocated > 6.0:  # 如果内存使用超过6GB，发出警告
                            logger.warning(f"GPU内存使用过高: {memory_allocated:.2f}GB / 8.00GB")
                            torch.cuda.empty_cache()  # 清理缓存
                    
                    # 更新进度条
                    current_lr = scheduler.get_last_lr()[0] if hasattr(scheduler, 'get_last_lr') else self.train_config["learning_rate"]
                    progress_bar.set_postfix({
                        'loss': f"{current_loss:.4f}",
                        'lr': f"{current_lr:.2e}",
                        'mem': f"{torch.cuda.memory_allocated() / (1024**3):.1f}GB" if torch.cuda.is_available() else "N/A"
                    })
                    
                    # 保存检查点
                    if global_step > 0 and global_step % self.train_config["save_steps"] == 0:
                        self.save_lora_checkpoint(output_dir, global_step)
                    
                    global_step += 1
                    
                except Exception as e:
                    logger.error(f"训练步骤失败: {e}")
                    continue
            
            # 记录epoch损失
            avg_loss = np.mean(epoch_losses) if epoch_losses else 0
            losses.append(avg_loss)
            
            logger.info(f"Epoch {epoch+1} 完成，平均损失: {avg_loss:.4f}")
            
            # 保存epoch检查点
            self.save_lora_checkpoint(output_dir, f"epoch_{epoch+1}")
        
        # 保存最终模型
        self.save_lora_checkpoint(output_dir, "final")
        
        # 可视化训练过程
        self.plot_training_loss(losses, output_dir)
        
        logger.info("LoRA训练完成！")
    
    def save_lora_checkpoint(self, output_dir, step):
        """保存LoRA检查点"""
        try:
            checkpoint_dir = os.path.join(output_dir, f"checkpoint-{step}")
            os.makedirs(checkpoint_dir, exist_ok=True)
            
            # 保存LoRA权重 - 兼容不同实现
            try:
                if hasattr(self.lora_layers, 'state_dict'):
                    # 如果有state_dict方法
                    lora_state_dict = self.accelerator.unwrap_model(self.lora_layers).state_dict()
                    save_file(lora_state_dict, os.path.join(checkpoint_dir, "adapter_model.safetensors"))
                else:
                    # 如果是参数列表，保存UNet的权重
                    unet_state_dict = {}
                    for name, param in self.pipeline.unet.named_parameters():
                        if param.requires_grad:
                            unet_state_dict[name] = param.data.clone()
                    
                    if unet_state_dict:
                        save_file(unet_state_dict, os.path.join(checkpoint_dir, "adapter_model.safetensors"))
                        logger.info(f"保存了 {len(unet_state_dict)} 个可训练参数")
                    else:
                        logger.warning("没有找到可训练参数")
            except Exception as e:
                logger.warning(f"保存LoRA权重失败: {e}")
                # 尝试保存整个UNet状态
                torch.save(self.pipeline.unet.state_dict(), os.path.join(checkpoint_dir, "unet_backup.pt"))
            
            # 保存配置
            config = {
                "lora_config": self.lora_config,
                "train_config": self.train_config,
                "model_id": self.model_id
            }
            
            with open(os.path.join(checkpoint_dir, "adapter_config.json"), 'w') as f:
                json.dump(config, f, indent=2)
            
            logger.info(f"LoRA检查点已保存: {checkpoint_dir}")
            
        except Exception as e:
            logger.error(f"保存检查点失败: {e}")
            import traceback
            traceback.print_exc()
    
    def plot_training_loss(self, losses, output_dir):
        """绘制训练损失曲线"""
        plt.figure(figsize=(10, 6))
        plt.plot(losses, 'b-', linewidth=2)
        plt.title('LoRA训练损失曲线', fontsize=16)
        plt.xlabel('Epoch', fontsize=12)
        plt.ylabel('Loss', fontsize=12)
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        
        plt.savefig(os.path.join(output_dir, "training_loss.png"), dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info("训练损失曲线已保存")
    
    def generate_with_lora(self, prompt, lora_path, output_dir="output/lora_generated", num_images=1):
        """使用训练好的LoRA生成图像"""
        logger.info(f"使用LoRA生成图像: {prompt}")
        
        # 初始化pipeline
        if not self.pipeline:
            self.initialize_pipeline()
        
        # 加载LoRA权重
        self.load_lora_weights(lora_path)
        
        os.makedirs(output_dir, exist_ok=True)
        
        # 创建负面提示词
        prompt_processor = OptimizedPromptProcessor()
        negative_prompt = prompt_processor.create_negative_prompt()
        
        images = []
        
        for i in range(num_images):
            try:
                logger.info(f"生成第 {i+1}/{num_images} 张图像...")
                
                with torch.no_grad():
                    image = self.pipeline(
                        prompt=prompt,
                        negative_prompt=negative_prompt,
                        num_inference_steps=self.train_config["num_inference_steps"],
                        guidance_scale=self.train_config["guidance_scale"],
                        height=self.train_config["image_size"],
                        width=self.train_config["image_size"],
                        generator=torch.Generator(device=self.device).manual_seed(42 + i)
                    ).images[0]
                
                images.append(image)
                
                # 保存图像
                timestamp = __import__('datetime').datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"lora_generated_{timestamp}_{i+1}.png"
                image_path = os.path.join(output_dir, filename)
                image.save(image_path)
                
                logger.info(f"图像已保存: {image_path}")
                
            except Exception as e:
                logger.error(f"生成图像失败: {e}")
        
        logger.info(f"LoRA生成完成，共生成 {len(images)} 张图像")
        return images
    
    def load_lora_weights(self, lora_path):
        """加载LoRA权重"""
        try:
            # 查找adapter_model.safetensors文件
            if os.path.isdir(lora_path):
                adapter_file = os.path.join(lora_path, "adapter_model.safetensors")
            else:
                adapter_file = lora_path
            
            if not os.path.exists(adapter_file):
                raise FileNotFoundError(f"LoRA权重文件不存在: {adapter_file}")
            
            # 设置LoRA层
            self.setup_lora()
            
            # 加载权重
            state_dict = load_file(adapter_file)
            self.lora_layers.load_state_dict(state_dict)
            
            logger.info(f"LoRA权重加载成功: {adapter_file}")
            
        except Exception as e:
            logger.error(f"加载LoRA权重失败: {e}")
            raise

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="刺绣LoRA微调器")
    parser.add_argument("--mode", type=str, choices=["train", "generate"], required=True)
    parser.add_argument("--data_dir", type=str, default="data/图像层")
    parser.add_argument("--knowledge_dir", type=str, default="data/知识层1")
    parser.add_argument("--output_dir", type=str, default="output/lora_models")
    parser.add_argument("--lora_path", type=str, help="LoRA模型路径（生成模式）")
    parser.add_argument("--prompt", type=str, default="traditional Chinese crane embroidery, gold threads, imperial court rank badge")
    parser.add_argument("--num_images", type=int, default=1)
    parser.add_argument("--image_size", type=int, default=256, help="训练分辨率 (256=快4倍, 512=标准, 1024=高质量)")
    
    args = parser.parse_args()
    
    trainer = EmbroideryLoRATrainer(image_size=args.image_size)
    
    if args.mode == "train":
        trainer.train(args.data_dir, args.knowledge_dir, args.output_dir)
    elif args.mode == "generate":
        if not args.lora_path:
            logger.error("生成模式需要指定--lora_path")
        else:
            trainer.generate_with_lora(args.prompt, args.lora_path, num_images=args.num_images) 