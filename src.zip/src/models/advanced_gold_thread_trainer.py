#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from PIL import Image
import logging
import json
import cv2
from tqdm import tqdm
import matplotlib.pyplot as plt
from torch.utils.data import Dataset, DataLoader
from diffusers import StableDiffusionXLPipeline, UNet2DConditionModel, DDPMScheduler
from transformers import CLIPTextModel, CLIPTokenizer
import torchvision.transforms as T
from accelerate import Accelerator
import lpips
import re
import pandas as pd

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class KnowledgeProcessor:
    """知识层处理器 - 提取和翻译知识描述"""
    
    def __init__(self):
        # 中英文映射词典 - 全面扩展版本
        self.translation_dict = {
            # 官品等级
            "一品": "first rank", "二品": "second rank", "三品": "third rank", 
            "四品": "fourth rank", "五品": "fifth rank", "六品": "sixth rank",
            "七品": "seventh rank", "八品": "eighth rank", "九品": "ninth rank",
            
            # 文武官
            "文官": "civil official", "武官": "military official",
            
            # 动物名称
            "仙鹤": "crane", "锦鸡": "golden pheasant", "孔雀": "peacock",
            "云雁": "wild goose", "白鹇": "silver pheasant", "鹭鸶": "egret",
            "鸂鶒": "mandarin duck", "鹌鹑": "quail", "练鹊": "magpie",
            "麒麟": "qilin", "狮子": "lion", "豹子": "leopard",
            "虎": "tiger", "熊": "bear", "彪纹": "tiger stripes", "獬豸": "xiezhi",
            "犀牛": "rhinoceros", "海马": "seahorse",
            
            # 动物姿态
            "立翅向日": "standing with wings spread toward the sun",
            "回首望日": "looking back at the sun",
            "展翅": "spreading wings", "回首": "looking back",
            "立于": "standing on", "飞翔": "flying", "游泳": "swimming",
            "奔跑": "running", "蹲坐": "crouching", "昂首": "raising head",
            
            # 刺绣针法术语
            "平绣": "satin stitch", "打籽绣": "seed stitch", "盘金": "couching",
            "施金": "gold applique", "锁绣": "chain stitch", "贴金": "gold leaf application",
            "捻金线": "twisted gold thread", "勾勒轮廓": "outline stitching",
            "套针": "long and short stitch", "抢针": "split stitch",
            "散套": "irregular satin stitch", "齐针": "straight stitch",
            "切针": "cutting stitch", "滚针": "rolling stitch",
            "网绣": "net stitch", "纳纱": "gauze stitch",
            "十字绣": "cross stitch", "回针": "back stitch",
            
            # 工艺技法
            "绣制": "embroidered", "刺绣": "embroidery", "针法": "stitching technique",
            "绣工": "embroidery work", "手工": "handcrafted", "精细": "fine",
            "繁复": "intricate", "密布": "densely distributed",
            "层次分明": "distinct layers", "色彩丰富": "rich colors",
            "构图饱满": "full composition", "工艺精湛": "exquisite craftsmanship",
            
            # 材质和线材
            "金线": "gold thread", "银线": "silver thread", "丝线": "silk thread",
            "真丝": "pure silk", "金丝": "gold silk", "银丝": "silver silk",
            "棉线": "cotton thread", "麻线": "linen thread",
            "捻金线": "twisted gold thread", "扁金线": "flat gold thread",
            "米黄色丝线": "beige silk thread", "多彩丝线": "multicolored silk threads",
            
            # 颜色描述
            "金色": "golden", "红色": "red", "蓝色": "blue", "绿色": "green",
            "黄色": "yellow", "紫色": "purple", "黑色": "black", "白色": "white",
            "深褐色": "dark brown", "深青色": "dark cyan", "浅青色": "light cyan",
            "墨绿色": "dark green", "赭黄色": "ochre yellow", "粉色": "pink",
            "深色": "dark colored", "浅色": "light colored",
            
            # 纹样和图案
            "江崖海水纹": "river cliff and sea wave pattern",
            "立水纹": "standing wave pattern", "回纹": "meander pattern",
            "祥云": "auspicious clouds", "杂宝": "various treasures",
            "如意": "ruyi scepter", "方胜": "square victory pattern",
            "寿桃": "longevity peach", "牡丹花": "peony flower",
            "莲花": "lotus flower", "艾叶": "mugwort leaves",
            "书卷": "scroll", "珊瑚": "coral", "如意珠": "ruyi pearl",
            "蝙蝠": "bat", "团花": "circular flower pattern",
            
            # 边框和装饰
            "边框类型": "border type", "边饰": "border decoration",
            "无边框": "no border", "有边框": "with border",
            "江牙礁石": "jagged reef rocks", "翻滚": "rolling",
            "波涛汹涌": "surging waves", "点缀": "embellished with",
            
            # 文化语义相关
            "文化语义": "cultural semantics", "象征": "symbolizes",
            "寓意": "meaning", "祥瑞": "auspicious", "吉祥": "lucky",
            "富贵": "wealth and honor", "长寿": "longevity", "清廉": "integrity",
            "权威": "authority", "地位": "status", "品级": "rank",
            "品德高尚": "noble character", "才能卓越": "outstanding talent",
            "镇守一方": "guarding a region", "光明": "brightness",
            "皇恩": "imperial grace", "洪福齐天": "boundless good fortune",
            "福寿安康": "fortune, longevity and health",
            "官运亨通": "smooth official career",
            "连绵不断": "continuous and unending",
            "福寿绵长": "long-lasting fortune and longevity",
            "品行高洁": "noble conduct", "富贵吉祥": "wealth and good fortune",
            
            # 质量和特征描述
            "高质量": "high quality", "精美": "exquisite", "细腻": "delicate",
            "光泽": "lustrous", "立体": "three-dimensional", "层次": "layered",
            "饱满": "full", "均匀": "even", "流畅": "smooth",
            "华丽": "magnificent", "庄重": "solemn", "威严": "majestic",
            "传统": "traditional", "古典": "classical", "宫廷": "imperial court",
            "威武": "mighty", "优雅": "elegant", "神圣": "sacred",
            
            # 补子相关
            "补子": "rank badge", "官服": "official robe", "朝服": "court dress",
            "中心纹样": "central pattern", "中心主体": "central motif",
            "背景地": "background field", "芝麻地": "sesame seed ground",
            "打籽绣地": "seed stitch ground",
            
            # 位置和方向
            "上方": "above", "下方": "below", "中心": "center",
            "边缘": "edge", "轮廓": "outline", "底部": "bottom",
            "其间": "among them", "其上": "on top", "之上": "above",
            "面部": "facial", "腹部": "belly", "背鳍": "dorsal fin",
            "鬃毛": "mane", "翅膀": "wings", "爪部": "claws",
            
            # 工艺质量描述
            "极为精细": "extremely fine", "极具特色": "highly distinctive",
            "琳琅满目": "dazzling array", "美好祝愿": "good wishes",
            "寄托": "entrusts", "特别是": "especially",
            "包括": "including", "以及": "as well as"
        }
    
    def extract_knowledge_from_rtf(self, rtf_path):
        """从RTF文件提取知识信息 - 修复版本，直接解析JSON"""
        if not os.path.exists(rtf_path):
            return {}
        
        try:
            with open(rtf_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
            
            # 直接解析JSON内容（RTF文件实际是JSON格式）
            try:
                knowledge_data = json.loads(content)
                return knowledge_data
            except json.JSONDecodeError:
                # 如果不是纯JSON，尝试提取JSON部分
                json_match = re.search(r'\{.*\}', content, re.DOTALL)
                if json_match:
                    json_str = json_match.group()
                    # 清理可能的RTF格式字符
                    json_str = self._clean_rtf_content(json_str)
                    try:
                        knowledge_data = json.loads(json_str)
                        return knowledge_data
                    except:
                        pass
            
            return {}
        except Exception as e:
            logger.warning(f"解析RTF文件失败 {rtf_path}: {e}")
            return {}
    
    def _clean_rtf_content(self, text):
        """清理RTF内容中的格式字符"""
        # 移除RTF控制字符
        text = re.sub(r'\\[a-z]+\d*', '', text)
        text = re.sub(r'\\[^a-z]', '', text)
        text = re.sub(r'\{|\}', '', text)
        
        # 清理Unicode转义序列
        replacements = {
            r'\\u(\d{4,5})': lambda m: chr(int(m.group(1))),
            r'\\uc0\\u(\d{4,5})': lambda m: chr(int(m.group(1))),
        }
        
        for pattern, replacement in replacements.items():
            text = re.sub(pattern, replacement, text)
        
        return text
    
    def translate_to_english(self, chinese_text):
        """将中文描述翻译成英文"""
        if not chinese_text:
            return ""
        
        # 简单的词典翻译
        english_text = chinese_text
        for chinese, english in self.translation_dict.items():
            english_text = english_text.replace(chinese, english)
        
        return english_text
    
    def create_detailed_prompt(self, category, knowledge_data, craft_data=None):
        """创建详细的英文提示词，整合知识层和工艺层信息 - 全面增强版本"""
        prompts = []
        
        # 基础类别翻译
        base_prompt = self.translate_to_english(category)
        prompts.append(base_prompt)
        
        # 添加知识层信息 - 深度翻译所有字段
        if knowledge_data:
            # 遍历所有知识层字段并翻译
            for key, value in knowledge_data.items():
                if isinstance(value, dict):
                    # 处理嵌套字典（如动物特征、中心纹样等）
                    for sub_key, sub_value in value.items():
                        if isinstance(sub_value, str) and sub_value.strip():
                            translated_key = self.translate_to_english(sub_key)
                            translated_value = self.translate_to_english(sub_value)
                            # 添加所有翻译内容，不管是否有变化
                            prompts.append(f"{translated_key} {translated_value}")
                elif isinstance(value, str) and value.strip():
                    # 处理字符串值 - 特别处理文化语义
                    translated_key = self.translate_to_english(key)
                    
                    if key == "文化语义" and len(value) > 50:
                        # 文化语义内容较长，进行分段翻译
                        # 按句号分割，逐句翻译
                        sentences = value.split('。')
                        for sentence in sentences:
                            if sentence.strip():
                                translated_sentence = self.translate_to_english(sentence.strip())
                                if translated_sentence:
                                    prompts.append(translated_sentence)
                    else:
                        # 普通字段翻译
                        translated_value = self.translate_to_english(value)
                        prompts.append(f"{translated_key} {translated_value}")
        
        # 添加工艺层信息 - 详细描述包括针法
        if craft_data:
            craft_terms = []
            
            # 处理针法信息（从CSV数据中提取）
            if 'stitch_type' in craft_data:
                stitch_types = craft_data['stitch_type']
                if isinstance(stitch_types, str):
                    # 分割针法字符串
                    stitches = [s.strip() for s in stitch_types.replace(',', ' ').split() if s.strip()]
                    for stitch in stitches:
                        translated_stitch = self.translate_to_english(stitch)
                        if translated_stitch and translated_stitch != stitch:
                            craft_terms.append(translated_stitch)
                        else:
                            # 如果没有翻译，添加原文
                            craft_terms.append(f"traditional {stitch} technique")
            
            # 根据工艺参数生成描述性词汇
            density = craft_data.get('density', 0.5)
            complexity = craft_data.get('complexity', 0.5)
            thread_thickness = craft_data.get('thread_thickness', 0.5)
            
            if density > 0.8:
                craft_terms.append("very high density stitching")
            elif density > 0.6:
                craft_terms.append("high density stitching")
            elif density > 0.4:
                craft_terms.append("medium density stitching")
            else:
                craft_terms.append("fine density stitching")
            
            if complexity > 0.8:
                craft_terms.append("extremely complex pattern work")
            elif complexity > 0.6:
                craft_terms.append("complex pattern work")
            elif complexity > 0.4:
                craft_terms.append("moderate pattern complexity")
            else:
                craft_terms.append("simple elegant patterns")
            
            if thread_thickness > 0.7:
                craft_terms.append("thick lustrous gold threads")
            elif thread_thickness > 0.4:
                craft_terms.append("medium gold threads")
            else:
                craft_terms.append("fine delicate gold threads")
            
            # 添加其他工艺特征
            if craft_data.get('angle_variance', 0) > 0.6:
                craft_terms.append("varied stitch angles")
            if craft_data.get('speed_variance', 0) > 0.6:
                craft_terms.append("dynamic stitching rhythm")
            if craft_data.get('force_variance', 0) > 0.6:
                craft_terms.append("varied thread tension")
            
            # 根据可行性评分添加质量描述
            feasibility = craft_data.get('feasibility', 1.0)
            if feasibility >= 0.9:
                craft_terms.append("masterful craftsmanship")
            elif feasibility >= 0.7:
                craft_terms.append("skilled workmanship")
            
            prompts.extend(craft_terms)
        
        # 添加基础刺绣工艺描述
        base_craft_terms = [
            "traditional Chinese gold thread embroidery",
            "imperial court rank badge",
            "fine silk threads",
            "intricate needlework",
            "metallic gold threads",
            "detailed stitching patterns",
            "high quality craftsmanship",
            "ornate decorative design"
        ]
        prompts.extend(base_craft_terms)
        
        # 组合成完整提示词
        full_prompt = ", ".join(prompts)
        
        # 适当增加长度限制，允许更多信息
        if len(full_prompt) > 400:
            full_prompt = full_prompt[:400]
        
        logger.debug(f"生成的详细提示词: {full_prompt}")
        
        return full_prompt

class EmbroideryFeatureExtractor(nn.Module):
    """刺绣特征提取器 - 修复版本"""
    
    def __init__(self, feature_dim=512):
        super().__init__()
        self.feature_dim = feature_dim
        
        # 纹理特征提取
        self.texture_conv = nn.Sequential(
            nn.Conv2d(3, 64, 3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, 3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d(8),
            nn.Flatten(),
            nn.Linear(128 * 64, feature_dim)
        )
        
        # 工艺特征编码
        self.craft_encoder = nn.Sequential(
            nn.Linear(6, 128),  # 6个工艺参数
            nn.ReLU(),
            nn.Linear(128, feature_dim)
        )
        
        # 知识特征编码
        self.knowledge_encoder = nn.Sequential(
            nn.Linear(768, 512),  # CLIP特征维度
            nn.ReLU(),
            nn.Linear(512, feature_dim)
        )
        
        # 多模态融合
        self.fusion = nn.Sequential(
            nn.Linear(feature_dim * 3, feature_dim * 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(feature_dim * 2, feature_dim)
        )
    
    def forward(self, image, craft_params, knowledge_embed):
        """
        前向传播 - 确保数据类型一致
        """
        # 确保所有输入具有相同的数据类型
        device = image.device
        dtype = image.dtype
        
        craft_params = craft_params.to(device=device, dtype=dtype)
        knowledge_embed = knowledge_embed.to(device=device, dtype=dtype)
        
        # 提取各模态特征
        texture_feat = self.texture_conv(image)
        craft_feat = self.craft_encoder(craft_params)
        knowledge_feat = self.knowledge_encoder(knowledge_embed)
        
        # 多模态融合
        combined = torch.cat([texture_feat, craft_feat, knowledge_feat], dim=1)
        fused_feat = self.fusion(combined)
        
        return fused_feat

class AdvancedEmbroideryDataset(Dataset):
    """高级刺绣数据集 - 整合图像层、知识层、工艺层，支持预翻译，只使用有标注的数据"""
    
    def __init__(self, data_dir, knowledge_dir, craft_dir, image_size=512, max_samples=None, 
                 use_pretranslated=True, pretranslated_dir="data/pretranslated"):
        self.data_dir = data_dir
        self.knowledge_dir = knowledge_dir
        self.craft_dir = craft_dir
        self.image_size = image_size
        self.use_pretranslated = use_pretranslated
        self.pretranslated_dir = pretranslated_dir
        self.samples = []
        
        # 初始化知识处理器
        self.knowledge_processor = KnowledgeProcessor()
        
        # 加载预翻译数据
        self.pretranslated_prompts = {}
        if use_pretranslated:
            self._load_pretranslated_data()
        
        # 数据增强
        self.transform = T.Compose([
            T.Resize((image_size, image_size)),
            T.RandomHorizontalFlip(p=0.5),
            T.RandomRotation(degrees=15),
            T.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1),
            T.ToTensor(),
            T.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
        ])
        
        # 根据是否使用预翻译选择不同的加载策略
        if use_pretranslated and self.pretranslated_prompts:
            self._load_annotated_samples_only()  # 只加载有标注的样本
        else:
            self._load_all_samples()  # 加载所有样本（旧方式）
        
        if max_samples and max_samples < len(self.samples):
            self.samples = self.samples[:max_samples]
        
        translation_status = "预翻译模式（仅标注数据）" if use_pretranslated else "实时翻译模式（全部数据）"
        logger.info(f"高级数据集加载完成，共 {len(self.samples)} 个样本（{translation_status}）")
    
    def _load_pretranslated_data(self):
        """加载预翻译数据"""
        prompts_file = os.path.join(self.pretranslated_dir, "unified_prompts.json")
        
        if os.path.exists(prompts_file):
            try:
                with open(prompts_file, 'r', encoding='utf-8') as f:
                    self.pretranslated_prompts = json.load(f)
                logger.info(f"✅ 加载预翻译数据: {len(self.pretranslated_prompts)} 个提示词")
                
                # 统计有工艺数据的提示词数量
                with_craft_count = sum(1 for prompt in self.pretranslated_prompts.values() 
                                     if prompt.get("craft_data") is not None)
                logger.info(f"   其中包含工艺数据: {with_craft_count} 个")
                
            except Exception as e:
                logger.warning(f"⚠️  加载预翻译数据失败: {e}，将使用实时翻译")
                self.use_pretranslated = False
        else:
            logger.warning(f"⚠️  预翻译文件不存在: {prompts_file}，将使用实时翻译")
            self.use_pretranslated = False
    
    def _load_annotated_samples_only(self):
        """只加载有预翻译标注的样本 - 高效训练模式"""
        logger.info("🎯 只加载有标注的样本（高效训练模式）...")
        
        annotated_count = 0
        missing_image_count = 0
        
        for knowledge_key, prompt_info in self.pretranslated_prompts.items():
            try:
                # 从知识层键名推断图像路径
                # 知识层键名格式: "一品文官 仙鹤_一品文官 仙鹤描述1"
                category = prompt_info.get("category", "")
                
                # 提取文件编号
                file_number = None
                if '_' in knowledge_key:
                    file_part = knowledge_key.split('_')[-1]  # "一品文官 仙鹤描述1"
                    number_match = re.search(r'(\d+)$', file_part)
                    if number_match:
                        file_number = number_match.group(1)
                
                if not file_number:
                    continue
                
                # 构建可能的图像路径
                # 图像文件名格式通常是: "一品文官仙鹤1.jpg" 或 "一品文官 仙鹤1.jpg"
                possible_image_names = [
                    f"{category.replace(' ', '')}{file_number}.jpg",
                    f"{category.replace(' ', '')}{file_number}.png", 
                    f"{category}{file_number}.jpg",
                    f"{category}{file_number}.png",
                    f"{category.replace('_', ' ')}{file_number}.jpg",
                    f"{category.replace('_', ' ')}{file_number}.png"
                ]
                
                # 在图像目录中查找对应的图像文件
                image_path = None
                category_dir = os.path.join(self.data_dir, category.replace('_', ' '))
                
                if os.path.exists(category_dir):
                    for image_name in possible_image_names:
                        potential_path = os.path.join(category_dir, image_name)
                        if os.path.exists(potential_path):
                            image_path = potential_path
                            break
                
                # 如果在类别目录中没找到，尝试在所有子目录中搜索
                if not image_path:
                    for root, dirs, files in os.walk(self.data_dir):
                        for image_name in possible_image_names:
                            if image_name in files:
                                image_path = os.path.join(root, image_name)
                                break
                        if image_path:
                            break
                
                if image_path and os.path.exists(image_path):
                    # 构建样本
                    sample = {
                        'image_path': image_path,
                        'category': category,
                        'knowledge_key': knowledge_key,
                        'prompt_info': prompt_info,
                        'has_annotation': True
                    }
                    
                    self.samples.append(sample)
                    annotated_count += 1
                    
                    if annotated_count % 20 == 0:
                        logger.info(f"  已加载 {annotated_count} 个标注样本...")
                else:
                    missing_image_count += 1
                    logger.debug(f"  未找到图像文件: {knowledge_key}")
                    
            except Exception as e:
                logger.warning(f"处理标注样本失败 {knowledge_key}: {e}")
        
        logger.info(f"✅ 标注样本加载完成:")
        logger.info(f"   成功加载: {annotated_count} 个")
        logger.info(f"   缺失图像: {missing_image_count} 个")
        logger.info(f"   总标注数: {len(self.pretranslated_prompts)} 个")
    
    def _load_all_samples(self):
        """加载所有样本 - 传统模式（包括无标注数据）"""
        logger.info("📁 加载所有样本（传统模式）...")
        
        for root, dirs, files in os.walk(self.data_dir):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    # 获取类别信息
                    rel_path = os.path.relpath(root, self.data_dir)
                    category = rel_path.replace(os.sep, '_')
                    
                    # 查找对应的知识文件和工艺文件
                    knowledge_files = self._find_knowledge_files(category, file)
                    craft_path = self._find_craft_file(category, file)
                    
                    # 构建样本
                    sample = {
                        'image_path': os.path.join(root, file),
                        'category': category,
                        'knowledge_files': knowledge_files,
                        'craft_path': craft_path,
                        'has_annotation': len(knowledge_files) > 0
                    }
                    
                    self.samples.append(sample)
    
        # 统计标注情况
        annotated_count = sum(1 for s in self.samples if s['has_annotation'])
        logger.info(f"✅ 全部样本加载完成:")
        logger.info(f"   总样本数: {len(self.samples)} 个")
        logger.info(f"   有标注: {annotated_count} 个")
        logger.info(f"   无标注: {len(self.samples) - annotated_count} 个")
        
        if annotated_count < len(self.samples) * 0.5:
            logger.warning("⚠️  超过50%的样本没有标注，建议使用预翻译模式以提高训练效率")
    
    def __getitem__(self, idx):
        sample = self.samples[idx]
        
        try:
            # 加载图像
            image = Image.open(sample['image_path']).convert('RGB')
            image = self.transform(image)
            
            # 根据样本类型选择不同的处理方式
            if 'prompt_info' in sample:
                # 有预翻译标注的样本
                prompt_info = sample['prompt_info']
                detailed_prompt = prompt_info['detailed_prompt']
                
                # 从预翻译信息中获取特征数据
                knowledge_data = prompt_info.get('translated_data', {})
                craft_data = prompt_info.get('craft_data', {})
                
                # 生成特征向量（简化版本）
                knowledge_feat = np.random.randn(768).astype(np.float32)  # 模拟CLIP特征
                
                # 从工艺数据中提取参数
                if craft_data:
                    craft_params = np.array([
                        craft_data.get('density', 0.5),
                        craft_data.get('complexity', 0.5),
                        0.5, 0.5, 0.5, 0.5  # 默认参数
                    ], dtype=np.float32)
                else:
                    craft_params = np.array([0.5, 0.5, 0.5, 0.5, 0.5, 0.5], dtype=np.float32)
                
                return {
                    'image': image,
                    'category': sample['category'],
                    'detailed_prompt': detailed_prompt,
                    'knowledge_features': torch.from_numpy(knowledge_feat),
                    'craft_params': torch.from_numpy(craft_params),
                    'knowledge_data': knowledge_data,
                    'craft_data': craft_data,
                    'is_pretranslated': True,
                    'has_annotation': True
                }
            
            else:
                # 传统样本处理方式
                detailed_prompt = None
                if self.use_pretranslated:
                    detailed_prompt = self._find_pretranslated_prompt(
                        sample['category'], 
                        os.path.basename(sample['image_path'])
                    )
                
                # 如果没有预翻译，则实时翻译
                if detailed_prompt is None:
                    # 加载知识特征和数据
                    knowledge_feat, knowledge_data = self._load_knowledge_features(sample.get('knowledge_files', []))
                    
                    # 加载工艺参数和数据
                    craft_params, craft_data = self._load_craft_params(sample.get('craft_path'))
                    
                    # 创建详细的英文提示词（实时翻译）
                    detailed_prompt = self.knowledge_processor.create_detailed_prompt(
                        sample['category'], knowledge_data, craft_data
                    )
                else:
                    # 使用预翻译，仍需加载特征数据用于模型训练
                    knowledge_feat, knowledge_data = self._load_knowledge_features(sample.get('knowledge_files', []))
                    craft_params, craft_data = self._load_craft_params(sample.get('craft_path'))
                
                return {
                    'image': image,
                    'category': sample['category'],
                    'detailed_prompt': detailed_prompt,
                    'knowledge_features': torch.from_numpy(knowledge_feat),
                    'craft_params': torch.from_numpy(craft_params),
                    'knowledge_data': knowledge_data,
                    'craft_data': craft_data,
                    'is_pretranslated': detailed_prompt is not None and self.use_pretranslated,
                    'has_annotation': sample.get('has_annotation', False)
                }
                
        except Exception as e:
            logger.warning(f"加载样本失败 {sample['image_path']}: {e}")
            # 返回默认数据
            default_prompt = self.knowledge_processor.translate_to_english(sample['category'])
            return {
                'image': torch.zeros(3, self.image_size, self.image_size),
                'category': sample['category'],
                'detailed_prompt': default_prompt,
                'knowledge_features': torch.zeros(768),
                'craft_params': torch.zeros(6),
                'knowledge_data': {},
                'craft_data': {},
                'is_pretranslated': False,
                'has_annotation': False
            }
    
    def _find_knowledge_files(self, category, image_file):
        """查找对应的知识文件"""
        knowledge_files = []
        
        # 在知识层目录中查找匹配的RTF文件
        knowledge_category_dir = os.path.join(self.knowledge_dir, category.replace('_', ' '))
        if os.path.exists(knowledge_category_dir):
            # 获取图像编号
            image_base = os.path.splitext(image_file)[0]
            image_number = re.search(r'(\d+)$', image_base)
            
            if image_number:
                number = image_number.group(1)
                # 查找对应编号的描述文件
                desc_file = f"{category.replace('_', ' ')}描述{number}.rtf"
                desc_path = os.path.join(knowledge_category_dir, desc_file)
                if os.path.exists(desc_path):
                    knowledge_files.append(desc_path)
        
        return knowledge_files
    
    def _find_craft_file(self, category, image_file):
        """查找对应的工艺文件"""
        base_name = os.path.splitext(image_file)[0]
        craft_file = os.path.join(self.craft_dir, category, base_name + '_craft.json')
        if os.path.exists(craft_file):
            return craft_file
        return None
    
    def _load_knowledge_features(self, knowledge_files):
        """加载知识特征"""
        all_knowledge = {}
        
        # 合并所有知识文件的信息
        for knowledge_file in knowledge_files:
            knowledge_data = self.knowledge_processor.extract_knowledge_from_rtf(knowledge_file)
            all_knowledge.update(knowledge_data)
        
        # 简化的知识编码为向量
        features = np.random.randn(768).astype(np.float32)  # 模拟CLIP特征
        return features, all_knowledge
    
    def _encode_knowledge(self, knowledge_data):
        """编码知识数据为特征向量"""
        # 简化的知识编码，实际应该用更复杂的方法
        features = np.random.randn(768).astype(np.float32)  # 模拟CLIP特征
        return features
    
    def _load_craft_params(self, craft_path):
        """加载工艺参数 - 增强版本，包括针法信息"""
        if craft_path and os.path.exists(craft_path):
            try:
                with open(craft_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                # 提取6个关键工艺参数
                params = [
                    data.get('density', 0.5),
                    data.get('complexity', 0.5),
                    data.get('angle_variance', 0.5),
                    data.get('speed_variance', 0.5),
                    data.get('force_variance', 0.5),
                    data.get('thread_thickness', 0.5)
                ]
                return np.array(params, dtype=np.float32), data
            except:
                pass
        
        # 如果没有JSON文件，尝试从CSV数据中查找对应的工艺信息
        craft_csv_path = os.path.join(self.craft_dir, "craft_summary.csv")
        if os.path.exists(craft_csv_path):
            try:
                df = pd.read_csv(craft_csv_path, encoding='utf-8')
                
                # 从图像路径提取样本ID
                if craft_path:
                    sample_id = os.path.basename(craft_path).replace('_craft.json', '')
                    # 查找匹配的行
                    matching_rows = df[df['sample_id'].str.contains(sample_id, na=False)]
                    
                    if not matching_rows.empty:
                        row = matching_rows.iloc[0]
                        # 构建工艺数据
                        craft_data = {
                            'stitch_type': row.get('stitch_type', ''),
                            'density': float(row.get('density', 0.5)) / 1000000,  # 归一化密度值
                            'complexity': float(row.get('complexity', 0.5)),
                            'feasibility': float(row.get('feasibility', 1.0)),
                            'angle_variance': 0.5,  # 默认值
                            'speed_variance': 0.5,  # 默认值
                            'force_variance': 0.5,  # 默认值
                            'thread_thickness': 0.5  # 默认值
                        }
                        
                        # 提取参数数组
                        params = [
                            craft_data['density'],
                            craft_data['complexity'],
                            craft_data['angle_variance'],
                            craft_data['speed_variance'],
                            craft_data['force_variance'],
                            craft_data['thread_thickness']
                        ]
                        
                        return np.array(params, dtype=np.float32), craft_data
            except Exception as e:
                logger.debug(f"从CSV加载工艺数据失败: {e}")
        
        # 返回默认参数
        default_params = np.array([0.5, 0.5, 0.5, 0.5, 0.5, 0.5], dtype=np.float32)
        default_data = {
            'stitch_type': '平绣,打籽绣',  # 默认针法
            'density': 0.5, 'complexity': 0.5, 'angle_variance': 0.5,
            'speed_variance': 0.5, 'force_variance': 0.5, 'thread_thickness': 0.5,
            'feasibility': 1.0
        }
        return default_params, default_data
    
    def __len__(self):
        return len(self.samples)
    
    def _find_pretranslated_prompt(self, category, image_file):
        """查找预翻译的提示词"""
        if not self.use_pretranslated:
            return None
        
        # 尝试多种匹配方式
        image_base = os.path.splitext(image_file)[0]
        
        # 方式1: 直接匹配 - 构建知识层键名
        # 从图像文件名提取编号
        number_match = re.search(r'(\d+)$', image_base)
        if number_match:
            file_number = number_match.group(1)
            # 构建知识层键名: "一品文官 仙鹤_一品文官 仙鹤描述1"
            knowledge_key_candidate = f"{category}_{category}描述{file_number}"
            if knowledge_key_candidate in self.pretranslated_prompts:
                return self.pretranslated_prompts[knowledge_key_candidate]["detailed_prompt"]
        
        # 方式2: 模糊匹配
        category_clean = category.replace('_', '').replace(' ', '')
        for key, prompt_info in self.pretranslated_prompts.items():
            if category_clean in key.replace('_', '').replace(' ', ''):
                return prompt_info["detailed_prompt"]
        
        # 方式3: 按类别匹配
        for key, prompt_info in self.pretranslated_prompts.items():
            if prompt_info["category"].replace('_', ' ') == category.replace('_', ' '):
                return prompt_info["detailed_prompt"]
        
        return None

class AdvancedGoldThreadTrainer:
    """高级金线刺绣训练器 - 修复版本"""
    
    def __init__(self, config_path=None):
        self.config = self._load_config(config_path)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
        plt.rcParams['axes.unicode_minus'] = False
        
        # 初始化组件
        self.pipeline = None
        self.feature_extractor = None
        self.accelerator = None
        self.lpips_loss = None
        self.dtype = torch.float32  # 强制使用float32避免类型问题
        
        logger.info(f"高级训练器初始化完成，设备: {self.device}, 数据类型: {self.dtype}")
    
    def _load_config(self, config_path):
        """加载配置"""
        default_config = {
            "model_id": "checkpoints/stable-diffusion-xl-base-1.0",  # 使用本地pipeline
            "learning_rate": 1e-4,
            "batch_size": 1,
            "num_epochs": 5,
            "save_steps": 100,
            "gradient_accumulation_steps": 8,
            "image_size": 512,
            "feature_dim": 512,
            "output_dir": "output/models/advanced",
            "max_samples": None,
            "use_mixed_precision": False,  # 强制禁用混合精度
            "loss_weights": {
                "mse": 1.0,
                "lpips": 0.3,
                "feature": 0.2,
                "consistency": 0.1
            }
        }
        
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                default_config.update(config)
        
        # 强制禁用混合精度
        default_config["use_mixed_precision"] = False
        
        return default_config
    
    def initialize_models(self, for_generation=False):
        """初始化模型 - 确保数据类型一致"""
        logger.info("初始化高级模型组件...")
        
        # 强制使用float32
        self.dtype = torch.float32
        
        if for_generation:
            # 生成模式：只初始化必要组件，不下载模型
            logger.info("生成模式：只初始化特征提取器...")
            self.feature_extractor = EmbroideryFeatureExtractor(
                feature_dim=self.config["feature_dim"]
            ).to(self.device, dtype=self.dtype)
            logger.info("特征提取器初始化完成")
            return
        
        # 训练模式：加载完整pipeline
        # 检查本地pipeline是否存在
        if not os.path.exists(self.config["model_id"]):
            logger.error(f"本地pipeline不存在: {self.config['model_id']}")
            logger.error("请先运行: python setup_local_pipeline.py")
            raise FileNotFoundError("本地pipeline未找到，请先设置")
        
        # 加载本地pipeline
        logger.info(f"从本地加载pipeline: {self.config['model_id']}")
        self.pipeline = StableDiffusionXLPipeline.from_pretrained(
            self.config["model_id"],
            torch_dtype=self.dtype,
            use_safetensors=True,
            local_files_only=True  # 强制只使用本地文件
        ).to(self.device)
        
        # 启用内存优化
        if self.device.type == "cuda":
            try:
                # 启用内存高效注意力
                self.pipeline.enable_attention_slicing()
                self.pipeline.enable_vae_slicing()
                logger.info("已启用内存优化")
            except Exception as e:
                logger.warning(f"内存优化启用失败: {e}")
        
        # 确保pipeline所有组件都是float32
        self.pipeline.unet = self.pipeline.unet.to(dtype=self.dtype)
        self.pipeline.vae = self.pipeline.vae.to(dtype=self.dtype)
        self.pipeline.text_encoder = self.pipeline.text_encoder.to(dtype=self.dtype)
        self.pipeline.text_encoder_2 = self.pipeline.text_encoder_2.to(dtype=self.dtype)
        
        # 初始化特征提取器
        self.feature_extractor = EmbroideryFeatureExtractor(
            feature_dim=self.config["feature_dim"]
        ).to(self.device, dtype=self.dtype)
        
        # 初始化加速器 - 禁用混合精度
        self.accelerator = Accelerator(
            gradient_accumulation_steps=self.config["gradient_accumulation_steps"],
            mixed_precision="no"  # 强制禁用混合精度
        )
        
        # 初始化LPIPS损失
        self.lpips_loss = lpips.LPIPS(net='alex').to(self.device)
        
        logger.info(f"高级模型组件初始化完成，数据类型: {self.dtype}")
    
    def prepare_dataset(self, data_dir, knowledge_dir, craft_dir):
        """准备数据集"""
        dataset = AdvancedEmbroideryDataset(
            data_dir=data_dir,
            knowledge_dir=knowledge_dir,
            craft_dir=craft_dir,
            image_size=self.config["image_size"],
            max_samples=self.config.get("max_samples")
        )
        
        dataloader = DataLoader(
            dataset,
            batch_size=self.config["batch_size"],
            shuffle=True,
            num_workers=0,  # 避免多进程问题
            pin_memory=False,
            drop_last=True
        )
        
        return dataloader
    
    def compute_advanced_loss(self, pred_noise, target_noise, pred_image, target_image, 
                            pred_features, target_features):
        """计算高级损失函数"""
        losses = {}
        
        # 确保所有张量都是float32
        pred_noise = pred_noise.float()
        target_noise = target_noise.float()
        pred_image = pred_image.float()
        target_image = target_image.float()
        pred_features = pred_features.float()
        target_features = target_features.float()
        
        # 1. 基础MSE损失
        losses['mse'] = F.mse_loss(pred_noise, target_noise)
        
        # 2. 感知损失 (LPIPS)
        if pred_image.shape[0] > 0 and not torch.all(pred_image == 0):
            # 确保输入图像在正确的范围内 [-1, 1]
            pred_img_lpips = pred_image * 2.0 - 1.0
            target_img_lpips = target_image * 2.0 - 1.0
            losses['lpips'] = self.lpips_loss(pred_img_lpips, target_img_lpips).mean()
        else:
            losses['lpips'] = torch.tensor(0.0, device=self.device, dtype=self.dtype)
        
        # 3. 特征一致性损失
        losses['feature'] = F.mse_loss(pred_features, target_features)
        
        # 4. 纹理一致性损失
        losses['consistency'] = self._texture_consistency_loss(pred_image, target_image)
        
        # 加权总损失
        total_loss = torch.tensor(0.0, device=self.device, dtype=self.dtype)
        for key, weight in self.config["loss_weights"].items():
            if key in losses:
                total_loss += weight * losses[key].float()
        
        losses['total'] = total_loss
        return losses
    
    def _texture_consistency_loss(self, pred_image, target_image):
        """纹理一致性损失"""
        # 确保输入是float32
        pred_image = pred_image.float()
        target_image = target_image.float()
        
        # 计算梯度
        def compute_gradients(img):
            grad_x = torch.abs(img[:, :, :, :-1] - img[:, :, :, 1:])
            grad_y = torch.abs(img[:, :, :-1, :] - img[:, :, 1:, :])
            return grad_x, grad_y
        
        pred_grad_x, pred_grad_y = compute_gradients(pred_image)
        target_grad_x, target_grad_y = compute_gradients(target_image)
        
        loss_x = F.mse_loss(pred_grad_x, target_grad_x)
        loss_y = F.mse_loss(pred_grad_y, target_grad_y)
        
        return loss_x + loss_y
    
    def train(self, data_dir, knowledge_dir="data/知识层1", craft_dir="output/results/craft"):
        """高级训练流程 - 整合图像层、知识层、工艺层"""
        logger.info("开始高级训练流程（整合图像层、知识层、工艺层，使用详细英文提示词）...")
        
        # 初始化模型
        self.initialize_models()
        
        # 准备数据
        train_dataloader = self.prepare_dataset(data_dir, knowledge_dir, craft_dir)
        
        if len(train_dataloader) == 0:
            logger.error("数据加载器为空")
            return
        
        # 设置可训练参数
        trainable_params = []
        
        # 训练UNet的部分层
        for name, param in self.pipeline.unet.named_parameters():
            if any(layer in name for layer in ['up_blocks.3', 'conv_out']):
                param.requires_grad = True
                trainable_params.append(param)
            else:
                param.requires_grad = False
        
        # 特征提取器参数
        for param in self.feature_extractor.parameters():
            param.requires_grad = True
            trainable_params.append(param)
        
        logger.info(f"可训练参数数量: {sum(p.numel() for p in trainable_params):,}")
        
        # 优化器
        optimizer = torch.optim.AdamW(
            trainable_params,
            lr=self.config["learning_rate"],
            weight_decay=0.01,
            betas=(0.9, 0.999)
        )
        
        # 学习率调度器
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=self.config["num_epochs"]
        )
        
        # 准备训练
        self.pipeline.unet, self.feature_extractor, optimizer, train_dataloader = self.accelerator.prepare(
            self.pipeline.unet, self.feature_extractor, optimizer, train_dataloader
        )
        
        # 训练循环
        global_step = 0
        all_losses = []
        
        for epoch in range(self.config["num_epochs"]):
            epoch_losses = {'total': [], 'mse': [], 'lpips': [], 'feature': [], 'consistency': []}
            
            progress_bar = tqdm(train_dataloader, desc=f"Epoch {epoch+1}/{self.config['num_epochs']}")
            
            for step, batch in enumerate(progress_bar):
                try:
                    with self.accelerator.accumulate(self.pipeline.unet):
                        # 获取数据并确保数据类型一致
                        images = batch['image'].to(self.device, dtype=self.dtype)
                        categories = batch['category']
                        knowledge_feat = batch['knowledge_features'].to(self.device, dtype=self.dtype)
                        craft_params = batch['craft_params'].to(self.device, dtype=self.dtype)
                        
                        # 提取多模态特征
                        embroidery_features = self.feature_extractor(images, craft_params, knowledge_feat)
                        
                        # VAE编码
                        with torch.no_grad():
                            latents = self.pipeline.vae.encode(images).latent_dist.sample()
                            latents = latents * self.pipeline.vae.config.scaling_factor
                            latents = latents.to(dtype=self.dtype)
                        
                        # 添加噪声
                        noise = torch.randn_like(latents, dtype=self.dtype)
                        # 修复时间步范围，确保不会越界 - 使用更保守的范围
                        num_train_timesteps = self.pipeline.scheduler.config.num_train_timesteps
                        # 使用更保守的范围，避免边界问题
                        max_timesteps = max(1, num_train_timesteps - 10)  # 留出安全边距
                        timesteps = torch.randint(
                            0, max_timesteps,
                            (latents.shape[0],), device=self.device
                        )
                        
                        # 调试信息（仅在第一个batch打印）
                        if global_step == 0:
                            logger.info(f"调度器配置: num_train_timesteps={num_train_timesteps}, 使用范围=[0, {max_timesteps})")
                        
                        noisy_latents = self.pipeline.scheduler.add_noise(latents, noise, timesteps)
                        
                        # 正确缩放输入
                        noisy_latents = self.pipeline.scheduler.scale_model_input(noisy_latents, timesteps)
                        
                        # 文本编码 - 使用详细的英文提示词
                        with torch.no_grad():
                            # 使用详细的英文提示词而不是简单的类别名
                            detailed_prompts = batch['detailed_prompt']
                            
                            text_inputs = self.pipeline.tokenizer(
                                detailed_prompts,  # 使用详细的英文提示词
                                padding="max_length",
                                max_length=77,
                                truncation=True,
                                return_tensors="pt"
                            ).to(self.device)
                            
                            text_inputs_2 = self.pipeline.tokenizer_2(
                                detailed_prompts,  # 使用详细的英文提示词
                                padding="max_length",
                                max_length=77,
                                truncation=True,
                                return_tensors="pt"
                            ).to(self.device)
                            
                            # 获取文本嵌入
                            text_embeds_1 = self.pipeline.text_encoder(**text_inputs).last_hidden_state
                            text_embeds_2 = self.pipeline.text_encoder_2(**text_inputs_2).last_hidden_state
                            pooled_embeds = self.pipeline.text_encoder_2(**text_inputs_2).text_embeds
                            
                            # 确保文本嵌入是float32
                            text_embeds_1 = text_embeds_1.to(dtype=self.dtype)
                            text_embeds_2 = text_embeds_2.to(dtype=self.dtype)
                            pooled_embeds = pooled_embeds.to(dtype=self.dtype)
                            
                            # 拼接文本嵌入
                            encoder_hidden_states = torch.cat([text_embeds_1, text_embeds_2], dim=-1)
                            
                            # 简化特征融合 - 避免维度不匹配
                            # 直接使用文本嵌入，不添加刺绣特征
                            enhanced_embeds = encoder_hidden_states
                            
                            # time_ids
                            time_ids = torch.tensor(
                                [self.config["image_size"], self.config["image_size"], 0, 0, 
                                 self.config["image_size"], self.config["image_size"]], 
                                dtype=self.dtype, device=self.device
                            ).repeat(latents.shape[0], 1)
                        
                        # UNet预测
                        noise_pred = self.pipeline.unet(
                            noisy_latents,
                            timesteps,
                            encoder_hidden_states=enhanced_embeds,
                            added_cond_kwargs={"text_embeds": pooled_embeds, "time_ids": time_ids}
                        ).sample
                        
                        # 解码预测图像用于感知损失
                        with torch.no_grad():
                            # 修复调度器索引越界问题 - 更安全的处理方式
                            try:
                                # 确保时间步在有效范围内
                                valid_timesteps = torch.clamp(timesteps, 0, max_timesteps - 1)
                                
                                pred_latents = self.pipeline.scheduler.step(
                                    noise_pred, valid_timesteps, noisy_latents
                                ).prev_sample
                                pred_images = self.pipeline.vae.decode(pred_latents / self.pipeline.vae.config.scaling_factor).sample
                                pred_images = (pred_images + 1) / 2  # 归一化到[0,1]
                                target_images = (images + 1) / 2
                            except (IndexError, RuntimeError) as e:
                                # 如果调度器步骤失败，使用简化的感知损失计算
                                logger.debug(f"调度器步骤失败，使用简化计算: {e}")
                                # 直接使用原始图像进行感知损失计算
                                pred_images = (images + 1) / 2  # 使用原始图像作为预测
                                target_images = (images + 1) / 2
                        
                        # 计算高级损失
                        losses = self.compute_advanced_loss(
                            noise_pred, noise, pred_images, target_images,
                            embroidery_features, embroidery_features
                        )
                        
                        # 反向传播
                        self.accelerator.backward(losses['total'])
                        
                        if self.accelerator.sync_gradients:
                            self.accelerator.clip_grad_norm_(trainable_params, 1.0)
                        
                        optimizer.step()
                        optimizer.zero_grad()
                    
                    # 记录损失
                    for key in epoch_losses:
                        if key in losses:
                            epoch_losses[key].append(losses[key].item())
                    
                    # 更新进度条 - 显示当前使用的详细提示词
                    current_loss = losses['total'].item()
                    sample_prompt = detailed_prompts[0][:50] + "..." if len(detailed_prompts[0]) > 50 else detailed_prompts[0]
                    progress_bar.set_postfix({
                        'loss': f"{current_loss:.4f}",
                        'prompt': sample_prompt
                    })
                    
                    # 不在中间步骤保存检查点，只在epoch结束时保存以节省硬盘空间
                    
                    global_step += 1
                    
                except Exception as e:
                    logger.error(f"训练步骤失败: {e}")
                    import traceback
                    traceback.print_exc()
                    continue
            
            # 更新学习率
            scheduler.step()
            
            # 记录epoch损失
            avg_losses = {k: np.mean(v) if v else 0 for k, v in epoch_losses.items()}
            all_losses.append(avg_losses)
            
            logger.info(f"Epoch {epoch+1} - Total: {avg_losses['total']:.4f}, "
                       f"MSE: {avg_losses['mse']:.4f}, LPIPS: {avg_losses['lpips']:.4f}")
            
            # 保存epoch检查点
            self.save_advanced_checkpoint(f"epoch_{epoch+1}", epoch_losses)
        
        # 可视化训练结果
        self.visualize_advanced_training(all_losses)
        
        logger.info("高级训练完成")
    
    def _has_trained_checkpoint(self):
        """检查是否有训练好的检查点"""
        output_dir = self.config["output_dir"]
        if not os.path.exists(output_dir):
            return False
        
        # 查找检查点
        for item in os.listdir(output_dir):
            if item.startswith("checkpoint-") and os.path.isdir(os.path.join(output_dir, item)):
                checkpoint_path = os.path.join(output_dir, item)
                # 检查是否有UNet权重文件
                if os.path.exists(os.path.join(checkpoint_path, "unet_state_dict.pt")):
                    return True
        return False
    
    def save_advanced_checkpoint(self, step_or_epoch, losses):
        """保存高级检查点 - 只保存权重文件，不保存完整pipeline以节省硬盘空间"""
        try:
            output_dir = os.path.join(self.config["output_dir"], f"checkpoint-{step_or_epoch}")
            os.makedirs(output_dir, exist_ok=True)
            
            # 保存UNet状态
            unet_state = self.accelerator.unwrap_model(self.pipeline.unet).state_dict()
            torch.save(unet_state, os.path.join(output_dir, "unet_state_dict.pt"))
            
            # 保存特征提取器
            feature_state = self.accelerator.unwrap_model(self.feature_extractor).state_dict()
            torch.save(feature_state, os.path.join(output_dir, "feature_extractor.pt"))
            
            # 不再保存完整pipeline，节省硬盘空间
            # 生成时直接从checkpoints目录加载基础pipeline并应用权重
            
            # 保存配置和损失
            with open(os.path.join(output_dir, "config.json"), 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            
            # 转换损失为可序列化格式
            serializable_losses = {}
            for key, value_list in losses.items():
                if isinstance(value_list, list) and value_list:
                    serializable_losses[key] = [float(v) for v in value_list]
                else:
                    serializable_losses[key] = []
            
            with open(os.path.join(output_dir, "losses.json"), 'w', encoding='utf-8') as f:
                json.dump(serializable_losses, f, indent=2, ensure_ascii=False)
            
            logger.info(f"高级检查点已保存: {output_dir}")
            
        except Exception as e:
            logger.error(f"保存检查点失败: {e}")
    
    def visualize_advanced_training(self, all_losses):
        """可视化高级训练结果"""
        if not all_losses:
            return
        
        try:
            # 创建多子图
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle('Advanced Training Loss Curves', fontsize=16)
            
            epochs = range(1, len(all_losses) + 1)
            
            # 总损失
            total_losses = [loss['total'] for loss in all_losses]
            axes[0, 0].plot(epochs, total_losses, 'b-', linewidth=2)
            axes[0, 0].set_title('Total Loss')
            axes[0, 0].set_xlabel('Epoch')
            axes[0, 0].set_ylabel('Loss')
            axes[0, 0].grid(True)
            
            # MSE损失
            mse_losses = [loss['mse'] for loss in all_losses]
            axes[0, 1].plot(epochs, mse_losses, 'r-', linewidth=2)
            axes[0, 1].set_title('MSE Loss')
            axes[0, 1].set_xlabel('Epoch')
            axes[0, 1].set_ylabel('Loss')
            axes[0, 1].grid(True)
            
            # LPIPS损失
            lpips_losses = [loss['lpips'] for loss in all_losses]
            axes[1, 0].plot(epochs, lpips_losses, 'g-', linewidth=2)
            axes[1, 0].set_title('Perceptual Loss (LPIPS)')
            axes[1, 0].set_xlabel('Epoch')
            axes[1, 0].set_ylabel('Loss')
            axes[1, 0].grid(True)
            
            # 特征损失
            feature_losses = [loss['feature'] for loss in all_losses]
            axes[1, 1].plot(epochs, feature_losses, 'm-', linewidth=2)
            axes[1, 1].set_title('Feature Loss')
            axes[1, 1].set_xlabel('Epoch')
            axes[1, 1].set_ylabel('Loss')
            axes[1, 1].grid(True)
            
            plt.tight_layout()
            
            # 保存图表
            output_dir = self.config["output_dir"]
            os.makedirs(output_dir, exist_ok=True)
            plt.savefig(os.path.join(output_dir, "advanced_training_curves.png"), dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info("训练曲线已保存")
            
        except Exception as e:
            logger.error(f"可视化失败: {e}")
    
    def generate_advanced(self, prompt, pattern_type=None, output_dir=None, num_images=1):
        """高级生成方法 - 使用优化的提示词"""
        logger.info(f"开始生成图像，原始提示词: {prompt}")
        
        # 检查是否有训练好的检查点
        if not self._has_trained_checkpoint():
            logger.error("未找到训练好的检查点，请先运行训练模式")
            return []
        
        # 生成模式：只初始化特征提取器，然后在加载检查点时加载pipeline
        if not self.feature_extractor:
            self.initialize_models(for_generation=True)
        
        # 加载检查点（包括基础模型）
        if not self.pipeline:
            if not self.load_latest_checkpoint(for_generation=True):
                logger.error("检查点加载失败，无法进行生成")
                return []
        
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        else:
            output_dir = "output/results/generated"
            os.makedirs(output_dir, exist_ok=True)
        
        # 初始化知识处理器
        knowledge_processor = KnowledgeProcessor()
        
        images = []
        
        for i in range(num_images):
            try:
                # 简化提示词处理 - 直接使用输入提示词，避免过度优化
                if len(prompt) < 50:
                    # 如果是简短提示词，适当增强
                    enhanced_prompt = f"{prompt}, traditional Chinese embroidery, museum quality, detailed craftsmanship"
                else:
                    # 如果是完整提示词，只做基础清理
                    enhanced_prompt = prompt.strip()
                    # 移除重复的开头词汇
                    enhanced_prompt = re.sub(r'^(Chinese imperial court rank badge,?\s*){2,}', 'Chinese imperial court rank badge, ', enhanced_prompt)
                    # 移除其他重复片段
                    enhanced_prompt = re.sub(r'(traditional gold thread embroidery,?\s*silk fabric,?\s*intricate needlework,?\s*){2,}', 'traditional gold thread embroidery, silk fabric, intricate needlework, ', enhanced_prompt)
                
                # 添加负面提示词以提高质量
                negative_prompt = "low quality, blurry, deformed, bad anatomy, text, watermark, signature, abstract art, modern art, cartoon, anime"
                
                logger.info(f"正在生成第 {i+1}/{num_images} 张图像...")
                logger.info(f"优化后提示词: {enhanced_prompt}")
                
                # 清理GPU内存
                torch.cuda.empty_cache()
                
                # 生成图像
                with torch.no_grad():
                    image = self.pipeline(
                        prompt=enhanced_prompt,
                        negative_prompt=negative_prompt,
                        num_inference_steps=5,  # 增加步数以提高质量
                        guidance_scale=7.5,
                        height=self.config["image_size"],
                        width=self.config["image_size"],
                        generator=torch.Generator(device=self.device).manual_seed(42 + i)
                    ).images[0]
                
                # 生成后清理内存
                torch.cuda.empty_cache()
                
                images.append(image)
                
                # 保存图像
                timestamp = __import__('datetime').datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"optimized_generated_{timestamp}_{i+1}.png"
                image_path = os.path.join(output_dir, filename)
                image.save(image_path)
                
                logger.info(f"图像已保存: {image_path}")
                
            except Exception as e:
                logger.error(f"生成图像 {i+1} 失败: {e}")
                import traceback
                traceback.print_exc()
        
        logger.info(f"生成完成，共生成 {len(images)} 张图像，保存在: {output_dir}")
        return images
    
    def load_latest_checkpoint(self, for_generation=False):
        """加载最新检查点 - 从checkpoints目录加载基础pipeline，然后应用训练权重"""
        try:
            output_dir = self.config["output_dir"]
            if not os.path.exists(output_dir):
                if for_generation:
                    logger.error("未找到检查点目录，无法进行生成")
                    return False
                else:
                    logger.warning("未找到检查点目录，使用原始模型")
                    return True
            
            # 查找最新检查点
            checkpoints = []
            for item in os.listdir(output_dir):
                if item.startswith("checkpoint-") and os.path.isdir(os.path.join(output_dir, item)):
                    checkpoints.append(item)
            
            if not checkpoints:
                if for_generation:
                    logger.error("未找到检查点，无法进行生成")
                    return False
                else:
                    logger.warning("未找到检查点，使用原始模型")
                    return True
            
            # 按名称排序，取最新的
            def sort_key(checkpoint):
                # 提取epoch数字进行排序
                if "epoch_" in checkpoint:
                    try:
                        return int(checkpoint.split("epoch_")[1])
                    except:
                        return 0
                return 0
            
            latest_checkpoint = sorted(checkpoints, key=sort_key)[-1]
            checkpoint_path = os.path.join(output_dir, latest_checkpoint)
            
            logger.info(f"加载检查点: {latest_checkpoint}")
            
            # 清理GPU内存
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            
            if for_generation:
                # 生成模式：从checkpoints加载基础pipeline，然后应用训练权重
                logger.info("生成模式：从checkpoints加载基础pipeline...")
                
                # 检查本地pipeline是否存在
                if not os.path.exists(self.config["model_id"]):
                    logger.error(f"本地pipeline不存在: {self.config['model_id']}")
                    logger.error("请先运行: python setup_local_pipeline.py")
                    return False
                
                try:
                    # 加载本地基础pipeline
                    self.pipeline = StableDiffusionXLPipeline.from_pretrained(
                        self.config["model_id"],
                        torch_dtype=self.dtype,
                        use_safetensors=True,
                        local_files_only=True
                    ).to(self.device)
                    logger.info("基础pipeline加载成功")
                    
                    # 启用内存优化
                    if self.device.type == "cuda":
                        try:
                            self.pipeline.enable_attention_slicing()
                            self.pipeline.enable_vae_slicing()
                            logger.info("已启用内存优化")
                        except Exception as e:
                            logger.warning(f"内存优化启用失败: {e}")
                    
                    # 确保数据类型一致
                    self.pipeline.unet = self.pipeline.unet.to(dtype=self.dtype)
                    self.pipeline.vae = self.pipeline.vae.to(dtype=self.dtype)
                    self.pipeline.text_encoder = self.pipeline.text_encoder.to(dtype=self.dtype)
                    self.pipeline.text_encoder_2 = self.pipeline.text_encoder_2.to(dtype=self.dtype)
                    
                except Exception as e:
                    logger.error(f"加载基础pipeline失败: {e}")
                    return False
            
            # 加载UNet状态
            unet_path = os.path.join(checkpoint_path, "unet_state_dict.pt")
            if os.path.exists(unet_path):
                # 使用CPU加载以节省GPU内存
                state_dict = torch.load(unet_path, map_location='cpu')
                self.pipeline.unet.load_state_dict(state_dict, strict=False)
                logger.info(f"已加载UNet检查点: {latest_checkpoint}")
                del state_dict  # 释放内存
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            
            # 加载特征提取器
            feature_path = os.path.join(checkpoint_path, "feature_extractor.pt")
            if os.path.exists(feature_path):
                state_dict = torch.load(feature_path, map_location='cpu')
                self.feature_extractor.load_state_dict(state_dict)
                logger.info(f"已加载特征提取器检查点: {latest_checkpoint}")
                del state_dict  # 释放内存
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            
            return True
            
        except Exception as e:
            logger.error(f"加载检查点失败: {e}")
            if for_generation:
                return False
            else:
                logger.warning("将使用原始模型进行生成")
                # 清理内存
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                return True
    
    def generate_with_features(self, prompt, craft_params=None, knowledge_features=None, 
                             output_dir=None, num_images=1):
        """使用特定特征生成图像"""
        logger.info(f"使用特征生成图像，提示词: {prompt}")
        
        if not self.pipeline:
            self.initialize_models()
            self.load_latest_checkpoint()
        
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        else:
            output_dir = "output/results/generated_with_features"
            os.makedirs(output_dir, exist_ok=True)
        
        # 默认特征
        if craft_params is None:
            craft_params = torch.tensor([[0.7, 0.8, 0.6, 0.5, 0.6, 0.7]], 
                                      dtype=self.dtype, device=self.device)
        else:
            craft_params = torch.tensor([craft_params], dtype=self.dtype, device=self.device)
        
        if knowledge_features is None:
            knowledge_features = torch.randn(1, 768, dtype=self.dtype, device=self.device)
        else:
            knowledge_features = torch.tensor([knowledge_features], dtype=self.dtype, device=self.device)
        
        images = []
        
        for i in range(num_images):
            try:
                # 创建虚拟图像用于特征提取
                dummy_image = torch.randn(1, 3, self.config["image_size"], self.config["image_size"], 
                                        dtype=self.dtype, device=self.device)
                
                # 提取刺绣特征
                with torch.no_grad():
                    embroidery_features = self.feature_extractor(dummy_image, craft_params, knowledge_features)
                
                # 增强提示词
                enhanced_prompt = f"{prompt}, 金线刺绣, 精细工艺, 传统纹样, 高质量"
                negative_prompt = "低质量, 模糊, 变形, 错误"
                
                logger.info(f"正在生成第 {i+1}/{num_images} 张特征图像...")
                
                # 生成图像（这里可以进一步集成特征，但需要更复杂的实现）
                with torch.no_grad():
                    image = self.pipeline(
                        prompt=enhanced_prompt,
                        negative_prompt=negative_prompt,
                        num_inference_steps=50,
                        guidance_scale=7.5,
                        height=self.config["image_size"],
                        width=self.config["image_size"],
                        generator=torch.Generator(device=self.device).manual_seed(42 + i)
                    ).images[0]
                
                images.append(image)
                
                # 保存图像
                timestamp = __import__('datetime').datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"feature_generated_{timestamp}_{i+1}.png"
                image_path = os.path.join(output_dir, filename)
                image.save(image_path)
                
                logger.info(f"特征图像已保存: {image_path}")
                
            except Exception as e:
                logger.error(f"生成特征图像 {i+1} 失败: {e}")
                import traceback
                traceback.print_exc()
        
        logger.info(f"特征生成完成，共生成 {len(images)} 张图像")
        return images
    
    def clean_and_optimize_prompt(self, raw_prompt):
        """清理和优化提示词，生成更适合图像生成的描述"""
        
        # 基础清理
        cleaned = raw_prompt.replace("{ Name:", "").replace("}", "").replace("{", "")
        cleaned = re.sub(r"['\"]", "", cleaned)  # 移除引号
        cleaned = re.sub(r"Central pattern:", "", cleaned)
        cleaned = re.sub(r"Grade:", "", cleaned)
        cleaned = re.sub(r"Color code: #[A-Fa-f0-9]{6}", "", cleaned)  # 移除颜色代码
        
        # 移除重复和无意义的片段
        cleaned = re.sub(r"First-rank civil servant Xian crane,?\s*", "Chinese imperial court rank badge, first rank civil official, red-crowned crane, ", cleaned)
        cleaned = re.sub(r"First-grade,?\s*", "", cleaned)
        cleaned = re.sub(r"One-grade,?\s*", "", cleaned)
        
        # 标准化刺绣术语
        embroidery_terms = {
            "Plate gold embroidery": "gold thread couching",
            "flat needle embroidery": "satin stitch",
            "trocar": "long and short stitch",
            "seed embroidery": "French knots",
            "nail thread embroidery": "laid work",
            "lock embroidery": "chain stitch"
        }
        
        for old_term, new_term in embroidery_terms.items():
            cleaned = cleaned.replace(old_term, new_term)
        
        # 添加视觉质量描述词
        quality_terms = [
            "museum quality",
            "fine silk textile",
            "detailed craftsmanship",
            "traditional Chinese art",
            "ornate design",
            "luxury embroidery"
        ]
        
        # 构建优化的提示词
        optimized_parts = [
            "Chinese imperial court rank badge",
            "red-crowned crane bird",
            "traditional gold thread embroidery",
            "silk fabric background",
            "intricate needlework",
            "imperial court style",
            "detailed textile art",
            "museum quality craftsmanship"
        ]
        
        # 从原始提示词中提取有用的刺绣技法
        if "gold" in cleaned.lower():
            optimized_parts.append("metallic gold threads")
        if "high density" in cleaned.lower():
            optimized_parts.append("dense stitching")
        if "complex pattern" in cleaned.lower():
            optimized_parts.append("intricate patterns")
        
        optimized_prompt = ", ".join(optimized_parts)
        
        # 确保长度适中
        if len(optimized_prompt) > 200:
            optimized_prompt = optimized_prompt[:200]
        
        return optimized_prompt

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="高级金线刺绣训练器 - 修复版本")
    parser.add_argument("--mode", type=str, choices=["train", "generate"], required=True)
    parser.add_argument("--config", type=str, default="config/advanced_config_safe.json")
    parser.add_argument("--data_dir", type=str, default="data/图像层")
    parser.add_argument("--knowledge_dir", type=str, default="data/知识层1")
    parser.add_argument("--craft_dir", type=str, default="output/results/craft")
    parser.add_argument("--output_dir", type=str, default="output/results/advanced")
    parser.add_argument("--prompt", type=str, default="一品文官仙鹤金线刺绣")
    parser.add_argument("--num_images", type=int, default=1)
    
    args = parser.parse_args()
    
    trainer = AdvancedGoldThreadTrainer(config_path=args.config)
    
    if args.mode == "train":
        trainer.train(args.data_dir, args.knowledge_dir, args.craft_dir)
    elif args.mode == "generate":
        trainer.generate_advanced(args.prompt, output_dir=args.output_dir, num_images=args.num_images) 