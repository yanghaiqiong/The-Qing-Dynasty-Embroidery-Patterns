#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import time
import requests
import logging
from PIL import Image
from io import BytesIO
import json
from datetime import datetime
import hashlib

logger = logging.getLogger(__name__)

class DALLE3Generator:
    """DALL-E 3生成器 - 用于对比实验"""
    
    def __init__(self, api_key=None, cache_dir="cache/dalle3"):
        """
        初始化DALL-E 3生成器
        
        Args:
            api_key (str): OpenAI API密钥
            cache_dir (str): 缓存目录
        """
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        if not self.api_key:
            logger.warning("未提供OpenAI API密钥，将使用模拟模式")
            self.mock_mode = True
        else:
            self.mock_mode = False
            
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        
        # API配置
        self.api_url = "https://api.openai.com/v1/images/generations"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # 生成参数
        self.default_params = {
            "model": "dall-e-3",
            "size": "1024x1024",
            "quality": "standard",
            "n": 1,
            "response_format": "url"
        }
        
        logger.info(f"DALL-E 3生成器初始化完成，模式: {'模拟' if self.mock_mode else 'API'}")
    
    def _get_cache_path(self, prompt, params):
        """生成缓存文件路径"""
        # 创建唯一标识符
        cache_key = f"{prompt}_{json.dumps(params, sort_keys=True)}"
        cache_hash = hashlib.md5(cache_key.encode()).hexdigest()
        return os.path.join(self.cache_dir, f"{cache_hash}.png")
    
    def _load_from_cache(self, prompt, params):
        """从缓存加载图像"""
        cache_path = self._get_cache_path(prompt, params)
        if os.path.exists(cache_path):
            try:
                image = Image.open(cache_path)
                logger.info(f"从缓存加载图像: {os.path.basename(cache_path)}")
                return image, cache_path
            except Exception as e:
                logger.warning(f"缓存文件损坏: {e}")
        return None, None
    
    def _save_to_cache(self, image, prompt, params):
        """保存图像到缓存"""
        cache_path = self._get_cache_path(prompt, params)
        try:
            image.save(cache_path)
            logger.info(f"图像已缓存: {os.path.basename(cache_path)}")
            return cache_path
        except Exception as e:
            logger.error(f"缓存保存失败: {e}")
            return None
    
    def _create_mock_image(self, prompt, size="1024x1024"):
        """创建模拟图像（用于测试）"""
        width, height = map(int, size.split('x'))
        
        # 创建渐变背景
        import numpy as np
        
        # 根据提示词生成不同的颜色
        prompt_hash = hash(prompt) % 1000000
        np.random.seed(prompt_hash)
        
        # 生成渐变色
        color1 = np.random.randint(50, 200, 3)
        color2 = np.random.randint(50, 200, 3)
        
        # 创建渐变图像
        image_array = np.zeros((height, width, 3), dtype=np.uint8)
        for i in range(height):
            ratio = i / height
            color = color1 * (1 - ratio) + color2 * ratio
            image_array[i, :] = color.astype(np.uint8)
        
        # 添加一些纹理
        noise = np.random.randint(-20, 20, (height, width, 3))
        image_array = np.clip(image_array + noise, 0, 255).astype(np.uint8)
        
        image = Image.fromarray(image_array)
        
        # 添加文本标识
        from PIL import ImageDraw, ImageFont
        draw = ImageDraw.Draw(image)
        
        try:
            # 尝试使用系统字体
            font = ImageFont.truetype("arial.ttf", 40)
        except:
            font = ImageFont.load_default()
        
        # 添加DALL-E 3标识
        text = "DALL-E 3 (Mock)"
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        
        x = (width - text_width) // 2
        y = height - text_height - 20
        
        # 添加背景
        draw.rectangle([x-10, y-10, x+text_width+10, y+text_height+10], fill=(0, 0, 0, 128))
        draw.text((x, y), text, fill=(255, 255, 255), font=font)
        
        # 添加提示词（截断）
        prompt_text = prompt[:50] + "..." if len(prompt) > 50 else prompt
        draw.text((10, 10), prompt_text, fill=(255, 255, 255), font=font)
        
        return image
    
    def generate(self, prompt, size="1024x1024", quality="standard", save_path=None, use_cache=True):
        """
        生成图像
        
        Args:
            prompt (str): 提示词
            size (str): 图像尺寸
            quality (str): 图像质量
            save_path (str): 保存路径
            use_cache (bool): 是否使用缓存
            
        Returns:
            PIL.Image: 生成的图像
        """
        params = {
            "model": "dall-e-3",
            "size": size,
            "quality": quality,
            "n": 1
        }
        
        # 检查缓存
        if use_cache:
            cached_image, cache_path = self._load_from_cache(prompt, params)
            if cached_image:
                if save_path:
                    cached_image.save(save_path)
                return cached_image
        
        logger.info(f"生成DALL-E 3图像: {prompt[:50]}...")
        
        if self.mock_mode:
            # 模拟模式
            logger.info("使用模拟模式生成图像")
            image = self._create_mock_image(prompt, size)
            
            # 模拟API延迟
            time.sleep(2)
            
        else:
            # 真实API调用
            try:
                payload = {
                    **self.default_params,
                    "prompt": prompt,
                    "size": size,
                    "quality": quality
                }
                
                logger.info("调用DALL-E 3 API...")
                response = requests.post(
                    self.api_url,
                    headers=self.headers,
                    json=payload,
                    timeout=60
                )
                
                if response.status_code == 200:
                    result = response.json()
                    image_url = result['data'][0]['url']
                    
                    # 下载图像
                    logger.info("下载生成的图像...")
                    img_response = requests.get(image_url, timeout=30)
                    image = Image.open(BytesIO(img_response.content))
                    
                else:
                    logger.error(f"API调用失败: {response.status_code} - {response.text}")
                    # 降级到模拟模式
                    logger.info("降级到模拟模式")
                    image = self._create_mock_image(prompt, size)
                    
            except Exception as e:
                logger.error(f"DALL-E 3生成失败: {e}")
                # 降级到模拟模式
                logger.info("降级到模拟模式")
                image = self._create_mock_image(prompt, size)
        
        # 保存到缓存
        if use_cache:
            self._save_to_cache(image, prompt, params)
        
        # 保存到指定路径
        if save_path:
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            image.save(save_path)
            logger.info(f"图像已保存: {save_path}")
        
        return image
    
    def batch_generate(self, prompts, output_dir, size="1024x1024", quality="standard"):
        """
        批量生成图像
        
        Args:
            prompts (list): 提示词列表
            output_dir (str): 输出目录
            size (str): 图像尺寸
            quality (str): 图像质量
            
        Returns:
            dict: 生成结果
        """
        os.makedirs(output_dir, exist_ok=True)
        
        results = {}
        
        for i, prompt in enumerate(prompts):
            try:
                logger.info(f"批量生成 {i+1}/{len(prompts)}: {prompt[:30]}...")
                
                # 生成文件名
                safe_prompt = "".join(c for c in prompt if c.isalnum() or c in (' ', '-', '_')).rstrip()
                safe_prompt = safe_prompt[:50]  # 限制长度
                filename = f"dalle3_{i+1:03d}_{safe_prompt}.png"
                save_path = os.path.join(output_dir, filename)
                
                # 生成图像
                start_time = time.time()
                image = self.generate(prompt, size, quality, save_path)
                generation_time = time.time() - start_time
                
                results[prompt] = {
                    "success": True,
                    "image_path": save_path,
                    "generation_time": generation_time,
                    "size": image.size
                }
                
                logger.info(f"生成完成: {filename} ({generation_time:.2f}s)")
                
                # API限制：避免过快请求
                if not self.mock_mode:
                    time.sleep(1)
                    
            except Exception as e:
                logger.error(f"生成失败 {prompt}: {e}")
                results[prompt] = {
                    "success": False,
                    "error": str(e),
                    "generation_time": 0
                }
        
        # 保存批量生成报告
        report_path = os.path.join(output_dir, "dalle3_generation_report.json")
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump({
                "timestamp": datetime.now().isoformat(),
                "total_prompts": len(prompts),
                "successful": sum(1 for r in results.values() if r["success"]),
                "failed": sum(1 for r in results.values() if not r["success"]),
                "results": results
            }, f, indent=2, ensure_ascii=False)
        
        logger.info(f"批量生成完成，报告保存: {report_path}")
        
        return results
    
    def get_generation_stats(self):
        """获取生成统计信息"""
        cache_files = [f for f in os.listdir(self.cache_dir) if f.endswith('.png')]
        
        return {
            "cache_size": len(cache_files),
            "cache_dir": self.cache_dir,
            "mock_mode": self.mock_mode,
            "api_available": self.api_key is not None
        }

if __name__ == "__main__":
    # 测试代码
    generator = DALLE3Generator()
    
    test_prompts = [
        "一品文官仙鹤金线刺绣",
        "二品文官锦鸡金线刺绣",
        "三品文官孔雀金线刺绣"
    ]
    
    # 测试单个生成
    image = generator.generate(test_prompts[0], save_path="test_dalle3.png")
    print(f"生成图像尺寸: {image.size}")
    
    # 测试批量生成
    results = generator.batch_generate(test_prompts, "output/test_dalle3")
    print(f"批量生成结果: {len(results)} 个")
    
    # 显示统计信息
    stats = generator.get_generation_stats()
    print(f"生成统计: {stats}") 