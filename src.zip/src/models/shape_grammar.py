import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from PIL import Image, ImageDraw
import cv2
import matplotlib.pyplot as plt
import logging
from tqdm import tqdm
import math

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ShapeGrammarController:
    """形状文法控制器，用于实现九宫格布局骨架注入和针法走向控制"""
    
    def __init__(self, device=None):
        """
        初始化形状文法控制器
        
        参数:
            device (str, optional): 计算设备
        """
        self.device = device if device else ("cuda" if torch.cuda.is_available() else "cpu")
        
        # 动物轮廓模板路径
        self.animal_templates = {
            "仙鹤": "crane.png",
            "麒麟": "qilin.png",
            "锦鸡": "pheasant.png",
            "狮子": "lion.png",
            "孔雀": "peacock.png",
            "豹子": "leopard.png",
            "云雁": "wild_goose.png",
            "虎": "tiger.png",
            "白鹇": "silver_pheasant.png",
            "熊": "bear.png",
            "鹭鸶": "egret.png",
            "彪纹": "tiger_pattern.png",
            "鸂鶒": "mandarin_duck.png",
            "犀牛": "rhinoceros.png",
            "鹌鹑": "quail.png",
            "海马": "seahorse.png",
            "练鹊": "magpie.png"
        }
    
    def generate_nine_grid_layout(self, size=512, line_width=2, center_ratio=0.5):
        """
        生成九宫格布局骨架
        
        参数:
            size (int): 输出图像大小
            line_width (int): 线条宽度
            center_ratio (float): 中心区域占比
            
        返回:
            np.ndarray: 九宫格布局图像
        """
        # 创建空白图像
        layout = np.zeros((size, size), dtype=np.uint8)
        
        # 计算中心区域大小
        center_size = int(size * center_ratio)
        start = (size - center_size) // 2
        end = start + center_size
        
        # 绘制九宫格线条
        # 水平线
        for i in range(3):
            y = start + (center_size * i) // 2
            layout[y-line_width//2:y+line_width//2+1, start:end] = 255
        
        # 垂直线
        for i in range(3):
            x = start + (center_size * i) // 2
            layout[start:end, x-line_width//2:x+line_width//2+1] = 255
        
        return layout
    
    def generate_canny_control_image(self, input_image, low_threshold=100, high_threshold=200):
        """
        生成Canny边缘检测控制图像
        
        参数:
            input_image (np.ndarray): 输入图像
            low_threshold (int): Canny低阈值
            high_threshold (int): Canny高阈值
            
        返回:
            np.ndarray: Canny边缘图像
        """
        # 确保输入图像是灰度图
        if len(input_image.shape) == 3:
            gray = cv2.cvtColor(input_image, cv2.COLOR_BGR2GRAY)
        else:
            gray = input_image
        
        # 应用高斯模糊减少噪声
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # 执行Canny边缘检测
        edges = cv2.Canny(blurred, low_threshold, high_threshold)
        
        return edges
    
    def generate_animal_silhouette(self, animal_type, size=512, line_width=2):
        """
        生成动物轮廓控制图像
        
        参数:
            animal_type (str): 动物类型
            size (int): 输出图像大小
            line_width (int): 线条宽度
            
        返回:
            np.ndarray: 动物轮廓图像
        """
        # 检查动物类型是否支持
        if animal_type not in self.animal_templates:
            logger.warning(f"不支持的动物类型: {animal_type}")
            return None
        
        # 创建空白图像
        silhouette = np.zeros((size, size), dtype=np.uint8)
        
        # 在实际应用中，这里应该加载预定义的动物轮廓模板
        # 这里使用简单的几何形状模拟
        center = (size // 2, size // 2)
        radius = size // 4
        
        if animal_type in ["仙鹤", "孔雀", "云雁", "鹭鸶", "鸂鶒", "练鹊"]:
            # 鸟类轮廓：三角形
            pts = np.array([
                [center[0], center[1] - radius],
                [center[0] - radius, center[1] + radius],
                [center[0] + radius, center[1] + radius]
            ], np.int32)
            cv2.polylines(silhouette, [pts], True, 255, line_width)
            
        elif animal_type in ["麒麟", "狮子", "豹子", "虎", "彪纹"]:
            # 猛兽轮廓：矩形
            cv2.rectangle(silhouette, 
                        (center[0] - radius, center[1] - radius),
                        (center[0] + radius, center[1] + radius),
                        255, line_width)
            
        else:
            # 其他动物：圆形
            cv2.circle(silhouette, center, radius, 255, line_width)
        
        return silhouette
    
    def generate_embroidery_guide(self, stitch_type, size=512, line_width=2):
        """
        生成针法走向指导图像
        
        参数:
            stitch_type (str): 针法类型
            size (int): 输出图像大小
            line_width (int): 线条宽度
            
        返回:
            np.ndarray: 针法指导图像
        """
        # 创建空白图像
        guide = np.zeros((size, size), dtype=np.uint8)
        
        # 根据不同针法生成不同的指导线
        if stitch_type == "盘金绣":
            # 螺旋形指导线
            center = (size // 2, size // 2)
            max_radius = size // 3
            theta = np.linspace(0, 6 * np.pi, 100)
            
            for i in range(len(theta) - 1):
                r1 = theta[i] * max_radius / (6 * np.pi)
                r2 = theta[i + 1] * max_radius / (6 * np.pi)
                x1 = int(center[0] + r1 * np.cos(theta[i]))
                y1 = int(center[1] + r1 * np.sin(theta[i]))
                x2 = int(center[0] + r2 * np.cos(theta[i + 1]))
                y2 = int(center[1] + r2 * np.sin(theta[i + 1]))
                cv2.line(guide, (x1, y1), (x2, y2), 255, line_width)
                
        elif stitch_type == "平金绣":
            # 平行线指导
            spacing = size // 20
            for y in range(spacing, size, spacing):
                cv2.line(guide, (0, y), (size, y), 255, line_width)
                
        elif stitch_type == "垫高针":
            # 放射状指导线
            center = (size // 2, size // 2)
            num_lines = 16
            radius = size // 2
            
            for i in range(num_lines):
                angle = i * (2 * np.pi / num_lines)
                end_x = int(center[0] + radius * np.cos(angle))
                end_y = int(center[1] + radius * np.sin(angle))
                cv2.line(guide, center, (end_x, end_y), 255, line_width)
        
        return guide
    
    def create_layout_condition(self, pattern_type, size=512):
        """
        创建完整的布局条件图像
        
        参数:
            pattern_type (str): 图案类型（如"一品文官仙鹤"）
            size (int): 输出图像大小
            
        返回:
            np.ndarray: 布局条件图像
        """
        # 创建空白图像
        condition = np.zeros((size, size), dtype=np.uint8)
        
        # 添加九宫格布局
        nine_grid = self.generate_nine_grid_layout(size)
        condition = cv2.addWeighted(condition, 1, nine_grid, 0.5, 0)
        
        # 解析图案类型，提取动物
        animal = None
        for key in self.animal_templates.keys():
            if key in pattern_type:
                animal = key
                break
        
        if animal:
            # 生成动物轮廓
            silhouette = self.generate_animal_silhouette(animal, size)
            if silhouette is not None:
                # 将轮廓放置在中心区域
                center_mask = np.zeros((size, size), dtype=np.uint8)
                center_size = int(size * 0.5)
                start = (size - center_size) // 2
                end = start + center_size
                center_mask[start:end, start:end] = silhouette[start:end, start:end]
                
                condition = cv2.addWeighted(condition, 1, center_mask, 0.7, 0)
        
        return condition
    
    def evaluate_compliance(self, generated_image, control_image, threshold=0.6):
        """
        评估生成图像对布局约束的符合度
        
        参数:
            generated_image (np.ndarray): 生成的图像
            control_image (np.ndarray): 控制图像
            threshold (float): 符合度阈值
            
        返回:
            float: 符合度分数
        """
        # 确保输入图像是灰度图
        if len(generated_image.shape) == 3:
            generated_gray = cv2.cvtColor(generated_image, cv2.COLOR_BGR2GRAY)
        else:
            generated_gray = generated_image
        
        # 确保control_image也是灰度图
        if len(control_image.shape) == 3:
            control_gray = cv2.cvtColor(control_image, cv2.COLOR_BGR2GRAY)
        else:
            control_gray = control_image
        
        # 提取生成图像的边缘
        generated_edges = self.generate_canny_control_image(generated_gray)
        
        # 确保两个图像尺寸相同
        if generated_edges.shape != control_gray.shape:
            control_gray = cv2.resize(control_gray, (generated_edges.shape[1], generated_edges.shape[0]))
        
        # 确保数据类型一致（转换为8位无符号整数）
        generated_edges = generated_edges.astype(np.uint8)
        control_gray = control_gray.astype(np.uint8)
        
        # 计算边缘重叠度
        intersection = cv2.bitwise_and(generated_edges, control_gray)
        union = cv2.bitwise_or(generated_edges, control_gray)
        
        if np.sum(union) == 0:
            return 0.0
        
        # 计算IoU分数
        iou = np.sum(intersection) / np.sum(union)
        
        # 计算结构相似性 - 修复模板匹配错误
        try:
            # 确保图像是2D且数据类型正确
            if generated_edges.shape == control_gray.shape and generated_edges.ndim == 2:
                # 使用32位浮点数进行模板匹配
                gen_float = generated_edges.astype(np.float32) / 255.0
                ctrl_float = control_gray.astype(np.float32) / 255.0
                
                # 使用归一化相关系数
                result = cv2.matchTemplate(gen_float, ctrl_float, cv2.TM_CCORR_NORMED)
                ssim = result[0][0] if result.size > 0 else 0.0
            else:
                # 如果尺寸不匹配，使用简单的像素相似度
                ssim = np.mean(np.abs(generated_edges.astype(float) - control_gray.astype(float))) / 255.0
                ssim = 1.0 - ssim  # 转换为相似度
        except Exception as e:
            logger.warning(f"模板匹配失败，使用备用计算方法: {e}")
            # 备用方法：计算像素差异
            diff = np.abs(generated_edges.astype(float) - control_gray.astype(float))
            ssim = 1.0 - (np.mean(diff) / 255.0)
        
        # 综合分数
        compliance_score = 0.5 * iou + 0.5 * ssim
        
        return compliance_score
    
    def visualize_compliance(self, generated_image, control_image, output_path=None):
        """
        可视化布局符合度评估
        
        参数:
            generated_image (np.ndarray): 生成的图像
            control_image (np.ndarray): 控制图像
            output_path (str, optional): 输出图像路径
        """
        # 提取生成图像的边缘
        if len(generated_image.shape) == 3:
            generated_gray = cv2.cvtColor(generated_image, cv2.COLOR_BGR2GRAY)
        else:
            generated_gray = generated_image
            
        # 确保control_image也是灰度图
        if len(control_image.shape) == 3:
            control_gray = cv2.cvtColor(control_image, cv2.COLOR_BGR2GRAY)
        else:
            control_gray = control_image.copy()
            
        generated_edges = self.generate_canny_control_image(generated_gray)
        
        # 确保两个图像尺寸相同
        if generated_edges.shape != control_gray.shape:
            control_gray = cv2.resize(control_gray, (generated_edges.shape[1], generated_edges.shape[0]))
        
        # 确保数据类型一致
        generated_edges = generated_edges.astype(np.uint8)
        control_gray = control_gray.astype(np.uint8)
        
        # 创建可视化图像
        vis_image = np.zeros((generated_edges.shape[0], generated_edges.shape[1], 3), dtype=np.uint8)
        
        # 控制图像显示为红色
        vis_image[control_gray > 0] = [0, 0, 255]
        
        # 生成图像边缘显示为绿色
        vis_image[generated_edges > 0] = [0, 255, 0]
        
        # 重叠区域显示为黄色
        intersection = cv2.bitwise_and(generated_edges, control_gray)
        vis_image[intersection > 0] = [0, 255, 255]
        
        # 计算符合度分数
        compliance_score = self.evaluate_compliance(generated_image, control_image)
        
        # 添加分数文本
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(vis_image, f"Compliance: {compliance_score:.2f}", 
                    (10, 30), font, 1, (255, 255, 255), 2)
        
        # 保存可视化结果
        if output_path:
            cv2.imwrite(output_path, vis_image)
            logger.info(f"已保存符合度可视化: {output_path}")
        
        return vis_image
    
    def design_reward_function(self, stitch_type):
        """
        设计针法走向的奖励函数
        
        参数:
            stitch_type (str): 针法类型
            
        返回:
            function: 奖励函数
        """
        if stitch_type == "盘金绣":
            def reward_func(image, state):
                # 提取边缘
                edges = self.generate_canny_control_image(image)
                
                # 计算螺旋度
                center = (image.shape[0] // 2, image.shape[1] // 2)
                y, x = np.nonzero(edges)
                if len(x) == 0 or len(y) == 0:
                    return 0.0
                
                # 计算相对于中心的角度变化
                angles = np.arctan2(y - center[0], x - center[1])
                angle_diff = np.diff(np.sort(angles))
                spiral_score = np.mean(np.abs(angle_diff))
                
                return spiral_score
                
            return reward_func
            
        elif stitch_type == "平金绣":
            def reward_func(image, state):
                # 提取边缘
                edges = self.generate_canny_control_image(image)
                
                # 计算水平线条的比例
                gradients = np.gradient(edges)
                horizontal_score = np.mean(np.abs(gradients[0])) / (np.mean(np.abs(gradients[1])) + 1e-6)
                
                return 1.0 / (1.0 + horizontal_score)
                
            return reward_func
            
        elif stitch_type == "垫高针":
            def reward_func(image, state):
                # 提取边缘
                edges = self.generate_canny_control_image(image)
                
                # 计算放射状特征
                center = (image.shape[0] // 2, image.shape[1] // 2)
                y, x = np.nonzero(edges)
                if len(x) == 0 or len(y) == 0:
                    return 0.0
                
                # 计算到中心的距离和角度
                distances = np.sqrt((x - center[1])**2 + (y - center[0])**2)
                angles = np.arctan2(y - center[0], x - center[1])
                
                # 计算角度的均匀分布程度
                hist, _ = np.histogram(angles, bins=16, range=(-np.pi, np.pi))
                uniformity = 1.0 - np.std(hist) / np.mean(hist)
                
                return uniformity
                
            return reward_func
        
        else:
            # 默认奖励函数
            return lambda image, state: 0.0


if __name__ == "__main__":
    # 测试代码
    controller = ShapeGrammarController()
    
    output_dir = "../../output/results/shape_grammar_test"
    os.makedirs(output_dir, exist_ok=True)
    
    # 测试九宫格生成
    nine_grid = controller.generate_nine_grid_layout()
    nine_grid.save(os.path.join(output_dir, "nine_grid_layout.png"))
    
    # 测试动物轮廓生成
    crane_outline = controller.generate_animal_silhouette("仙鹤")
    crane_outline.save(os.path.join(output_dir, "crane_outline.png"))
    
    # 测试针法引导生成
    stitch_guide = controller.generate_embroidery_guide("盘金绣")
    stitch_guide.save(os.path.join(output_dir, "pangjin_guide.png"))
    
    # 测试布局条件图生成
    layout_condition = controller.create_layout_condition("一品文官仙鹤 盘金绣")
    layout_condition.save(os.path.join(output_dir, "layout_condition.png"))
    
    # 创建模拟生成图像进行符合度测试
    # 这里使用布局条件图本身作为模拟生成图像
    mock_generated = Image.open(os.path.join(output_dir, "crane_outline.png"))
    compliance = controller.evaluate_compliance(mock_generated, layout_condition)
    print(f"模拟符合度评分: {compliance:.4f}")
    
    # 可视化符合度
    controller.visualize_compliance(
        mock_generated, 
        layout_condition, 
        os.path.join(output_dir, "compliance_visualization.png")
    ) 