import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import CLIPTextModel, CLIPTokenizer, CLIPTextModelWithProjection
from diffusers import (
    StableDiffusionXLPipeline, 
    AutoencoderKL, 
    UNet2DConditionModel,
    DDPMScheduler,
    StableDiffusionXLImg2ImgPipeline,
    ControlNetModel
)
from diffusers.loaders import LoraLoaderMixin
from accelerate import Accelerator
from pathlib import Path
import numpy as np
from PIL import Image
from tqdm.auto import tqdm
from torch.utils.data import Dataset, DataLoader
import logging
import wandb
import matplotlib.pyplot as plt

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class GoldThreadDiffusionModel:
    """金线刺绣扩散模型基础类，用于生成具有文化准确性和工艺可行性的刺绣纹样"""
    
    def __init__(self, model_id="stabilityai/stable-diffusion-xl-base-1.0", device=None):
        """
        初始化扩散模型
        
        参数:
            model_id (str): 使用的基础模型ID
            device (str, optional): 计算设备，如果为None则自动选择
        """
        # 完全禁用CUDA，强制使用CPU
        os.environ['CUDA_VISIBLE_DEVICES'] = ''
        
        # 强制PyTorch使用CPU
        torch.cuda.is_available = lambda: False
        
        self.model_id = model_id
        self.device = torch.device("cpu")
        logger.info(f"使用设备: {self.device}")
        
        # 加载分词器
        self.tokenizer = CLIPTokenizer.from_pretrained(
            model_id, 
            subfolder="tokenizer",
            revision="main",
            cache_dir=None
        )
        
        # 加载第二个分词器
        self.tokenizer_2 = CLIPTokenizer.from_pretrained(
            model_id, 
            subfolder="tokenizer_2",
            revision="main",
            cache_dir=None
        )
        
        # 加载第一个文本编码器
        self.text_encoder = CLIPTextModel.from_pretrained(
            model_id, 
            subfolder="text_encoder",
            revision="main",
            cache_dir=None,
            torch_dtype=torch.float32,
            device_map={"": "cpu"}
        )
        
        # 加载第二个文本编码器
        self.text_encoder_2 = CLIPTextModelWithProjection.from_pretrained(
            model_id, 
            subfolder="text_encoder_2",
            revision="main",
            cache_dir=None,
            torch_dtype=torch.float32,
            device_map={"": "cpu"}
        )
        
        # 加载VAE
        self.vae = AutoencoderKL.from_pretrained(
            model_id, 
            subfolder="vae",
            revision="main",
            cache_dir=None,
            torch_dtype=torch.float32,
            device_map={"": "cpu"}
        )
        
        # 加载UNet
        self.unet = UNet2DConditionModel.from_pretrained(
            model_id, 
            subfolder="unet",
            revision="main",
            cache_dir=None,
            torch_dtype=torch.float32,
            device_map={"": "cpu"}
        )
        
        # 加载噪声调度器
        self.noise_scheduler = DDPMScheduler.from_pretrained(model_id, subfolder="scheduler", revision="main", cache_dir=None)
        
        # 完整的pipeline (用于推理)
        self.pipeline = None
        
        # ControlNet模型
        self.controlnet = None
        
        # 初始化wandb
        self.wandb_initialized = False
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 微软雅黑
        plt.rcParams['axes.unicode_minus'] = False

        # 检查各子模块权重来源
        def get_model_source(model):
            if hasattr(model, 'name_or_path'):
                return getattr(model, 'name_or_path', '未知')
            if hasattr(model, 'config') and hasattr(model.config, '_name_or_path'):
                return getattr(model.config, '_name_or_path', '未知')
            return '未知'
        sources = {
            'tokenizer': getattr(self.tokenizer, 'name_or_path', '未知'),
            'tokenizer_2': getattr(self.tokenizer_2, 'name_or_path', '未知'),
            'text_encoder': get_model_source(self.text_encoder),
            'text_encoder_2': get_model_source(self.text_encoder_2),
            'vae': get_model_source(self.vae),
            'unet': get_model_source(self.unet)
        }
        
        # SDXL的cross_attention_dim应该等于两个text_encoder的hidden_size之和
        text_encoder_hidden_size = self.text_encoder.config.hidden_size
        text_encoder_2_hidden_size = self.text_encoder_2.config.hidden_size
        expected_cross_attention_dim = text_encoder_hidden_size + text_encoder_2_hidden_size
        actual_cross_attention_dim = self.unet.config.cross_attention_dim
        
        if expected_cross_attention_dim != actual_cross_attention_dim:
            mismatch = []
            for k, v in sources.items():
                if self.model_id not in v:
                    mismatch.append(f"{k}: {v}")
            mismatch_info = '\n'.join(mismatch) if mismatch else '（无法自动检测到具体不一致的子模块，请手动检查）'
            raise RuntimeError(
                f"模型权重不匹配：text_encoder hidden_size={self.text_encoder.config.hidden_size}，"
                f"text_encoder_2 hidden_size={self.text_encoder_2.config.hidden_size}，"
                f"预期cross_attention_dim={expected_cross_attention_dim}，"
                f"实际unet cross_attention_dim={actual_cross_attention_dim}。\n"
                f"检测到以下子模块权重来源与主model_id不一致：\n{mismatch_info}\n"
                f"请确保所有子模块都来自同一个官方SDXL模型id，"
                f"如 stabilityai/stable-diffusion-xl-base-1.0，并清理本地huggingface缓存后重新下载。"
            )
    
    def load_pipeline(self):
        """加载完整的扩散模型pipeline用于推理"""
        if self.pipeline is None:
            logger.info("加载完整pipeline...")
            self.pipeline = StableDiffusionXLPipeline.from_pretrained(
                self.model_id,
                torch_dtype=torch.float32
            ).to(self.device)
            logger.info("Pipeline加载完成")
    
    def load_controlnet(self, controlnet_model_id="lllyasviel/control_v11p_sd15_canny"):
        """
        加载ControlNet模型
        
        参数:
            controlnet_model_id (str): ControlNet模型ID
        """
        logger.info(f"加载ControlNet模型: {controlnet_model_id}")
        self.controlnet = ControlNetModel.from_pretrained(
            controlnet_model_id,
            torch_dtype=torch.float16 if self.device == "cuda" else torch.float32
        ).to(self.device)
        logger.info("ControlNet模型加载完成")
    
    def create_lora_layers(self, rank=16, alpha=32):
        """
        为UNet创建LoRA适配层
        
        参数:
            rank (int): LoRA秩
            alpha (int): LoRA缩放因子
        """
        # 实现LoRA适配层的创建，这里只是一个示例框架
        # 实际实现可能更复杂，需要考虑语义通道和质感通道
        logger.info(f"创建LoRA层: rank={rank}, alpha={alpha}")
        
        # 这里需要实现具体的LoRA层创建逻辑
        # 在实际实现中，你可能需要:
        # 1. 遍历UNet中的线性层
        # 2. 替换为LoRA适配的层
        # 3. 区分语义通道和质感通道
        
        logger.info("LoRA层创建完成")
    
    def train(self, 
              train_data_dir, 
              output_dir, 
              num_epochs=100, 
              batch_size=4, 
              learning_rate=1e-5,
              save_steps=500,
              gradient_accumulation_steps=4,
              use_wandb=True,
              project_name="gold_thread_embroidery"):
        """
        训练模型
        
        参数:
            train_data_dir (str): 训练数据目录
            output_dir (str): 输出模型目录
            num_epochs (int): 训练轮数
            batch_size (int): 批大小
            learning_rate (float): 学习率
            save_steps (int): 保存模型的步数间隔
            gradient_accumulation_steps (int): 梯度累积步数
            use_wandb (bool): 是否使用wandb记录训练过程
            project_name (str): wandb项目名称
        """
        logger.info("开始训练过程...")
        
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # 初始化wandb
        if use_wandb and not self.wandb_initialized:
            wandb.init(project=project_name)
            self.wandb_initialized = True
        
        # 准备数据集和加载器
        # 这里需要实现具体的数据集加载逻辑
        # train_dataset = YourCustomDataset(train_data_dir)
        # train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        
        # 设置优化器
        # optimizer = torch.optim.AdamW(self.unet.parameters(), lr=learning_rate)
        
        # 使用Accelerator进行分布式训练支持
        # accelerator = Accelerator(
        #     gradient_accumulation_steps=gradient_accumulation_steps,
        #     mixed_precision="fp16" if self.device == "cuda" else "no"
        # )
        
        # 训练循环
        # global_step = 0
        # for epoch in range(num_epochs):
        #     self.unet.train()
        #     for step, batch in enumerate(train_dataloader):
        #         # 训练逻辑
        #         ...
        #         
        #         # 记录训练指标
        #         if use_wandb:
        #             wandb.log({"loss": loss.item()})
        #         
        #         # 保存模型
        #         if global_step % save_steps == 0:
        #             self.save_model(os.path.join(output_dir, f"checkpoint-{global_step}"))
        #         
        #         global_step += 1
        
        logger.info("训练完成")
    
    def save_model(self, output_dir):
        """
        保存模型
        
        参数:
            output_dir (str): 保存模型的目录
        """
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # 保存UNet模型
        self.unet.save_pretrained(os.path.join(output_dir, "unet"))
        
        # 如果使用了ControlNet，也保存它
        if self.controlnet is not None:
            self.controlnet.save_pretrained(os.path.join(output_dir, "controlnet"))
        
        logger.info(f"模型已保存到: {output_dir}")
    
    def load_model(self, model_dir):
        """
        加载保存的模型
        
        参数:
            model_dir (str): 模型目录
        """
        # 加载UNet
        unet_path = os.path.join(model_dir, "unet")
        if os.path.exists(unet_path):
            self.unet = UNet2DConditionModel.from_pretrained(
                unet_path,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32
            ).to(self.device)
        
        # 加载ControlNet
        controlnet_path = os.path.join(model_dir, "controlnet")
        if os.path.exists(controlnet_path):
            self.controlnet = ControlNetModel.from_pretrained(
                controlnet_path,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32
            ).to(self.device)
        
        logger.info(f"已加载模型: {model_dir}")
    
    def generate(self, 
                 prompt, 
                 control_image=None, 
                 negative_prompt="低质量, 模糊, 畸变", 
                 num_inference_steps=50,
                 guidance_scale=7.5, 
                 height=512, 
                 width=512,
                 seed=None,
                 output_path=None):
        """
        生成刺绣纹样图像
        
        参数:
            prompt (str): 生成提示词
            control_image (PIL.Image, optional): 控制图像
            negative_prompt (str): 负面提示词
            num_inference_steps (int): 推理步数
            guidance_scale (float): 提示词引导系数
            height (int): 输出图像高度
            width (int): 输出图像宽度
            seed (int, optional): 随机种子
            output_path (str, optional): 输出图像路径
            
        返回:
            PIL.Image: 生成的图像
        """
        # 确保pipeline已加载
        if self.pipeline is None:
            self.load_pipeline()
        
        # 设置随机种子
        if seed is not None:
            torch.manual_seed(seed)
            np.random.seed(seed)
        
        # 生成图像
        if control_image is not None and self.controlnet is not None:
            # 使用ControlNet的生成
            pipe = StableDiffusionXLImg2ImgPipeline(
                vae=self.vae,
                unet=self.unet,
                text_encoder=self.text_encoder,
                tokenizer=self.tokenizer,
                scheduler=self.noise_scheduler,
                controlnet=self.controlnet
            ).to(self.device)
            
            image = pipe(
                prompt=prompt,
                negative_prompt=negative_prompt,
                image=control_image,
                num_inference_steps=num_inference_steps,
                guidance_scale=guidance_scale
            ).images[0]
        else:
            # 标准生成
            image = self.pipeline(
                prompt=prompt,
                negative_prompt=negative_prompt,
                num_inference_steps=num_inference_steps,
                guidance_scale=guidance_scale,
                height=height,
                width=width
            ).images[0]
        
        # 保存图像
        if output_path:
            image.save(output_path)
            logger.info(f"已保存生成图像: {output_path}")
        
        return image
    
    def evaluate_cultural_relevance(self, generated_image, target_label):
        """
        评估生成图像的文化符合度
        
        参数:
            generated_image (PIL.Image): 生成的图像
            target_label (str): 目标标签（如"一品文官仙鹤"）
            
        返回:
            float: 文化符合度分数
        """
        # 这里应该实现基于CLIP的文化符合度评估
        # 由于CLIP评估需要较多代码，这里给出示例框架
        
        # 1. 加载CLIP模型
        # clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
        # clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
        
        # 2. 准备图像和文本
        # inputs = clip_processor(
        #     text=[target_label], 
        #     images=generated_image, 
        #     return_tensors="pt", 
        #     padding=True
        # ).to(self.device)
        
        # 3. 计算相似度
        # outputs = clip_model(**inputs)
        # similarity = outputs.logits_per_image[0][0].item()
        
        # 示例返回，实际中应返回真实计算结果
        logger.info(f"文化符合度评估: 目标={target_label}")
        return 0.85
    
    def evaluate_craftability(self, generated_image):
        """
        评估生成图像的工艺可行性
        
        参数:
            generated_image (PIL.Image): 生成的图像
            
        返回:
            float: 工艺可行性分数
        """
        # 这里应该实现工艺可行性评估模型
        # 实际实现中，可能需要:
        # 1. 提取图像特征（如线条复杂度、密度等）
        # 2. 使用预训练的工艺可行性预测模型进行评估
        
        # 示例返回，实际中应返回真实计算结果
        logger.info("工艺可行性评估")
        return 0.78
    
    def visualize_attention_maps(self, prompt, output_path=None):
        """
        可视化注意力图
        
        参数:
            prompt (str): 提示词
            output_path (str, optional): 输出图像路径
        """
        # 实现注意力图可视化
        # 这需要访问模型内部的注意力权重
        
        logger.info(f"注意力图可视化: prompt={prompt}")
        
        # 创建示例可视化
        fig, ax = plt.subplots(1, 1, figsize=(10, 8))
        ax.set_title(f"Prompt Attention Map: {prompt}")
        ax.text(0.5, 0.5, "Attention Map Example\n(Actual implementation requires access to internal model weights)", 
                ha='center', va='center', fontsize=12)
        ax.axis('off')
        
        if output_path:
            plt.savefig(output_path, bbox_inches='tight')
            logger.info(f"注意力图已保存: {output_path}")
            
        plt.close()
    
    def run_comparative_experiment(self, prompt, control_image=None, output_dir=None):
        """
        运行对比实验（无约束、硬约束、混合约束）
        
        参数:
            prompt (str): 提示词
            control_image (PIL.Image, optional): 控制图像
            output_dir (str, optional): 输出目录
            
        返回:
            dict: 包含生成图像和评估结果的字典
        """
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        
        results = {}
        
        # 1. 无约束生成
        logger.info("无约束生成...")
        unconstrained_image = self.generate(
            prompt=prompt,
            output_path=os.path.join(output_dir, "无约束生成.png") if output_dir else None
        )
        results["无约束"] = {
            "image": unconstrained_image,
            "文化符合度": self.evaluate_cultural_relevance(unconstrained_image, prompt),
            "工艺可行性": self.evaluate_craftability(unconstrained_image)
        }
        
        # 2. 硬约束生成（使用ControlNet）
        if control_image is not None and self.controlnet is not None:
            logger.info("硬约束生成...")
            hard_constrained_image = self.generate(
                prompt=prompt,
                control_image=control_image,
                output_path=os.path.join(output_dir, "硬约束生成.png") if output_dir else None
            )
            results["硬约束"] = {
                "image": hard_constrained_image,
                "文化符合度": self.evaluate_cultural_relevance(hard_constrained_image, prompt),
                "工艺可行性": self.evaluate_craftability(hard_constrained_image)
            }
        
        # 3. 混合约束生成
        # 这通常结合ControlNet和LoRA或其他技术
        # 在实际实现中，可能需要特定的混合约束逻辑
        
        # 可视化对比结果
        if output_dir:
            self.visualize_comparison(results, os.path.join(output_dir, "对比实验结果.png"))
        
        return results
    
    def visualize_comparison(self, results, output_path=None):
        """
        可视化对比实验结果
        
        参数:
            results (dict): 对比实验结果
            output_path (str, optional): 输出图像路径
        """
        # 创建对比可视化
        n_methods = len(results)
        
        fig, axes = plt.subplots(2, n_methods, figsize=(6 * n_methods, 10))
        
        for i, (method, data) in enumerate(results.items()):
            # 图像
            axes[0, i].imshow(data["image"])
            axes[0, i].set_title(f"{method} Generation")
            axes[0, i].axis('off')
            
            # 评分
            cultural_score = data["文化符合度"]
            craft_score = data["工艺可行性"]
            avg_score = (cultural_score + craft_score) / 2
            
            metrics = ['Cultural Compliance', 'Craft Feasibility', 'Average Score']
            scores = [cultural_score, craft_score, avg_score]
            
            axes[1, i].bar(metrics, scores, color=['blue', 'green', 'orange'])
            axes[1, i].set_ylim(0, 1)
            axes[1, i].set_title(f"{method} Scores")
            
            for j, score in enumerate(scores):
                axes[1, i].text(j, score + 0.05, f'{score:.2f}', ha='center')
        
        plt.tight_layout()
        
        if output_path:
            plt.savefig(output_path, bbox_inches='tight')
            logger.info(f"对比结果已保存: {output_path}")
            
        plt.close()


if __name__ == "__main__":
    # 测试代码
    model = GoldThreadDiffusionModel()
    
    # 生成一个简单的测试图像
    test_prompt = "一品文官 仙鹤 金线刺绣"
    output_dir = "../../output/results/model_test"
    os.makedirs(output_dir, exist_ok=True)
    
    # 由于实际运行可能需要下载大型模型，这里只创建测试视觉效果
    model.visualize_attention_maps(test_prompt, os.path.join(output_dir, "attention_map_test.png"))
    
    # 模拟对比实验结果
    mock_results = {
        "无约束": {
            "image": Image.new('RGB', (512, 512), color = (73, 109, 137)),
            "文化符合度": 0.65,
            "工艺可行性": 0.42
        },
        "硬约束": {
            "image": Image.new('RGB', (512, 512), color = (109, 73, 137)),
            "文化符合度": 0.78,
            "工艺可行性": 0.65
        },
        "混合约束": {
            "image": Image.new('RGB', (512, 512), color = (73, 137, 109)),
            "文化符合度": 0.85,
            "工艺可行性": 0.82
        }
    }
    
    model.visualize_comparison(mock_results, os.path.join(output_dir, "comparison_test.png")) 