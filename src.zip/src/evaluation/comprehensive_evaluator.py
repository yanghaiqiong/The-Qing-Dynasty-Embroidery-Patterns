#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import numpy as np
import cv2
from PIL import Image
import torch
import torch.nn.functional as F
from torchvision import transforms
import logging
from skimage.feature import graycomatrix, graycoprops
from scipy.spatial.distance import cosine
import json

# 添加项目路径
sys.path.append('src')

logger = logging.getLogger(__name__)

class ComprehensiveEvaluator:
    """综合评估器 - 支持多种图像质量和文化准确性评估指标"""
    
    def __init__(self):
        """初始化评估器"""
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 初始化各种评估模型
        self.clip_model = None
        self.clip_processor = None
        self.inception_model = None
        
        # 文化符号词典
        self.cultural_symbols = {
            "仙鹤": ["crane", "bird", "elegant", "longevity"],
            "锦鸡": ["golden pheasant", "colorful bird", "ornate"],
            "孔雀": ["peacock", "feathers", "magnificent"],
            "云雁": ["wild goose", "flying", "migration"],
            "白鹇": ["silver pheasant", "white bird"],
            "鹭鸶": ["egret", "heron", "water bird"],
            "鸂鶒": ["mandarin duck", "pair", "love"],
            "鹌鹑": ["quail", "small bird"],
            "练鹊": ["magpie", "black white"],
            "麒麟": ["qilin", "mythical", "dragon", "lion"],
            "金线": ["gold thread", "metallic", "shiny"],
            "刺绣": ["embroidery", "needlework", "textile"]
        }
        
        # 工艺特征
        self.craft_features = [
            "thread", "stitch", "pattern", "texture", "metallic",
            "embroidery", "needlework", "fabric", "silk", "gold"
        ]
        
        logger.info("综合评估器初始化完成")
    
    def _init_clip_model(self):
        """初始化CLIP模型"""
        if self.clip_model is None:
            try:
                from transformers import CLIPModel, CLIPProcessor
                self.clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
                self.clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
                self.clip_model.to(self.device)
                logger.info("CLIP模型初始化成功")
            except Exception as e:
                logger.warning(f"CLIP模型初始化失败: {e}")
                self.clip_model = None
    
    def _init_inception_model(self):
        """初始化Inception模型（用于FID计算）"""
        if self.inception_model is None:
            try:
                from torchvision.models import inception_v3
                self.inception_model = inception_v3(pretrained=True, transform_input=False)
                self.inception_model.fc = torch.nn.Identity()  # 移除最后的分类层
                self.inception_model.eval()
                self.inception_model.to(self.device)
                logger.info("Inception模型初始化成功")
            except Exception as e:
                logger.warning(f"Inception模型初始化失败: {e}")
                self.inception_model = None
    
    def evaluate_single_image(self, image_path, prompt=""):
        """
        评估单张图像
        
        Args:
            image_path (str): 图像路径
            prompt (str): 对应的提示词
            
        Returns:
            dict: 评估结果
        """
        if not os.path.exists(image_path):
            logger.error(f"图像文件不存在: {image_path}")
            return {}
        
        try:
            # 加载图像
            image = Image.open(image_path).convert('RGB')
            image_array = np.array(image)
            
            # 执行各项评估
            results = {
                "image_path": image_path,
                "prompt": prompt,
                "image_size": image.size
            }
            
            # 1. GLCM纹理复杂度
            results["glcm_texture"] = self._calculate_glcm_texture(image_array)
            
            # 2. CLIP相似度
            results["clip_similarity"] = self._calculate_clip_similarity(image, prompt)
            
            # 3. 文化准确性
            results["cultural_accuracy"] = self._evaluate_cultural_accuracy(image, prompt)
            
            # 4. 工艺可行性
            results["craft_feasibility"] = self._evaluate_craft_feasibility(image, prompt)
            
            # 5. 美学质量
            results["aesthetic_quality"] = self._evaluate_aesthetic_quality(image_array)
            
            # 6. 图像清晰度
            results["sharpness"] = self._calculate_sharpness(image_array)
            
            # 7. 颜色丰富度
            results["color_richness"] = self._calculate_color_richness(image_array)
            
            # 8. 对比度
            results["contrast"] = self._calculate_contrast(image_array)
            
            # 计算综合评分
            results["overall_score"] = self._calculate_overall_score(results)
            
            return results
            
        except Exception as e:
            logger.error(f"图像评估失败 {image_path}: {e}")
            return {"error": str(e), "image_path": image_path}
    
    def _calculate_glcm_texture(self, image_array):
        """计算GLCM纹理复杂度"""
        try:
            # 转换为灰度图
            gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
            
            # 计算GLCM
            distances = [1, 2, 3]
            angles = [0, 45, 90, 135]
            
            contrast_values = []
            dissimilarity_values = []
            homogeneity_values = []
            energy_values = []
            
            for distance in distances:
                for angle in angles:
                    # 计算GLCM矩阵
                    glcm = graycomatrix(gray, [distance], [np.radians(angle)], 
                                     levels=256, symmetric=True, normed=True)
                    
                    # 计算纹理特征
                    contrast_values.append(graycoprops(glcm, 'contrast')[0, 0])
                    dissimilarity_values.append(graycoprops(glcm, 'dissimilarity')[0, 0])
                    homogeneity_values.append(graycoprops(glcm, 'homogeneity')[0, 0])
                    energy_values.append(graycoprops(glcm, 'energy')[0, 0])
            
            # 计算平均值
            texture_complexity = {
                "contrast": float(np.mean(contrast_values)),
                "dissimilarity": float(np.mean(dissimilarity_values)),
                "homogeneity": float(np.mean(homogeneity_values)),
                "energy": float(np.mean(energy_values))
            }
            
            # 综合纹理复杂度分数
            complexity_score = (texture_complexity["contrast"] + 
                              texture_complexity["dissimilarity"]) / 2
            
            return float(complexity_score)
            
        except Exception as e:
            logger.warning(f"GLCM纹理计算失败: {e}")
            return 0.0
    
    def _calculate_clip_similarity(self, image, prompt):
        """计算CLIP相似度"""
        try:
            self._init_clip_model()
            
            if self.clip_model is None:
                return 0.0
            
            # 处理图像和文本
            inputs = self.clip_processor(
                text=[prompt], 
                images=[image], 
                return_tensors="pt", 
                padding=True
            )
            
            # 移动到设备
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            # 获取特征
            with torch.no_grad():
                outputs = self.clip_model(**inputs)
                image_features = outputs.image_embeds
                text_features = outputs.text_embeds
                
                # 计算余弦相似度
                similarity = F.cosine_similarity(image_features, text_features, dim=1)
                
            return float(similarity.cpu().item())
            
        except Exception as e:
            logger.warning(f"CLIP相似度计算失败: {e}")
            return 0.0
    
    def _evaluate_cultural_accuracy(self, image, prompt):
        """评估文化准确性"""
        try:
            # 基于提示词中的文化元素评估
            cultural_score = 0.0
            total_elements = 0
            
            for symbol, keywords in self.cultural_symbols.items():
                if symbol in prompt:
                    total_elements += 1
                    
                    # 使用CLIP检查图像中是否包含相关元素
                    for keyword in keywords:
                        similarity = self._calculate_clip_similarity(image, keyword)
                        cultural_score += similarity
            
            if total_elements > 0:
                cultural_score = cultural_score / (total_elements * len(keywords))
            else:
                cultural_score = 0.5  # 默认分数
            
            return float(cultural_score)
            
        except Exception as e:
            logger.warning(f"文化准确性评估失败: {e}")
            return 0.0
    
    def _evaluate_craft_feasibility(self, image, prompt):
        """评估工艺可行性"""
        try:
            # 基于工艺特征评估
            craft_score = 0.0
            
            for feature in self.craft_features:
                similarity = self._calculate_clip_similarity(image, feature)
                craft_score += similarity
            
            craft_score = craft_score / len(self.craft_features)
            
            # 额外检查金线刺绣特征
            if "金线" in prompt or "刺绣" in prompt:
                metallic_score = self._calculate_clip_similarity(image, "metallic gold embroidery")
                craft_score = (craft_score + metallic_score) / 2
            
            return float(craft_score)
            
        except Exception as e:
            logger.warning(f"工艺可行性评估失败: {e}")
            return 0.0
    
    def _evaluate_aesthetic_quality(self, image_array):
        """评估美学质量"""
        try:
            # 基于多个美学指标
            scores = []
            
            # 1. 构图平衡（基于重心）
            gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
            moments = cv2.moments(gray)
            if moments['m00'] != 0:
                cx = moments['m10'] / moments['m00']
                cy = moments['m01'] / moments['m00']
                h, w = gray.shape
                # 重心越接近中心，构图越平衡
                balance_score = 1 - (abs(cx - w/2) + abs(cy - h/2)) / (w + h)
                scores.append(balance_score)
            
            # 2. 颜色和谐度
            color_harmony = self._calculate_color_harmony(image_array)
            scores.append(color_harmony)
            
            # 3. 细节丰富度
            detail_richness = self._calculate_detail_richness(image_array)
            scores.append(detail_richness)
            
            return float(np.mean(scores))
            
        except Exception as e:
            logger.warning(f"美学质量评估失败: {e}")
            return 0.0
    
    def _calculate_color_harmony(self, image_array):
        """计算颜色和谐度"""
        try:
            # 转换到HSV色彩空间
            hsv = cv2.cvtColor(image_array, cv2.COLOR_RGB2HSV)
            hue = hsv[:, :, 0]
            
            # 计算色相分布的标准差
            hue_std = np.std(hue)
            
            # 标准差适中表示颜色和谐
            harmony_score = 1 / (1 + hue_std / 50)
            
            return float(harmony_score)
            
        except Exception as e:
            logger.warning(f"颜色和谐度计算失败: {e}")
            return 0.0
    
    def _calculate_detail_richness(self, image_array):
        """计算细节丰富度"""
        try:
            # 使用Sobel算子检测边缘
            gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
            sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            
            # 计算梯度幅值
            gradient_magnitude = np.sqrt(sobelx**2 + sobely**2)
            
            # 细节丰富度 = 平均梯度幅值
            detail_score = np.mean(gradient_magnitude) / 255.0
            
            return float(detail_score)
            
        except Exception as e:
            logger.warning(f"细节丰富度计算失败: {e}")
            return 0.0
    
    def _calculate_sharpness(self, image_array):
        """计算图像清晰度"""
        try:
            gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
            
            # 使用Laplacian算子计算清晰度
            laplacian = cv2.Laplacian(gray, cv2.CV_64F)
            sharpness = np.var(laplacian)
            
            # 归一化
            sharpness_score = min(sharpness / 1000, 1.0)
            
            return float(sharpness_score)
            
        except Exception as e:
            logger.warning(f"清晰度计算失败: {e}")
            return 0.0
    
    def _calculate_color_richness(self, image_array):
        """计算颜色丰富度"""
        try:
            # 计算颜色直方图
            hist_r = cv2.calcHist([image_array], [0], None, [256], [0, 256])
            hist_g = cv2.calcHist([image_array], [1], None, [256], [0, 256])
            hist_b = cv2.calcHist([image_array], [2], None, [256], [0, 256])
            
            # 计算熵（信息量）
            def calculate_entropy(hist):
                hist = hist.flatten()
                hist = hist[hist > 0]  # 移除零值
                prob = hist / np.sum(hist)
                entropy = -np.sum(prob * np.log2(prob))
                return entropy
            
            entropy_r = calculate_entropy(hist_r)
            entropy_g = calculate_entropy(hist_g)
            entropy_b = calculate_entropy(hist_b)
            
            # 平均熵作为颜色丰富度
            color_richness = (entropy_r + entropy_g + entropy_b) / 3
            
            # 归一化到0-1
            richness_score = min(color_richness / 8, 1.0)
            
            return float(richness_score)
            
        except Exception as e:
            logger.warning(f"颜色丰富度计算失败: {e}")
            return 0.0
    
    def _calculate_contrast(self, image_array):
        """计算对比度"""
        try:
            gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
            
            # 计算标准差作为对比度指标
            contrast = np.std(gray)
            
            # 归一化
            contrast_score = min(contrast / 64, 1.0)
            
            return float(contrast_score)
            
        except Exception as e:
            logger.warning(f"对比度计算失败: {e}")
            return 0.0
    
    def _calculate_overall_score(self, results):
        """计算综合评分"""
        try:
            # 权重设置
            weights = {
                "glcm_texture": 0.15,
                "clip_similarity": 0.20,
                "cultural_accuracy": 0.25,
                "craft_feasibility": 0.20,
                "aesthetic_quality": 0.10,
                "sharpness": 0.05,
                "color_richness": 0.03,
                "contrast": 0.02
            }
            
            overall_score = 0.0
            total_weight = 0.0
            
            for metric, weight in weights.items():
                if metric in results and isinstance(results[metric], (int, float)):
                    overall_score += results[metric] * weight
                    total_weight += weight
            
            if total_weight > 0:
                overall_score = overall_score / total_weight
            
            return float(overall_score)
            
        except Exception as e:
            logger.warning(f"综合评分计算失败: {e}")
            return 0.0
    
    def calculate_fid_score(self, real_images_dir, generated_images_dir):
        """计算FID分数"""
        try:
            self._init_inception_model()
            
            if self.inception_model is None:
                logger.warning("Inception模型未初始化，无法计算FID")
                return float('inf')
            
            # 提取特征
            real_features = self._extract_inception_features(real_images_dir)
            gen_features = self._extract_inception_features(generated_images_dir)
            
            if len(real_features) == 0 or len(gen_features) == 0:
                logger.warning("特征提取失败，无法计算FID")
                return float('inf')
            
            # 计算均值和协方差
            mu1, sigma1 = np.mean(real_features, axis=0), np.cov(real_features, rowvar=False)
            mu2, sigma2 = np.mean(gen_features, axis=0), np.cov(gen_features, rowvar=False)
            
            # 计算FID
            diff = mu1 - mu2
            covmean = self._sqrtm(sigma1.dot(sigma2))
            
            if np.iscomplexobj(covmean):
                covmean = covmean.real
            
            fid = diff.dot(diff) + np.trace(sigma1 + sigma2 - 2 * covmean)
            
            return float(fid)
            
        except Exception as e:
            logger.error(f"FID计算失败: {e}")
            return float('inf')
    
    def _extract_inception_features(self, images_dir):
        """提取Inception特征"""
        features = []
        
        # 图像预处理
        transform = transforms.Compose([
            transforms.Resize((299, 299)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        for filename in os.listdir(images_dir):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                try:
                    image_path = os.path.join(images_dir, filename)
                    image = Image.open(image_path).convert('RGB')
                    image_tensor = transform(image).unsqueeze(0).to(self.device)
                    
                    with torch.no_grad():
                        feature = self.inception_model(image_tensor)
                        features.append(feature.cpu().numpy().flatten())
                        
                except Exception as e:
                    logger.warning(f"特征提取失败 {filename}: {e}")
        
        return np.array(features)
    
    def _sqrtm(self, matrix):
        """计算矩阵平方根"""
        try:
            from scipy.linalg import sqrtm
            return sqrtm(matrix)
        except ImportError:
            # 简化实现
            eigenvalues, eigenvectors = np.linalg.eigh(matrix)
            eigenvalues = np.maximum(eigenvalues, 0)  # 确保非负
            sqrt_eigenvalues = np.sqrt(eigenvalues)
            return eigenvectors @ np.diag(sqrt_eigenvalues) @ eigenvectors.T
    
    def batch_evaluate(self, images_dir, prompts_file=None):
        """批量评估图像"""
        results = []
        
        # 加载提示词
        prompts = {}
        if prompts_file and os.path.exists(prompts_file):
            with open(prompts_file, 'r', encoding='utf-8') as f:
                prompts = json.load(f)
        
        # 评估所有图像
        for filename in os.listdir(images_dir):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                image_path = os.path.join(images_dir, filename)
                prompt = prompts.get(filename, "")
                
                result = self.evaluate_single_image(image_path, prompt)
                results.append(result)
        
        return results

if __name__ == "__main__":
    # 测试代码
    evaluator = ComprehensiveEvaluator()
    
    # 测试单张图像评估
    test_image = "test_image.png"
    test_prompt = "一品文官仙鹤金线刺绣"
    
    if os.path.exists(test_image):
        result = evaluator.evaluate_single_image(test_image, test_prompt)
        print(f"评估结果: {result}")
    else:
        print("测试图像不存在，跳过测试") 