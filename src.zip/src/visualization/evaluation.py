import numpy as np
import matplotlib.pyplot as plt
import logging
from pytorch_fid import fid_score
from skimage.feature import greycomatrix, greycoprops
import open_clip
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, roc_curve, auc

# 预留：如需集成scikit-learn、clip、pytorch-fid、skimage等
# from sklearn.metrics import confusion_matrix, roc_curve, auc
# import clip
# from pytorch_fid import fid_score
# from skimage.feature import greycomatrix, greycoprops

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class Evaluation:
    """生成评估与博士级可视化主类"""
    def __init__(self):
        self.clip_model, _, self.clip_preprocess = open_clip.create_model_and_transforms('ViT-B-32', pretrained='openai')
        self.clip_tokenizer = open_clip.get_tokenizer('ViT-B-32')
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.clip_model = self.clip_model.to(self.device)

    def compute_fid(self, real_dir, gen_dir):
        """FID分数评估骨架"""
        fid = fid_score.calculate_fid_given_paths([real_dir, gen_dir], batch_size=16, device=str(self.device), dims=2048)
        logger.info(f'FID分数: {fid:.4f}')
        return fid

    def compute_glcm(self, img):
        """GLCM纹理复杂度评估骨架"""
        # img: numpy array, uint8, gray
        glcm = greycomatrix(img, [1], [0, np.pi/4, np.pi/2, 3*np.pi/4], 256, symmetric=True, normed=True)
        contrast = greycoprops(glcm, 'contrast').mean()
        energy = greycoprops(glcm, 'energy').mean()
        logger.info(f'GLCM对比度: {contrast:.4f}, 能量: {energy:.4f}')
        return {'contrast': contrast, 'energy': energy}

    def style_consistency(self, real_imgs, gen_imgs):
        """风格一致性评估骨架"""
        logger.info('风格一致性建议用人工评分或特征距离')
        return None

    def clip_similarity(self, img, text):
        """CLIP语义相似度骨架"""
        # img: PIL.Image, text: str
        image = self.clip_preprocess(img).unsqueeze(0).to(self.device)
        text = self.clip_tokenizer([text]).to(self.device)
        with torch.no_grad():
            image_features = self.clip_model.encode_image(image)
            text_features = self.clip_model.encode_text(text)
            sim = torch.nn.functional.cosine_similarity(image_features, text_features).item()
        logger.info(f'CLIP语义相似度: {sim:.4f}')
        return sim

    def confusion_matrix(self, y_true, y_pred, labels, output_path):
        """混淆矩阵可视化骨架"""
        cm = confusion_matrix(y_true, y_pred, labels=labels)
        plt.figure(figsize=(8,6))
        plt.imshow(cm, cmap='Blues')
        plt.xticks(np.arange(len(labels)), labels, rotation=45)
        plt.yticks(np.arange(len(labels)), labels)
        plt.xlabel('预测')
        plt.ylabel('真实')
        plt.title('混淆矩阵')
        for i in range(len(labels)):
            for j in range(len(labels)):
                plt.text(j, i, cm[i, j], ha='center', va='center', color='red')
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
        logger.info(f'混淆矩阵已保存: {output_path}')

    def craftability_predict(self, features, labels):
        """工艺可行性逻辑回归预测骨架"""
        clf = LogisticRegression(max_iter=200)
        clf.fit(features, labels)
        y_score = clf.predict_proba(features)[:,1]
        y_pred = clf.predict(features)
        logger.info('工艺可行性逻辑回归已训练')
        return clf, y_pred, y_score

    def plot_roc_curve(self, y_true, y_score, output_path):
        """ROC曲线可视化骨架"""
        fpr, tpr, _ = roc_curve(y_true, y_score)
        roc_auc = auc(fpr, tpr)
        plt.figure(figsize=(8,6))
        plt.plot(fpr, tpr, label=f'AUC={roc_auc:.2f}')
        plt.plot([0,1],[0,1],'--',color='gray')
        plt.xlabel('假阳性率')
        plt.ylabel('真阳性率')
        plt.title('ROC曲线')
        plt.legend()
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
        logger.info(f'ROC曲线已保存: {output_path}')

    def plot_radar(self, score_dict, output_path):
        """雷达图可视化骨架"""
        labels = list(score_dict.keys())
        values = list(score_dict.values())
        values += values[:1]
        angles = np.linspace(0, 2*np.pi, len(labels)+1, endpoint=True)
        plt.figure(figsize=(6,6))
        ax = plt.subplot(111, polar=True)
        ax.plot(angles, values, 'o-', linewidth=2)
        ax.fill(angles, values, alpha=0.25)
        ax.set_thetagrids(np.degrees(angles[:-1]), labels)
        plt.title('多维度评分雷达图')
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
        logger.info(f'雷达图已保存: {output_path}')

    def plot_violin(self, data, labels, output_path):
        """小提琴图可视化骨架"""
        plt.figure(figsize=(8,6))
        plt.violinplot(data)
        plt.xticks(np.arange(1, len(labels)+1), labels)
        plt.title('分数分布小提琴图')
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
        logger.info(f'小提琴图已保存: {output_path}')

    def plot_heatmap(self, matrix, labels, output_path):
        """热力图可视化骨架"""
        plt.figure(figsize=(8,6))
        plt.imshow(matrix, cmap='hot', interpolation='nearest')
        plt.xticks(np.arange(len(labels)), labels, rotation=45)
        plt.yticks(np.arange(len(labels)), labels)
        plt.colorbar()
        plt.title('热力图')
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
        logger.info(f'热力图已保存: {output_path}')

    def plot_box(self, data, labels, output_path):
        """箱线图可视化骨架"""
        plt.figure(figsize=(8,6))
        plt.boxplot(data, labels=labels)
        plt.title('箱线图')
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
        logger.info(f'箱线图已保存: {output_path}') 