import matplotlib.pyplot as plt
import numpy as np
import logging
from matplotlib.patches import Patch

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def plot_radar_comparison(score_dict, output_path):
    """
    综合评分雷达图
    参数:
        score_dict (dict): {模型名: {维度:分数}}
        output_path (str): 输出路径
    """
    labels = list(next(iter(score_dict.values())).keys())
    num_vars = len(labels)
    angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()
    angles += angles[:1]
    plt.figure(figsize=(8, 8))
    for name, scores in score_dict.items():
        values = list(scores.values())
        values += values[:1]
        plt.polar(angles, values, label=name, linewidth=2)
    plt.xticks(angles[:-1], labels)
    plt.title('综合评分雷达图')
    plt.legend(loc='upper right')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"雷达图已保存: {output_path}")

def plot_efficiency_boxplot(time_dict, output_path):
    """
    生成效率箱线图
    参数:
        time_dict (dict): {模型名: [耗时列表]}
        output_path (str): 输出路径
    """
    plt.figure(figsize=(8, 6))
    plt.boxplot(time_dict.values(), labels=time_dict.keys(), patch_artist=True)
    plt.ylabel('生成耗时（秒/图）')
    plt.title('不同模型生成效率箱线图')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"生成效率箱线图已保存: {output_path}")

def plot_pipeline_flow(output_path):
    """
    实验整体流程图
    """
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.axis('off')
    steps = ['数据建构', '模型训练', '生成推理', '评估与可视化']
    for i, step in enumerate(steps):
        ax.add_patch(Patch((0.1 + i*0.2, 0.4), 0.15, 0.2, color='#90caf9'))
        ax.text(0.175 + i*0.2, 0.5, step, ha='center', va='center', fontsize=14)
        if i < len(steps) - 1:
            ax.arrow(0.25 + i*0.2, 0.5, 0.05, 0, head_width=0.03, head_length=0.02, fc='k', ec='k')
    plt.title('实验整体流程')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"实验流程图已保存: {output_path}") 