#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import time
import logging
import numpy as np
import pandas as pd
from datetime import datetime
from tqdm import tqdm
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import torch
from pathlib import Path

# 添加项目路径
sys.path.append('src')
from models.advanced_gold_thread_trainer import AdvancedGoldThreadTrainer
from models.dalle3_generator import DALLE3Generator
from evaluation.comprehensive_evaluator import ComprehensiveEvaluator

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AutomatedComparisonExperiment:
    """自动化对比实验系统 - SDXL vs DALL-E 3"""
    
    def __init__(self, config_path="config/comparison_config.json"):
        """
        初始化自动化对比实验
        
        Args:
            config_path (str): 配置文件路径
        """
        self.config = self._load_config(config_path)
        self.experiment_id = f"comparison_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.output_dir = os.path.join(self.config["output_dir"], self.experiment_id)
        
        # 创建输出目录结构
        self.dirs = {
            "sdxl": os.path.join(self.output_dir, "sdxl_results"),
            "dalle3": os.path.join(self.output_dir, "dalle3_results"),
            "evaluation": os.path.join(self.output_dir, "evaluation"),
            "reports": os.path.join(self.output_dir, "reports"),
            "visualizations": os.path.join(self.output_dir, "visualizations")
        }
        
        for dir_path in self.dirs.values():
            os.makedirs(dir_path, exist_ok=True)
        
        # 初始化生成器
        self.sdxl_trainer = None
        self.dalle3_generator = None
        self.evaluator = None
        
        # 实验状态
        self.experiment_state = {
            "start_time": None,
            "end_time": None,
            "current_stage": "initialized",
            "completed_stages": [],
            "results": {}
        }
        
        logger.info(f"自动化对比实验初始化完成: {self.experiment_id}")
    
    def _load_config(self, config_path):
        """加载实验配置"""
        default_config = {
            "output_dir": "output/experiments",
            "test_prompts": [
                "一品文官仙鹤金线刺绣",
                "二品文官锦鸡金线刺绣", 
                "三品文官孔雀金线刺绣",
                "四品文官云雁金线刺绣",
                "五品文官白鹇金线刺绣",
                "六品文官鹭鸶金线刺绣",
                "七品文官鸂鶒金线刺绣",
                "八品文官鹌鹑金线刺绣",
                "九品文官练鹊金线刺绣",
                "一品武官麒麟金线刺绣"
            ],
            "generation_params": {
                "sdxl": {
                    "num_images_per_prompt": 3,
                    "num_inference_steps": 30,
                    "guidance_scale": 7.5,
                    "image_size": 512
                },
                "dalle3": {
                    "num_images_per_prompt": 3,
                    "size": "1024x1024",
                    "quality": "standard"
                }
            },
            "evaluation_metrics": [
                "fid_score",
                "glcm_texture",
                "clip_similarity", 
                "cultural_accuracy",
                "craft_feasibility",
                "aesthetic_quality"
            ],
            "statistical_tests": [
                "t_test",
                "wilcoxon",
                "effect_size"
            ],
            "visualization_types": [
                "metric_comparison",
                "distribution_plots",
                "correlation_matrix",
                "radar_chart",
                "sample_gallery"
            ]
        }
        
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                default_config.update(config)
        else:
            # 保存默认配置
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(default_config, f, indent=2, ensure_ascii=False)
            logger.info(f"创建默认配置文件: {config_path}")
        
        return default_config
    
    def initialize_models(self):
        """初始化所有模型"""
        logger.info("🔧 初始化模型...")
        
        # 初始化SDXL训练器
        try:
            self.sdxl_trainer = AdvancedGoldThreadTrainer()
            self.sdxl_trainer.initialize_models(for_generation=True)
            logger.info("✅ SDXL训练器初始化成功")
        except Exception as e:
            logger.error(f"❌ SDXL训练器初始化失败: {e}")
            self.sdxl_trainer = None
        
        # 初始化DALL-E 3生成器
        try:
            self.dalle3_generator = DALLE3Generator(
                cache_dir=os.path.join(self.output_dir, "dalle3_cache")
            )
            logger.info("✅ DALL-E 3生成器初始化成功")
        except Exception as e:
            logger.error(f"❌ DALL-E 3生成器初始化失败: {e}")
            self.dalle3_generator = None
        
        # 初始化评估器
        try:
            self.evaluator = ComprehensiveEvaluator()
            logger.info("✅ 评估器初始化成功")
        except Exception as e:
            logger.error(f"❌ 评估器初始化失败: {e}")
            self.evaluator = None
        
        # 检查模型可用性
        available_models = []
        if self.sdxl_trainer: available_models.append("SDXL")
        if self.dalle3_generator: available_models.append("DALL-E 3")
        
        if not available_models:
            raise RuntimeError("没有可用的生成模型")
        
        logger.info(f"可用模型: {', '.join(available_models)}")
    
    def generate_sdxl_images(self, prompts):
        """使用SDXL生成图像"""
        logger.info("🎨 开始SDXL图像生成...")
        
        if not self.sdxl_trainer:
            logger.error("SDXL训练器未初始化")
            return {}
        
        results = {}
        params = self.config["generation_params"]["sdxl"]
        
        for i, prompt in enumerate(tqdm(prompts, desc="SDXL生成")):
            try:
                prompt_results = []
                
                for j in range(params["num_images_per_prompt"]):
                    # 生成图像
                    start_time = time.time()
                    
                    images = self.sdxl_trainer.generate_advanced(
                        prompt=prompt,
                        output_dir=self.dirs["sdxl"],
                        num_images=1
                    )
                    
                    generation_time = time.time() - start_time
                    
                    if images:
                        # 保存图像
                        safe_prompt = "".join(c for c in prompt if c.isalnum() or c in (' ', '-', '_')).rstrip()
                        filename = f"sdxl_{i+1:02d}_{j+1}_{safe_prompt[:30]}.png"
                        image_path = os.path.join(self.dirs["sdxl"], filename)
                        images[0].save(image_path)
                        
                        prompt_results.append({
                            "image_path": image_path,
                            "generation_time": generation_time,
                            "success": True
                        })
                    else:
                        prompt_results.append({
                            "image_path": None,
                            "generation_time": generation_time,
                            "success": False
                        })
                
                results[prompt] = prompt_results
                logger.info(f"SDXL完成提示词 {i+1}/{len(prompts)}: {prompt[:30]}...")
                
            except Exception as e:
                logger.error(f"SDXL生成失败 {prompt}: {e}")
                results[prompt] = []
        
        logger.info(f"✅ SDXL生成完成，共处理 {len(prompts)} 个提示词")
        return results
    
    def generate_dalle3_images(self, prompts):
        """使用DALL-E 3生成图像"""
        logger.info("🎨 开始DALL-E 3图像生成...")
        
        if not self.dalle3_generator:
            logger.error("DALL-E 3生成器未初始化")
            return {}
        
        results = {}
        params = self.config["generation_params"]["dalle3"]
        
        for i, prompt in enumerate(tqdm(prompts, desc="DALL-E 3生成")):
            try:
                prompt_results = []
                
                for j in range(params["num_images_per_prompt"]):
                    # 生成图像
                    start_time = time.time()
                    
                    safe_prompt = "".join(c for c in prompt if c.isalnum() or c in (' ', '-', '_')).rstrip()
                    filename = f"dalle3_{i+1:02d}_{j+1}_{safe_prompt[:30]}.png"
                    image_path = os.path.join(self.dirs["dalle3"], filename)
                    
                    image = self.dalle3_generator.generate(
                        prompt=prompt,
                        size=params["size"],
                        quality=params["quality"],
                        save_path=image_path
                    )
                    
                    generation_time = time.time() - start_time
                    
                    prompt_results.append({
                        "image_path": image_path,
                        "generation_time": generation_time,
                        "success": True
                    })
                
                results[prompt] = prompt_results
                logger.info(f"DALL-E 3完成提示词 {i+1}/{len(prompts)}: {prompt[:30]}...")
                
            except Exception as e:
                logger.error(f"DALL-E 3生成失败 {prompt}: {e}")
                results[prompt] = []
        
        logger.info(f"✅ DALL-E 3生成完成，共处理 {len(prompts)} 个提示词")
        return results
    
    def evaluate_all_images(self, sdxl_results, dalle3_results):
        """评估所有生成的图像"""
        logger.info("📊 开始图像评估...")
        
        if not self.evaluator:
            logger.error("评估器未初始化")
            return {}
        
        evaluation_results = {
            "sdxl": {},
            "dalle3": {},
            "comparison": {}
        }
        
        # 评估SDXL图像
        logger.info("评估SDXL图像...")
        for prompt, images in tqdm(sdxl_results.items(), desc="评估SDXL"):
            prompt_evaluations = []
            for img_info in images:
                if img_info["success"] and os.path.exists(img_info["image_path"]):
                    try:
                        eval_result = self.evaluator.evaluate_single_image(
                            img_info["image_path"], prompt
                        )
                        eval_result["generation_time"] = img_info["generation_time"]
                        prompt_evaluations.append(eval_result)
                    except Exception as e:
                        logger.warning(f"SDXL图像评估失败 {img_info['image_path']}: {e}")
            
            evaluation_results["sdxl"][prompt] = prompt_evaluations
        
        # 评估DALL-E 3图像
        logger.info("评估DALL-E 3图像...")
        for prompt, images in tqdm(dalle3_results.items(), desc="评估DALL-E 3"):
            prompt_evaluations = []
            for img_info in images:
                if img_info["success"] and os.path.exists(img_info["image_path"]):
                    try:
                        eval_result = self.evaluator.evaluate_single_image(
                            img_info["image_path"], prompt
                        )
                        eval_result["generation_time"] = img_info["generation_time"]
                        prompt_evaluations.append(eval_result)
                    except Exception as e:
                        logger.warning(f"DALL-E 3图像评估失败 {img_info['image_path']}: {e}")
            
            evaluation_results["dalle3"][prompt] = prompt_evaluations
        
        # 保存评估结果
        eval_file = os.path.join(self.dirs["evaluation"], "evaluation_results.json")
        with open(eval_file, 'w', encoding='utf-8') as f:
            json.dump(evaluation_results, f, indent=2, ensure_ascii=False)
        
        logger.info(f"✅ 图像评估完成，结果保存: {eval_file}")
        return evaluation_results
    
    def perform_statistical_analysis(self, evaluation_results):
        """执行统计分析"""
        logger.info("📈 开始统计分析...")
        
        # 提取指标数据
        metrics_data = {
            "sdxl": self._extract_metrics(evaluation_results["sdxl"]),
            "dalle3": self._extract_metrics(evaluation_results["dalle3"])
        }
        
        # 执行统计测试
        statistical_results = {}
        
        for metric in self.config["evaluation_metrics"]:
            if metric in metrics_data["sdxl"] and metric in metrics_data["dalle3"]:
                sdxl_values = metrics_data["sdxl"][metric]
                dalle3_values = metrics_data["dalle3"][metric]
                
                # t检验
                from scipy import stats
                t_stat, t_pvalue = stats.ttest_ind(sdxl_values, dalle3_values)
                
                # Wilcoxon秩和检验
                u_stat, u_pvalue = stats.mannwhitneyu(sdxl_values, dalle3_values, alternative='two-sided')
                
                # 效应量 (Cohen's d)
                pooled_std = np.sqrt(((len(sdxl_values) - 1) * np.var(sdxl_values, ddof=1) + 
                                    (len(dalle3_values) - 1) * np.var(dalle3_values, ddof=1)) / 
                                   (len(sdxl_values) + len(dalle3_values) - 2))
                cohens_d = (np.mean(sdxl_values) - np.mean(dalle3_values)) / pooled_std
                
                statistical_results[metric] = {
                    "sdxl_mean": float(np.mean(sdxl_values)),
                    "sdxl_std": float(np.std(sdxl_values)),
                    "dalle3_mean": float(np.mean(dalle3_values)),
                    "dalle3_std": float(np.std(dalle3_values)),
                    "t_test": {"statistic": float(t_stat), "p_value": float(t_pvalue)},
                    "wilcoxon": {"statistic": float(u_stat), "p_value": float(u_pvalue)},
                    "effect_size": float(cohens_d),
                    "significant": t_pvalue < 0.05
                }
        
        # 保存统计结果
        stats_file = os.path.join(self.dirs["evaluation"], "statistical_analysis.json")
        with open(stats_file, 'w', encoding='utf-8') as f:
            json.dump(statistical_results, f, indent=2, ensure_ascii=False)
        
        logger.info(f"✅ 统计分析完成，结果保存: {stats_file}")
        return statistical_results
    
    def _extract_metrics(self, evaluation_data):
        """从评估数据中提取指标"""
        metrics = {}
        
        for prompt, evaluations in evaluation_data.items():
            for eval_result in evaluations:
                for metric, value in eval_result.items():
                    if isinstance(value, (int, float)) and not np.isnan(value):
                        if metric not in metrics:
                            metrics[metric] = []
                        metrics[metric].append(value)
        
        return metrics
    
    def create_visualizations(self, evaluation_results, statistical_results):
        """创建可视化图表"""
        logger.info("📊 创建可视化图表...")
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei']
        plt.rcParams['axes.unicode_minus'] = False
        
        # 1. 指标对比图
        self._create_metric_comparison(statistical_results)
        
        # 2. 分布图
        self._create_distribution_plots(evaluation_results)
        
        # 3. 相关性矩阵
        self._create_correlation_matrix(evaluation_results)
        
        # 4. 雷达图
        self._create_radar_chart(statistical_results)
        
        # 5. 样本画廊
        self._create_sample_gallery(evaluation_results)
        
        logger.info("✅ 可视化图表创建完成")
    
    def _create_metric_comparison(self, statistical_results):
        """创建指标对比图"""
        metrics = list(statistical_results.keys())
        sdxl_means = [statistical_results[m]["sdxl_mean"] for m in metrics]
        dalle3_means = [statistical_results[m]["dalle3_mean"] for m in metrics]
        
        x = np.arange(len(metrics))
        width = 0.35
        
        fig, ax = plt.subplots(figsize=(12, 8))
        bars1 = ax.bar(x - width/2, sdxl_means, width, label='SDXL', alpha=0.8)
        bars2 = ax.bar(x + width/2, dalle3_means, width, label='DALL-E 3', alpha=0.8)
        
        ax.set_xlabel('Evaluation Metrics')
        ax.set_ylabel('Score')
        ax.set_title('SDXL vs DALL-E 3 Metrics Comparison')
        ax.set_xticks(x)
        ax.set_xticklabels(metrics, rotation=45, ha='right')
        ax.legend()
        
        # 添加显著性标记
        for i, metric in enumerate(metrics):
            if statistical_results[metric]["significant"]:
                ax.text(i, max(sdxl_means[i], dalle3_means[i]) + 0.1, '*', 
                       ha='center', va='bottom', fontsize=16, color='red')
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.dirs["visualizations"], "metric_comparison.png"), 
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def _create_distribution_plots(self, evaluation_results):
        """创建分布图"""
        metrics_data = {
            "sdxl": self._extract_metrics(evaluation_results["sdxl"]),
            "dalle3": self._extract_metrics(evaluation_results["dalle3"])
        }
        
        # 选择主要指标
        main_metrics = ["fid_score", "glcm_texture", "clip_similarity", "cultural_accuracy"]
        available_metrics = [m for m in main_metrics if m in metrics_data["sdxl"]]
        
        if not available_metrics:
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        axes = axes.flatten()
        
        for i, metric in enumerate(available_metrics[:4]):
            if i >= len(axes):
                break
                
            ax = axes[i]
            
            # 绘制分布
            if metric in metrics_data["sdxl"]:
                ax.hist(metrics_data["sdxl"][metric], alpha=0.7, label='SDXL', bins=20)
            if metric in metrics_data["dalle3"]:
                ax.hist(metrics_data["dalle3"][metric], alpha=0.7, label='DALL-E 3', bins=20)
            
            ax.set_xlabel(metric)
            ax.set_ylabel('Frequency')
            ax.set_title(f'{metric} Distribution')
            ax.legend()
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.dirs["visualizations"], "distribution_plots.png"), 
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def _create_correlation_matrix(self, evaluation_results):
        """创建相关性矩阵"""
        # 合并所有数据
        all_data = []
        
        for model in ["sdxl", "dalle3"]:
            for prompt, evaluations in evaluation_results[model].items():
                for eval_result in evaluations:
                    row = {"model": model}
                    for metric, value in eval_result.items():
                        if isinstance(value, (int, float)) and not np.isnan(value):
                            row[metric] = value
                    all_data.append(row)
        
        if not all_data:
            return
        
        df = pd.DataFrame(all_data)
        
        # 只保留数值列
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) < 2:
            return
        
        correlation_matrix = df[numeric_cols].corr()
        
        plt.figure(figsize=(12, 10))
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0,
                   square=True, fmt='.2f')
        plt.title('指标相关性矩阵')
        plt.tight_layout()
        plt.savefig(os.path.join(self.dirs["visualizations"], "correlation_matrix.png"), 
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def _create_radar_chart(self, statistical_results):
        """创建雷达图"""
        metrics = list(statistical_results.keys())[:6]  # 最多6个指标
        if len(metrics) < 3:
            return
        
        # 归一化数据到0-1范围
        sdxl_values = []
        dalle3_values = []
        
        for metric in metrics:
            sdxl_val = statistical_results[metric]["sdxl_mean"]
            dalle3_val = statistical_results[metric]["dalle3_mean"]
            
            # 简单归一化
            max_val = max(sdxl_val, dalle3_val)
            min_val = min(sdxl_val, dalle3_val)
            range_val = max_val - min_val if max_val != min_val else 1
            
            sdxl_norm = (sdxl_val - min_val) / range_val
            dalle3_norm = (dalle3_val - min_val) / range_val
            
            sdxl_values.append(sdxl_norm)
            dalle3_values.append(dalle3_norm)
        
        # 创建雷达图
        angles = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False).tolist()
        angles += angles[:1]  # 闭合
        
        sdxl_values += sdxl_values[:1]
        dalle3_values += dalle3_values[:1]
        
        fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(projection='polar'))
        
        ax.plot(angles, sdxl_values, 'o-', linewidth=2, label='SDXL', color='blue')
        ax.fill(angles, sdxl_values, alpha=0.25, color='blue')
        
        ax.plot(angles, dalle3_values, 'o-', linewidth=2, label='DALL-E 3', color='red')
        ax.fill(angles, dalle3_values, alpha=0.25, color='red')
        
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(metrics)
        ax.set_ylim(0, 1)
        ax.set_title('Model Performance Radar Chart', size=16, pad=20)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0))
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.dirs["visualizations"], "radar_chart.png"), 
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def _create_sample_gallery(self, evaluation_results):
        """创建样本画廊"""
        # 选择最佳样本
        best_samples = {"sdxl": [], "dalle3": []}
        
        for model in ["sdxl", "dalle3"]:
            for prompt, evaluations in evaluation_results[model].items():
                if evaluations:
                    # 选择评分最高的样本
                    best_eval = max(evaluations, key=lambda x: x.get("overall_score", 0))
                    if "image_path" in best_eval and os.path.exists(best_eval["image_path"]):
                        best_samples[model].append({
                            "image_path": best_eval["image_path"],
                            "prompt": prompt,
                            "score": best_eval.get("overall_score", 0)
                        })
        
        # 创建画廊
        n_samples = min(6, len(best_samples["sdxl"]), len(best_samples["dalle3"]))
        if n_samples == 0:
            return
        
        fig, axes = plt.subplots(2, n_samples, figsize=(4*n_samples, 8))
        if n_samples == 1:
            axes = axes.reshape(2, 1)
        
        for i in range(n_samples):
            # SDXL样本
            if i < len(best_samples["sdxl"]):
                img_path = best_samples["sdxl"][i]["image_path"]
                if os.path.exists(img_path):
                    img = Image.open(img_path)
                    axes[0, i].imshow(img)
                    axes[0, i].set_title(f"SDXL\n{best_samples['sdxl'][i]['prompt'][:20]}...", fontsize=10)
                    axes[0, i].axis('off')
            
            # DALL-E 3样本
            if i < len(best_samples["dalle3"]):
                img_path = best_samples["dalle3"][i]["image_path"]
                if os.path.exists(img_path):
                    img = Image.open(img_path)
                    axes[1, i].imshow(img)
                    axes[1, i].set_title(f"DALL-E 3\n{best_samples['dalle3'][i]['prompt'][:20]}...", fontsize=10)
                    axes[1, i].axis('off')
        
        plt.suptitle('最佳样本对比', fontsize=16)
        plt.tight_layout()
        plt.savefig(os.path.join(self.dirs["visualizations"], "sample_gallery.png"), 
                   dpi=300, bbox_inches='tight')
        plt.close()
    
    def generate_comprehensive_report(self, evaluation_results, statistical_results):
        """生成综合报告"""
        logger.info("📝 生成综合报告...")
        
        report = {
            "experiment_info": {
                "experiment_id": self.experiment_id,
                "start_time": self.experiment_state["start_time"],
                "end_time": self.experiment_state["end_time"],
                "duration": (self.experiment_state["end_time"] - self.experiment_state["start_time"]).total_seconds(),
                "test_prompts": self.config["test_prompts"],
                "generation_params": self.config["generation_params"]
            },
            "summary": {
                "total_images_generated": self._count_generated_images(evaluation_results),
                "evaluation_metrics": list(statistical_results.keys()),
                "significant_differences": [m for m, r in statistical_results.items() if r["significant"]],
                "best_performing_model": self._determine_best_model(statistical_results)
            },
            "detailed_results": {
                "statistical_analysis": statistical_results,
                "model_comparison": self._create_model_comparison_summary(statistical_results)
            },
            "conclusions": self._generate_conclusions(statistical_results),
            "recommendations": self._generate_recommendations(statistical_results)
        }
        
        # 保存JSON报告
        report_file = os.path.join(self.dirs["reports"], "comprehensive_report.json")
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False, default=str)
        
        # 生成Markdown报告
        self._generate_markdown_report(report)
        
        logger.info(f"✅ 综合报告生成完成: {report_file}")
        return report
    
    def _count_generated_images(self, evaluation_results):
        """统计生成的图像数量"""
        count = {"sdxl": 0, "dalle3": 0}
        
        for model in ["sdxl", "dalle3"]:
            for prompt, evaluations in evaluation_results[model].items():
                count[model] += len(evaluations)
        
        return count
    
    def _determine_best_model(self, statistical_results):
        """确定最佳模型"""
        sdxl_wins = 0
        dalle3_wins = 0
        
        for metric, results in statistical_results.items():
            if results["sdxl_mean"] > results["dalle3_mean"]:
                sdxl_wins += 1
            else:
                dalle3_wins += 1
        
        if sdxl_wins > dalle3_wins:
            return "SDXL"
        elif dalle3_wins > sdxl_wins:
            return "DALL-E 3"
        else:
            return "平局"
    
    def _create_model_comparison_summary(self, statistical_results):
        """创建模型对比摘要"""
        summary = {}
        
        for metric, results in statistical_results.items():
            summary[metric] = {
                "winner": "SDXL" if results["sdxl_mean"] > results["dalle3_mean"] else "DALL-E 3",
                "difference": abs(results["sdxl_mean"] - results["dalle3_mean"]),
                "effect_size": results["effect_size"],
                "significance": "显著" if results["significant"] else "不显著"
            }
        
        return summary
    
    def _generate_conclusions(self, statistical_results):
        """生成结论"""
        conclusions = []
        
        # 整体性能
        best_model = self._determine_best_model(statistical_results)
        conclusions.append(f"整体而言，{best_model}在更多指标上表现更好。")
        
        # 显著差异
        significant_metrics = [m for m, r in statistical_results.items() if r["significant"]]
        if significant_metrics:
            conclusions.append(f"在{len(significant_metrics)}个指标上发现显著差异：{', '.join(significant_metrics)}。")
        else:
            conclusions.append("两个模型在所有指标上均无显著差异。")
        
        # 效应量分析
        large_effects = [m for m, r in statistical_results.items() if abs(r["effect_size"]) > 0.8]
        if large_effects:
            conclusions.append(f"以下指标显示大效应量：{', '.join(large_effects)}。")
        
        return conclusions
    
    def _generate_recommendations(self, statistical_results):
        """生成建议"""
        recommendations = []
        
        # 基于结果的建议
        best_model = self._determine_best_model(statistical_results)
        
        if best_model == "SDXL":
            recommendations.append("建议在金线刺绣生成任务中优先使用SDXL模型。")
            recommendations.append("SDXL在文化准确性和工艺可行性方面表现更好。")
        elif best_model == "DALL-E 3":
            recommendations.append("建议在金线刺绣生成任务中优先使用DALL-E 3模型。")
            recommendations.append("DALL-E 3在图像质量和美学方面表现更好。")
        else:
            recommendations.append("两个模型各有优势，建议根据具体需求选择。")
        
        # 改进建议
        recommendations.append("建议进一步优化提示词工程以提高生成质量。")
        recommendations.append("考虑结合两个模型的优势进行集成生成。")
        
        return recommendations
    
    def _generate_markdown_report(self, report):
        """生成Markdown格式报告"""
        md_content = f"""# 金线刺绣生成模型对比实验报告

## 实验概述

- **实验ID**: {report['experiment_info']['experiment_id']}
- **开始时间**: {report['experiment_info']['start_time']}
- **结束时间**: {report['experiment_info']['end_time']}
- **总耗时**: {report['experiment_info']['duration']:.2f} 秒

## 实验设置

### 测试提示词
{chr(10).join([f"- {prompt}" for prompt in report['experiment_info']['test_prompts']])}

### 生成参数
- **SDXL**: {report['experiment_info']['generation_params']['sdxl']}
- **DALL-E 3**: {report['experiment_info']['generation_params']['dalle3']}

## 实验结果

### 图像生成统计
- **SDXL**: {report['summary']['total_images_generated']['sdxl']} 张
- **DALL-E 3**: {report['summary']['total_images_generated']['dalle3']} 张

### 最佳模型
**{report['summary']['best_performing_model']}** 在整体评估中表现最佳。

### 显著差异指标
{chr(10).join([f"- {metric}" for metric in report['summary']['significant_differences']])}

## 详细分析

### 统计结果
| 指标 | SDXL均值 | DALL-E 3均值 | p值 | 效应量 | 显著性 |
|------|----------|--------------|-----|--------|--------|
"""
        
        for metric, results in report['detailed_results']['statistical_analysis'].items():
            md_content += f"| {metric} | {results['sdxl_mean']:.3f} | {results['dalle3_mean']:.3f} | {results['t_test']['p_value']:.3f} | {results['effect_size']:.3f} | {'是' if results['significant'] else '否'} |\n"
        
        md_content += f"""
## 结论

{chr(10).join([f"- {conclusion}" for conclusion in report['conclusions']])}

## 建议

{chr(10).join([f"- {recommendation}" for recommendation in report['recommendations']])}

## 可视化图表

- [指标对比图](../visualizations/metric_comparison.png)
- [分布图](../visualizations/distribution_plots.png)
- [相关性矩阵](../visualizations/correlation_matrix.png)
- [雷达图](../visualizations/radar_chart.png)
- [样本画廊](../visualizations/sample_gallery.png)

---
*报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""
        
        # 保存Markdown报告
        md_file = os.path.join(self.dirs["reports"], "experiment_report.md")
        with open(md_file, 'w', encoding='utf-8') as f:
            f.write(md_content)
        
        logger.info(f"Markdown报告已保存: {md_file}")
    
    def run_full_experiment(self):
        """运行完整的对比实验"""
        logger.info("🚀 开始完整的自动化对比实验")
        logger.info("=" * 60)
        
        self.experiment_state["start_time"] = datetime.now()
        self.experiment_state["current_stage"] = "initializing"
        
        try:
            # 1. 初始化模型
            self.experiment_state["current_stage"] = "model_initialization"
            self.initialize_models()
            self.experiment_state["completed_stages"].append("model_initialization")
            
            # 2. 生成图像
            prompts = self.config["test_prompts"]
            
            # SDXL生成
            self.experiment_state["current_stage"] = "sdxl_generation"
            sdxl_results = self.generate_sdxl_images(prompts)
            self.experiment_state["completed_stages"].append("sdxl_generation")
            
            # DALL-E 3生成
            self.experiment_state["current_stage"] = "dalle3_generation"
            dalle3_results = self.generate_dalle3_images(prompts)
            self.experiment_state["completed_stages"].append("dalle3_generation")
            
            # 3. 评估图像
            self.experiment_state["current_stage"] = "evaluation"
            evaluation_results = self.evaluate_all_images(sdxl_results, dalle3_results)
            self.experiment_state["completed_stages"].append("evaluation")
            
            # 4. 统计分析
            self.experiment_state["current_stage"] = "statistical_analysis"
            statistical_results = self.perform_statistical_analysis(evaluation_results)
            self.experiment_state["completed_stages"].append("statistical_analysis")
            
            # 5. 创建可视化
            self.experiment_state["current_stage"] = "visualization"
            self.create_visualizations(evaluation_results, statistical_results)
            self.experiment_state["completed_stages"].append("visualization")
            
            # 6. 生成报告
            self.experiment_state["current_stage"] = "report_generation"
            comprehensive_report = self.generate_comprehensive_report(evaluation_results, statistical_results)
            self.experiment_state["completed_stages"].append("report_generation")
            
            self.experiment_state["end_time"] = datetime.now()
            self.experiment_state["current_stage"] = "completed"
            
            # 保存实验状态
            state_file = os.path.join(self.output_dir, "experiment_state.json")
            with open(state_file, 'w', encoding='utf-8') as f:
                json.dump(self.experiment_state, f, indent=2, ensure_ascii=False, default=str)
            
            # 显示结果摘要
            duration = self.experiment_state["end_time"] - self.experiment_state["start_time"]
            logger.info("\n" + "=" * 60)
            logger.info("🎉 自动化对比实验完成！")
            logger.info(f"📊 实验ID: {self.experiment_id}")
            logger.info(f"⏱️  总耗时: {duration.total_seconds():.2f} 秒")
            logger.info(f"🏆 最佳模型: {comprehensive_report['summary']['best_performing_model']}")
            logger.info(f"📁 结果目录: {self.output_dir}")
            logger.info(f"📝 报告文件: {os.path.join(self.dirs['reports'], 'experiment_report.md')}")
            
            return comprehensive_report
            
        except Exception as e:
            self.experiment_state["end_time"] = datetime.now()
            self.experiment_state["current_stage"] = "failed"
            self.experiment_state["error"] = str(e)
            
            logger.error(f"❌ 实验失败: {e}")
            import traceback
            traceback.print_exc()
            
            # 保存失败状态
            state_file = os.path.join(self.output_dir, "experiment_state.json")
            with open(state_file, 'w', encoding='utf-8') as f:
                json.dump(self.experiment_state, f, indent=2, ensure_ascii=False, default=str)
            
            raise

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="自动化对比实验 - SDXL vs DALL-E 3")
    parser.add_argument("--config", type=str, default="config/comparison_config.json",
                       help="配置文件路径")
    parser.add_argument("--output_dir", type=str, default="output/experiments",
                       help="输出目录")
    parser.add_argument("--openai_api_key", type=str, help="OpenAI API密钥")
    
    args = parser.parse_args()
    
    # 设置API密钥
    if args.openai_api_key:
        os.environ['OPENAI_API_KEY'] = args.openai_api_key
    
    # 创建实验
    experiment = AutomatedComparisonExperiment(config_path=args.config)
    
    # 运行实验
    try:
        report = experiment.run_full_experiment()
        print(f"\n✅ 实验成功完成！")
        print(f"📊 最佳模型: {report['summary']['best_performing_model']}")
        print(f"📁 结果目录: {experiment.output_dir}")
    except Exception as e:
        print(f"\n❌ 实验失败: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 