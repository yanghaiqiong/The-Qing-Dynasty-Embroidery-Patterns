import os
import argparse
import logging
import json
import sys
import torch

# 将src目录添加到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入项目模块
from src.data_processing.data_processor import DataProcessor
from src.models.model_trainer import GoldThreadModelTrainer

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("../output/gold_thread_embroidery.log", mode='a'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def process_data(args):
    """
    处理数据
    
    参数:
        args: 命令行参数
    """
    logger.info("开始数据处理...")
    
    # 创建数据处理器
    processor = DataProcessor(
        data_dir=args.data_dir,
        output_dir=args.output_dir
    )
    
    # 处理所有层数据
    processor.process_all(simulate_craft=args.simulate_craft)
    
    logger.info("数据处理完成")

def train_model(args):
    """
    训练模型
    
    参数:
        args: 命令行参数
    """
    logger.info("开始模型训练...")
    
    # 创建模型训练器
    trainer = GoldThreadModelTrainer(config_path=args.config)
    
    # 训练模型
    trainer.train(args.data_dir)
    
    logger.info("模型训练完成")

def generate_samples(args):
    """
    生成样本
    
    参数:
        args: 命令行参数
    """
    logger.info(f"开始生成样本: {args.prompt}...")
    
    # 创建模型训练器
    trainer = GoldThreadModelTrainer(config_path=args.config)
    
    # 生成样本
    output_dir = os.path.join(args.output_dir, "generation", args.pattern_type.replace(" ", "_"))
    os.makedirs(output_dir, exist_ok=True)
    
    generated_images = trainer.generate(
        prompt=args.prompt,
        pattern_type=args.pattern_type,
        output_dir=output_dir,
        num_images=args.num_images
    )
    
    logger.info(f"已生成 {len(generated_images)} 张图像，保存在 {output_dir}")

def run_experiment(args):
    """
    运行实验
    
    参数:
        args: 命令行参数
    """
    logger.info(f"开始运行实验: {args.prompt}...")
    
    # 创建模型训练器
    trainer = GoldThreadModelTrainer(config_path=args.config)
    
    # 运行实验
    output_dir = os.path.join(args.output_dir, "experiment", args.pattern_type.replace(" ", "_"))
    os.makedirs(output_dir, exist_ok=True)
    
    results = trainer.run_comparative_experiment(
        prompt=args.prompt,
        pattern_type=args.pattern_type,
        output_dir=output_dir
    )
    
    logger.info(f"实验完成，结果保存在 {output_dir}")

def main():
    """主函数入口"""
    parser = argparse.ArgumentParser(description="金线刺绣多模态生成系统")
    
    # 通用参数
    parser.add_argument("--data_dir", type=str, default="data", help="数据目录")
    parser.add_argument("--output_dir", type=str, default="output", help="输出目录")
    parser.add_argument("--config", type=str, default="config/default_config.json", help="配置文件路径")
    
    # 子命令
    subparsers = parser.add_subparsers(dest="command", help="子命令")
    
    # 数据处理子命令
    data_parser = subparsers.add_parser("process_data", help="处理数据")
    data_parser.add_argument("--simulate_craft", action="store_true", help="是否使用模拟工艺数据")
    
    # 训练模型子命令
    train_parser = subparsers.add_parser("train", help="训练模型")
    
    # 生成样本子命令
    generate_parser = subparsers.add_parser("generate", help="生成样本")
    generate_parser.add_argument("--prompt", type=str, required=True, help="生成提示词")
    generate_parser.add_argument("--pattern_type", type=str, required=True, help="图案类型")
    generate_parser.add_argument("--num_images", type=int, default=1, help="生成图像数量")
    
    # 运行实验子命令
    experiment_parser = subparsers.add_parser("experiment", help="运行实验")
    experiment_parser.add_argument("--prompt", type=str, required=True, help="生成提示词")
    experiment_parser.add_argument("--pattern_type", type=str, required=True, help="图案类型")
    
    # 解析参数
    args = parser.parse_args()
    
    # 检查输出目录
    os.makedirs(args.output_dir, exist_ok=True)
    
    # 检查配置文件
    if not os.path.exists(args.config):
        logger.error(f"配置文件不存在: {args.config}")
        return
    
    # 检查GPU可用性
    logger.info(f"CUDA是否可用: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        logger.info(f"GPU数量: {torch.cuda.device_count()}")
        logger.info(f"GPU型号: {torch.cuda.get_device_name(0)}")
    
    # 执行子命令
    if args.command == "process_data":
        process_data(args)
    elif args.command == "train":
        train_model(args)
    elif args.command == "generate":
        generate_samples(args)
    elif args.command == "experiment":
        run_experiment(args)
    else:
        logger.error("未指定子命令，请使用 --help 查看帮助")
        parser.print_help()

if __name__ == "__main__":
    main() 