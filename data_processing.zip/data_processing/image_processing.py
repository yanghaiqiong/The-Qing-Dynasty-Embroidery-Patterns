import os
import cv2
import numpy as np
from PIL import Image
import torch
from tqdm import tqdm
import matplotlib.pyplot as plt
from skimage.metrics import structural_similarity as ssim
from colormath.color_diff import delta_e_cie2000
from colormath.color_objects import LabColor, sRGBColor
import logging
import subprocess
import uuid
import shutil
import tempfile
import random
import time

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ImageProcessor:
    """金线刺绣图像处理类，用于多光源扫描处理和超分辨率重建"""
    
    def __init__(self, data_dir, output_dir, ncnn_exe_path='./realesrgan-ncnn-vulkan-20220424-windows/realesrgan-ncnn-vulkan.exe'):
        """
        初始化图像处理器
        
        参数:
            data_dir (str): 输入图像目录
            output_dir (str): 输出图像目录
            ncnn_exe_path (str): Real-ESRGAN ncnn-vulkan 可执行文件路径
        """
        self.data_dir = data_dir
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)
        self.ncnn_exe_path = os.path.abspath(ncnn_exe_path)
        if not os.path.exists(self.ncnn_exe_path):
            raise FileNotFoundError(f"未找到 Real-ESRGAN ncnn-vulkan 可执行文件: {self.ncnn_exe_path}")
    
    def safe_path(self, path):
        """
        去除路径和文件名中的所有空格，保留中文
        """
        return path.replace(' ', '')
    
    def preprocess_image(self, image_path, target_dpi=600):
        """
        图像预处理
        
        参数:
            image_path (str): 图像路径
            target_dpi (int): 目标DPI
            
        返回:
            PIL.Image: 预处理后的图像
        """
        img = Image.open(image_path)
        
        # 获取原始DPI
        original_dpi = img.info.get('dpi', (72, 72))
        original_dpi = original_dpi[0]  # 取横向DPI
        
        # 如果DPI低于目标DPI，调整大小
        if original_dpi < target_dpi:
            scale_factor = target_dpi / original_dpi
            new_width = int(img.width * scale_factor)
            new_height = int(img.height * scale_factor)
            img = img.resize((new_width, new_height), Image.LANCZOS)
        
        return img
    
    def multi_light_fusion(self, diffuse_path, side_path, polarized_path, output_path=None):
        """
        融合多光源图像（漫射光/侧光/偏振光）
        
        参数:
            diffuse_path (str): 漫射光图像路径
            side_path (str): 侧光图像路径
            polarized_path (str): 偏振光图像路径
            output_path (str, optional): 输出路径
            
        返回:
            np.ndarray: 融合后的图像
        """
        # 读取三种光源下的图像
        diffuse_img = cv2.imread(diffuse_path)
        side_img = cv2.imread(side_path)
        polarized_img = cv2.imread(polarized_path)
        
        # 确保所有图像具有相同尺寸
        if diffuse_img.shape != side_img.shape or diffuse_img.shape != polarized_img.shape:
            # 调整为与漫射光图像相同大小
            side_img = cv2.resize(side_img, (diffuse_img.shape[1], diffuse_img.shape[0]))
            polarized_img = cv2.resize(polarized_img, (diffuse_img.shape[1], diffuse_img.shape[0]))
        
        # 转换为浮点数进行融合
        diffuse_img = diffuse_img.astype(np.float32) / 255.0
        side_img = side_img.astype(np.float32) / 255.0
        polarized_img = polarized_img.astype(np.float32) / 255.0
        
        # 权重融合 (可根据需要调整权重)
        weights = [0.5, 0.3, 0.2]  # 漫射光、侧光、偏振光的权重
        fused_img = weights[0] * diffuse_img + weights[1] * side_img + weights[2] * polarized_img
        
        # 归一化并转回8位图像
        fused_img = np.clip(fused_img * 255, 0, 255).astype(np.uint8)
        
        # 保存融合图像
        if output_path:
            cv2.imwrite(output_path, fused_img)
        
        return fused_img
    
    def super_resolution_ncnn(self, input_path, output_path, scale=4, model_name='realesrgan-x4plus'):
        """
        调用 Real-ESRGAN ncnn-vulkan exe 进行超分辨率，兼容中文路径。
        """
        temp_dir = tempfile.mkdtemp()
        temp_input = os.path.join(temp_dir, 'input.png')
        temp_output = os.path.join(temp_dir, 'output.png')
        try:
            shutil.copy(input_path, temp_input)
        except Exception as e:
            logger.error(f'复制图片到临时目录失败: {input_path} -> {temp_input}, 错误: {e}')
            shutil.rmtree(temp_dir)
            return
        # 检查图片尺寸，过大则自动缩放
        img = cv2.imread(temp_input)
        if img is None:
            logger.error(f'无法读取图片: {temp_input}，请检查路径和文件完整性，已跳过。')
            shutil.rmtree(temp_dir)
            return
        h, w = img.shape[:2]
        max_size = 4096
        if max(h, w) > max_size:
            scale_factor = max_size / max(h, w)
            new_size = (int(w * scale_factor), int(h * scale_factor))
            img = cv2.resize(img, new_size, interpolation=cv2.INTER_LANCZOS4)
            cv2.imwrite(temp_input, img)
            print(f"图片过大，已自动缩放到{new_size}")
        cmd = [
            self.ncnn_exe_path,
            '-g', '0',
            '-i', temp_input,
            '-o', temp_output,
            '-n', model_name,
            '-s', str(scale)
        ]
        logger.info(f"调用Real-ESRGAN命令: {' '.join(cmd)}")
        try:
            result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=600)
            logger.info(result.stdout.decode('utf-8', errors='ignore'))
            shutil.copy(temp_output, output_path)
        except subprocess.TimeoutExpired:
            logger.error(f"超分进程超时，跳过: {input_path}")
        except subprocess.CalledProcessError as e:
            err_msg = e.stderr.decode('utf-8', errors='ignore')
            logger.error(f"[NCNN ERROR] {err_msg}")
            if "vkCreateInstance failed" in err_msg or "invalid gpu device" in err_msg:
                logger.error(f"Real-ESRGAN ncnn-vulkan 处理失败，未检测到可用的Vulkan GPU设备。错误信息: {err_msg}")
            else:
                logger.error(f"Real-ESRGAN ncnn-vulkan 处理失败: {input_path}\n错误信息: {err_msg}")
        except Exception as e:
            logger.error(f"未知错误: {e}")
        finally:
            shutil.rmtree(temp_dir)
    
    def calculate_ssim(self, img1, img2):
        """
        计算结构相似性指标(SSIM)
        
        参数:
            img1, img2 (np.ndarray): 要比较的两张图像
            
        返回:
            float: SSIM值
        """
        # 转换为灰度图
        if len(img1.shape) == 3:
            gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        else:
            gray1 = img1
            
        if len(img2.shape) == 3:
            gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
        else:
            gray2 = img2
        
        # 确保两张图像尺寸相同
        if gray1.shape != gray2.shape:
            gray2 = cv2.resize(gray2, (gray1.shape[1], gray1.shape[0]))
        
        # 计算SSIM
        ssim_value = ssim(gray1, gray2, data_range=255)
        return ssim_value
    
    def calculate_color_error(self, img1, img2):
        """
        计算色彩误差(ΔE)
        
        参数:
            img1, img2 (np.ndarray): BGR格式的图像
            
        返回:
            float: 平均ΔE值
        """
        # 确保两张图像尺寸相同
        if img1.shape != img2.shape:
            img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))
        # 转换为RGB格式
        img1_rgb = cv2.cvtColor(img1, cv2.COLOR_BGR2RGB)
        img2_rgb = cv2.cvtColor(img2, cv2.COLOR_BGR2RGB)
        # 转换为Lab
        img1_lab = cv2.cvtColor(img1_rgb, cv2.COLOR_RGB2LAB)
        img2_lab = cv2.cvtColor(img2_rgb, cv2.COLOR_RGB2LAB)
        # 计算ΔE值
        delta_e_map = np.zeros(img1_lab.shape[:2])
        for i in range(img1_lab.shape[0]):
            for j in range(img1_lab.shape[1]):
                c1 = LabColor(float(img1_lab[i, j][0]), float(img1_lab[i, j][1]), float(img1_lab[i, j][2]))
                c2 = LabColor(float(img2_lab[i, j][0]), float(img2_lab[i, j][1]), float(img2_lab[i, j][2]))
                delta_e_map[i, j] = delta_e_cie2000(c1, c2)
        mean_delta_e = np.mean(delta_e_map)
        return mean_delta_e
    
    def remove_space_path(self, path):
        """
        递归去除路径中所有目录和文件名的空格
        """
        return os.path.join(*[p.replace(' ', '') for p in path.split(os.sep)])
    
    def process_image_directory(self, pattern_type, light_type=None):
        """
        处理特定类型图案的所有图像
        
        参数:
            pattern_type (str): 图案类型目录
            light_type (str, optional): 光源类型，如果为None则处理多光源融合
        """
        import uuid
        source_dir = os.path.join(self.data_dir, pattern_type)  # 原始数据目录不变
        # 输出目录、文件名全部去空格
        target_dir = self.remove_space_path(os.path.join(self.output_dir, pattern_type))
        os.makedirs(target_dir, exist_ok=True)
        image_files = [f for f in os.listdir(source_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        # 检查是否已全部处理
        processed = True
        for img_file in image_files:
            base_name = os.path.splitext(img_file)[0].replace(' ', '')
            sr_path = os.path.join(target_dir, f"{base_name}_SR.png")
            fused_sr_path = os.path.join(target_dir, f"{base_name}_fused_SR.png")
            if not (os.path.exists(sr_path) or os.path.exists(fused_sr_path)):
                processed = False
                break
        if processed:
            print(f"类别 {pattern_type} 已全部处理，自动跳过。")
            return
        # 否则只处理未处理的图片
        for img_file in tqdm(image_files, desc=f"处理{pattern_type}中的图像"):
            base_name = os.path.splitext(img_file)[0]
            base_name_nospace = base_name.replace(' ', '')
            diffuse_path = os.path.join(source_dir, f"{base_name}_diffuse.png")
            side_path = os.path.join(source_dir, f"{base_name}_side.png")
            polarized_path = os.path.join(source_dir, f"{base_name}_polarized.png")
            fused_path = self.remove_space_path(os.path.join(target_dir, f"{base_name_nospace}_fused.png"))
            sr_path = self.remove_space_path(os.path.join(target_dir, f"{base_name_nospace}_fused_SR.png"))
            output_path = self.remove_space_path(os.path.join(target_dir, f"{base_name_nospace}_SR.png"))
            # 跳过已处理图片
            if os.path.exists(sr_path) or os.path.exists(output_path):
                continue
            if os.path.exists(diffuse_path) and os.path.exists(side_path) and os.path.exists(polarized_path):
                self.multi_light_fusion(diffuse_path, side_path, polarized_path, fused_path)
                self.super_resolution_ncnn(fused_path, sr_path)
            else:
                self.super_resolution_ncnn(os.path.join(source_dir, img_file), output_path)
    
    def robust_imread(self, path):
        """
        使用PIL读取图片并转为numpy数组，兼容中文路径和特殊字符。
        """
        try:
            img = Image.open(path)
            return np.array(img)
        except Exception as e:
            logger.error(f'PIL无法读取图片: {path}，错误: {e}')
            return None
    
    def evaluate_dataset(self, original_dir, processed_dir, max_samples=5):
        """
        评估处理后数据集的质量
        
        参数:
            original_dir (str): 原始图像目录
            processed_dir (str): 处理后图像目录
            max_samples (int, optional): 随机抽取评估的样本数，None为全量评估
        返回:
            tuple: 平均SSIM值, 平均ΔE值, ssim_values, delta_e_values, resolutions
        """
        pairs = []
        for root, _, files in os.walk(processed_dir):
            for file in files:
                if file.endswith('.png') and '_SR' in file:
                    processed_path = os.path.abspath(os.path.normpath(os.path.join(root, file)))
                    relative_path = os.path.relpath(root, processed_dir)
                    base_name = file.replace('_diffuse_SR.png', '.png').replace('_side_SR.png', '.png').replace('_polarized_SR.png', '.png').replace('_fused_SR.png', '.png').replace('_SR.png', '.png')
                    original_path = os.path.abspath(os.path.normpath(os.path.join(original_dir, relative_path, base_name)))
                    file_size = os.path.getsize(processed_path)
                    pairs.append((file_size, original_path, processed_path, base_name))
        # 先按文件大小升序取前100个，再随机抽取max_samples个
        pairs.sort(key=lambda x: x[0])
        top_pairs = pairs[:100] if len(pairs) > 100 else pairs
        if max_samples is not None and len(top_pairs) > max_samples:
            top_pairs = random.sample(top_pairs, max_samples)
        ssim_values = []
        delta_e_values = []
        resolutions = []  # [(样本名, 原分辨率, 超分分辨率)]
        for idx, (file_size, original_path, processed_path, base_name) in enumerate(tqdm(top_pairs, desc='评估进度')):
            t0 = time.time()
            if not os.path.exists(processed_path):
                logger.error(f'处理后图片不存在: {processed_path}')
                continue
            if not os.path.exists(original_path):
                logger.error(f'原始图片不存在: {original_path}')
                continue
            processed_img = self.robust_imread(processed_path)
            if processed_img is None:
                logger.error(f'无法读取处理后图片: {processed_path}，请检查路径和文件完整性，已跳过。')
                continue
            original_img = self.robust_imread(original_path)
            if original_img is None:
                logger.error(f'无法读取原始图片: {original_path}，请检查路径和文件完整性，已跳过。')
                continue
            # 自动缩放到最长边不超过512像素
            max_side = 512
            h, w = processed_img.shape[:2]
            if max(h, w) > max_side:
                scale = max_side / max(h, w)
                new_size = (int(w * scale), int(h * scale))
                processed_img = cv2.resize(processed_img, new_size)
                original_img = cv2.resize(original_img, new_size)
            # 计算SSIM
            ssim_value = self.calculate_ssim(original_img, processed_img)
            ssim_values.append(ssim_value)
            # 计算色彩误差
            delta_e = self.calculate_color_error(original_img, processed_img)
            delta_e_values.append(delta_e)
            # 分辨率
            ori_dpi = original_img.shape[1] * original_img.shape[0]
            sr_dpi = processed_img.shape[1] * processed_img.shape[0]
            resolutions.append((base_name, ori_dpi, sr_dpi))
            t1 = time.time()
            print(f'[{idx+1}/{len(top_pairs)}] {base_name} 评估完成，耗时: {t1-t0:.2f}s, SSIM: {ssim_value:.4f}, ΔE: {delta_e:.4f}')
        # 计算平均值
        avg_ssim = np.mean(ssim_values) if ssim_values else 0
        avg_delta_e = np.mean(delta_e_values) if delta_e_values else 0
        # 输出结果
        print(f"数据集评估结果:")
        print(f"平均SSIM: {avg_ssim:.4f} (目标 ≥0.9)")
        print(f"平均ΔE: {avg_delta_e:.4f} (目标 <3)")
        # 生成直方图
        plt.figure(figsize=(12, 5))
        plt.subplot(1, 2, 1)
        plt.hist(ssim_values, bins=20, alpha=0.7)
        plt.axvline(x=0.9, color='r', linestyle='--', label='目标SSIM ≥0.9')
        plt.axvline(x=avg_ssim, color='g', linestyle='-', label=f'平均SSIM = {avg_ssim:.4f}')
        plt.xlabel('SSIM值')
        plt.ylabel('图像数量')
        plt.title('SSIM值分布')
        plt.legend()
        plt.subplot(1, 2, 2)
        plt.hist(delta_e_values, bins=20, alpha=0.7)
        plt.axvline(x=3.0, color='r', linestyle='--', label='目标ΔE <3')
        plt.axvline(x=avg_delta_e, color='g', linestyle='-', label=f'平均ΔE = {avg_delta_e:.4f}')
        plt.xlabel('ΔE值')
        plt.ylabel('图像数量')
        plt.title('色彩误差(ΔE)分布')
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.abspath(os.path.join(self.output_dir, 'image_quality_evaluation.png')))
        plt.close()
        return avg_ssim, avg_delta_e, ssim_values, delta_e_values, resolutions
    
    def visualize_comparison(self, original_path, processed_path, output_path):
        """
        可视化比较原始图像和处理后图像
        
        参数:
            original_path (str): 原始图像路径
            processed_path (str): 处理后图像路径
            output_path (str): 输出可视化图像路径
        """
        # 强制将对比图保存到image_processing目录下
        output_dir = os.path.abspath(self.output_dir)
        compare_name = os.path.basename(output_path)
        if not compare_name.endswith('.png'):
            compare_name += '.png'
        output_path = os.path.join(output_dir, compare_name)
        original_path = os.path.abspath(os.path.normpath(original_path))
        processed_path = os.path.abspath(os.path.normpath(processed_path))
        if not os.path.exists(original_path):
            logger.error(f'可视化时原始图片不存在: {original_path}，已跳过。')
            return
        if not os.path.exists(processed_path):
            logger.error(f'可视化时处理后图片不存在: {processed_path}，已跳过。')
            return
        original_img = self.robust_imread(original_path)
        processed_img = self.robust_imread(processed_path)
        if original_img is None:
            logger.error(f'可视化时无法读取原始图片: {original_path}，已跳过。')
            return
        if processed_img is None:
            logger.error(f'可视化时无法读取处理后图片: {processed_path}，已跳过。')
            return
        # 跳过超大图片，防止PIL卡死
        max_pixels = 50_000_000  # 5000万像素
        if original_img.size > max_pixels or processed_img.size > max_pixels:
            logger.error(f'图片过大（>{max_pixels}像素），跳过可视化: {original_path} 或 {processed_path}')
            return
        # 若为RGB三通道，需转为BGR以兼容后续cv2和matplotlib
        if original_img.ndim == 3 and original_img.shape[2] == 3:
            original_img = cv2.cvtColor(original_img, cv2.COLOR_RGB2BGR)
        if processed_img.ndim == 3 and processed_img.shape[2] == 3:
            processed_img = cv2.cvtColor(processed_img, cv2.COLOR_RGB2BGR)
        # 可视化前自动缩放，最长边不超过2048像素
        max_vis_side = 2048
        for img_var in ['original_img', 'processed_img']:
            img = locals()[img_var]
            h, w = img.shape[:2]
            if max(h, w) > max_vis_side:
                scale = max_vis_side / max(h, w)
                new_size = (int(w * scale), int(h * scale))
                locals()[img_var] = cv2.resize(img, new_size)
        original_img = locals()['original_img']
        processed_img = locals()['processed_img']
        # 确保两张图像高度相同以便横向展示
        h1, w1 = original_img.shape[:2]
        h2, w2 = processed_img.shape[:2]
        # 调整大小使高度相同
        if h1 != h2:
            scale = h1 / h2
            new_w2 = int(w2 * scale)
            processed_img = cv2.resize(processed_img, (new_w2, h1))
        # 计算质量指标
        ssim_value = self.calculate_ssim(original_img, cv2.resize(processed_img, (w1, h1)))
        delta_e = self.calculate_color_error(original_img, cv2.resize(processed_img, (w1, h1)))
        # 创建对比图
        # 转换为RGB用于matplotlib显示
        original_rgb = cv2.cvtColor(original_img, cv2.COLOR_BGR2RGB)
        processed_rgb = cv2.cvtColor(processed_img, cv2.COLOR_BGR2RGB)
        plt.figure(figsize=(12, 6))
        plt.subplot(1, 2, 1)
        plt.imshow(original_rgb)
        plt.title('原始图像')
        plt.axis('off')
        plt.subplot(1, 2, 2)
        plt.imshow(processed_rgb)
        plt.title(f'处理后图像\nSSIM: {ssim_value:.4f}, ΔE: {delta_e:.4f}')
        plt.axis('off')
        plt.tight_layout()
        plt.savefig(os.path.abspath(output_path), dpi=300)
        plt.close()

def compare_multilight_images(image_paths, output_path):
    """
    多光源扫描对比图像，可视化不同光源下的纹理差异
    参数:
        image_paths (dict): {'漫射光': path1, '侧光': path2, '偏振光': path3}
        output_path (str): 输出路径
    """
    fig, axes = plt.subplots(1, len(image_paths), figsize=(15, 5))
    for i, (k, v) in enumerate(image_paths.items()):
        img = Image.open(v)
        axes[i].imshow(img)
        axes[i].set_title(k)
        axes[i].axis('off')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"多光源对比图已保存: {output_path}")

def super_resolution_esrgan(input_path, output_path):
    """
    超分辨率重建（ESRGAN接口预留，需集成第三方库）
    参数:
        input_path (str): 输入图像路径
        output_path (str): 输出图像路径
    """
    # 这里只做接口预留，实际需集成ESRGAN
    img = Image.open(input_path)
    img.save(output_path)
    logger.info(f"超分辨率重建图像已保存: {output_path}")

def evaluate_ssim(img1_path, img2_path):
    """
    计算两幅图像的结构相似性SSIM
    """
    img1 = np.array(Image.open(img1_path).convert('L'))
    img2 = np.array(Image.open(img2_path).convert('L'))
    score = ssim(img1, img2)
    return score

def evaluate_delta_e(img1_path, img2_path):
    """
    计算两幅图像的色彩误差ΔE（CIE2000）
    """
    img1 = np.array(Image.open(img1_path).convert('RGB'))
    img2 = np.array(Image.open(img2_path).convert('RGB'))
    img1_lab = cv2.cvtColor(img1, cv2.COLOR_RGB2LAB)
    img2_lab = cv2.cvtColor(img2, cv2.COLOR_RGB2LAB)
    delta_e_map = np.zeros(img1_lab.shape[:2])
    for i in range(img1_lab.shape[0]):
        for j in range(img1_lab.shape[1]):
            c1 = LabColor(*img1_lab[i, j])
            c2 = LabColor(*img2_lab[i, j])
            delta_e_map[i, j] = delta_e_cie2000(c1, c2)
    mean_delta_e = np.mean(delta_e_map)
    return mean_delta_e, delta_e_map

def plot_delta_e_hist(delta_e_map, output_path):
    """
    ΔE色彩误差分布直方图
    """
    plt.figure(figsize=(8, 6))
    plt.hist(delta_e_map.flatten(), bins=50, color='skyblue', edgecolor='black')
    plt.xlabel('ΔE')
    plt.ylabel('像素数')
    plt.title('色彩误差ΔE分布')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"ΔE分布直方图已保存: {output_path}")

def plot_resolution_trend(resolutions, output_path):
    """
    分辨率提升趋势折线图
    参数:
        resolutions (list): [(样本名, 原分辨率, 超分辨率)]
        output_path (str): 输出路径
    """
    names = [x[0] for x in resolutions]
    ori = [x[1] for x in resolutions]
    sr = [x[2] for x in resolutions]
    plt.figure(figsize=(10, 6))
    plt.plot(names, ori, marker='o', label='原分辨率')
    plt.plot(names, sr, marker='s', label='超分辨率')
    plt.ylabel('分辨率(dpi)')
    plt.xlabel('样本')
    plt.title('分辨率提升趋势')
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"分辨率提升趋势图已保存: {output_path}")

if __name__ == "__main__":
    # 测试代码
    data_dir = "../../data/图像层"
    output_dir = "../../output/results/image_processing"
    
    processor = ImageProcessor(data_dir, output_dir)
    
    # 处理清代文官官补中的一品文官仙鹤图像
    pattern_dir = "清代文官官补/一品文官 仙鹤"
    processor.process_image_directory(pattern_dir, light_type="diffuse")
    
    # 评估处理结果
    processor.evaluate_dataset(data_dir, output_dir) 