import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.interpolate import splprep, splev
from scipy.spatial.distance import euclidean
import cv2
from tqdm import tqdm
import json

class CraftParameterExtractor:
    """金线刺绣工艺参数提取类，用于分析针法轨迹和参数"""
    
    def __init__(self, data_dir, output_dir):
        """
        初始化工艺参数提取器
        
        参数:
            data_dir (str): 输入工艺视频或轨迹数据目录
            output_dir (str): 输出目录
        """
        self.data_dir = data_dir
        self.output_dir = output_dir
        
        # 创建输出目录
        os.makedirs(self.output_dir, exist_ok=True)
        
        # 针法类型
        self.stitch_types = ["盘金绣", "平金绣", "垫高针", "套针"]
        
        # 设置字体
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 微软雅黑
        plt.rcParams['axes.unicode_minus'] = False
    
    def extract_motion_from_video(self, video_path, sampling_rate=5):
        """
        从视频中提取运动轨迹
        
        参数:
            video_path (str): 视频文件路径
            sampling_rate (int): 每秒采样帧数
            
        返回:
            np.ndarray: 轨迹点坐标数组
        """
        # 打开视频文件
        cap = cv2.VideoCapture(video_path)
        
        if not cap.isOpened():
            print(f"错误: 无法打开视频 {video_path}")
            return None
        
        # 获取视频总帧数和帧率
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        
        # 计算采样间隔
        frame_interval = int(fps / sampling_rate)
        
        # 初始化轨迹点列表
        trajectory = []
        
        # 初始化追踪器
        tracker = cv2.TrackerCSRT_create()
        
        # 读取第一帧并初始化追踪器
        ret, frame = cap.read()
        if not ret:
            print("错误: 无法读取视频第一帧")
            cap.release()
            return None
        
        # 让用户选择ROI (感兴趣区域)
        # 注意: 在实际实现中，这里可能需要替换为自动检测针尖或用户预定义的区域
        bbox = cv2.selectROI(frame, False)
        tracker.init(frame, bbox)
        
        # 设置进度条
        pbar = tqdm(total=total_frames // frame_interval, desc="提取轨迹")
        
        frame_count = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
                
            frame_count += 1
            
            # 按采样率跳过帧
            if frame_count % frame_interval != 0:
                continue
            
            # 更新追踪器
            success, bbox = tracker.update(frame)
            
            if success:
                # 提取ROI中心作为轨迹点
                x, y, w, h = [int(v) for v in bbox]
                center_x = x + w/2
                center_y = y + h/2
                
                # 记录轨迹点
                trajectory.append([frame_count/fps, center_x, center_y])
                
                # 可视化追踪
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.circle(frame, (int(center_x), int(center_y)), 2, (0, 0, 255), -1)
                
                # 显示结果
                cv2.imshow("针法追踪", frame)
            
            pbar.update(1)
            
            # 按ESC键退出
            if cv2.waitKey(1) & 0xFF == 27:
                break
        
        # 关闭资源
        pbar.close()
        cap.release()
        cv2.destroyAllWindows()
        
        return np.array(trajectory)
    
    def fit_spline_model(self, trajectory, smoothing=0.1):
        """
        使用样条曲线拟合轨迹
        
        参数:
            trajectory (np.ndarray): 轨迹点坐标数组
            smoothing (float): 平滑参数
            
        返回:
            tuple: 样条曲线模型参数
        """
        # 分离时间和空间坐标
        times = trajectory[:, 0]
        points = trajectory[:, 1:3]
        
        # 标准化时间
        t = (times - times.min()) / (times.max() - times.min())
        
        # 拟合3D样条曲线 (时间, x, y)
        tck, u = splprep([t, points[:, 0], points[:, 1]], s=smoothing)
        
        return tck, u
    
    def generate_trajectory_from_model(self, tck, num_points=100):
        """
        从样条曲线模型生成轨迹
        
        参数:
            tck (tuple): 样条曲线模型参数
            num_points (int): 生成的点数
            
        返回:
            np.ndarray: 生成的轨迹点
        """
        # 生成新的参数值
        u_new = np.linspace(0, 1, num_points)
        
        # 求值获取轨迹点
        t_new, x_new, y_new = splev(u_new, tck)
        
        return np.column_stack([t_new, x_new, y_new])
    
    def extract_stitch_parameters(self, trajectory):
        """
        提取针法参数 (速度、角度、针距等)
        
        参数:
            trajectory (np.ndarray): 轨迹点坐标数组
            
        返回:
            dict: 针法参数
        """
        # 初始化参数字典
        params = {
            "速度": [],
            "角度": [],
            "针距": [],
            "曲率": []
        }
        
        # 计算各点之间的时间差和位移
        time_diffs = np.diff(trajectory[:, 0])
        pos_diffs = np.diff(trajectory[:, 1:3], axis=0)
        
        # 计算速度 (位移/时间)
        velocities = np.sqrt(np.sum(pos_diffs**2, axis=1)) / time_diffs
        params["速度"] = velocities
        
        # 计算运动方向角度
        angles = np.arctan2(pos_diffs[:, 1], pos_diffs[:, 0]) * 180 / np.pi
        params["角度"] = angles
        
        # 计算针距 (相邻点之间的欧氏距离)
        distances = np.sqrt(np.sum(pos_diffs**2, axis=1))
        params["针距"] = distances
        
        # 计算曲率 (使用三点法近似)
        curvatures = []
        for i in range(1, len(trajectory) - 1):
            p1 = trajectory[i-1, 1:3]
            p2 = trajectory[i, 1:3]
            p3 = trajectory[i+1, 1:3]
            
            # 三点构成的三角形面积
            area = 0.5 * abs((p2[0] - p1[0]) * (p3[1] - p1[1]) - (p3[0] - p1[0]) * (p2[1] - p1[1]))
            
            # 三边长度
            a = euclidean(p1, p2)
            b = euclidean(p2, p3)
            c = euclidean(p3, p1)
            
            # 使用海伦公式计算半径，半径倒数即为曲率
            s = (a + b + c) / 2
            if s * (s - a) * (s - b) * (s - c) > 0:  # 避免数值误差导致开方负数
                radius = (a * b * c) / (4 * area)
                curvature = 1 / radius if radius > 0 else 0
            else:
                curvature = 0
                
            curvatures.append(curvature)
        
        # 为保持数组长度一致，在首尾添加值
        curvatures = [curvatures[0]] + curvatures + [curvatures[-1]]
        params["曲率"] = np.array(curvatures)
        
        # 计算统计指标
        stats = {}
        for param_name, values in params.items():
            if len(values) > 0:
                stats[f"{param_name}_均值"] = np.mean(values)
                stats[f"{param_name}_标准差"] = np.std(values)
                stats[f"{param_name}_最大值"] = np.max(values)
                stats[f"{param_name}_最小值"] = np.min(values)
                stats[f"{param_name}_CV"] = np.std(values) / np.mean(values) if np.mean(values) != 0 else 0
        
        return params, stats
    
    def visualize_trajectory(self, trajectory, title="针法轨迹", output_path=None):
        """
        可视化轨迹
        
        参数:
            trajectory (np.ndarray): 轨迹点坐标数组
            title (str): 图表标题
            output_path (str, optional): 输出图像路径
        """
        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        # 绘制3D轨迹 (时间, x, y)
        ax.plot(trajectory[:, 0], trajectory[:, 1], trajectory[:, 2], 'r-', linewidth=2)
        ax.scatter(trajectory[0, 0], trajectory[0, 1], trajectory[0, 2], c='g', marker='o', s=50, label='起点')
        ax.scatter(trajectory[-1, 0], trajectory[-1, 1], trajectory[-1, 2], c='b', marker='x', s=50, label='终点')
        
        # 设置轴标签
        ax.set_xlabel('时间 (秒)')
        ax.set_ylabel('X坐标')
        ax.set_zlabel('Y坐标')
        
        # 设置标题和图例
        ax.set_title(title)
        ax.legend()
        
        # 保存图像
        if output_path:
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            
        plt.close()
    
    def visualize_parameters(self, params, title="针法参数", output_path=None):
        """
        可视化针法参数
        
        参数:
            params (dict): 针法参数字典
            title (str): 图表标题
            output_path (str, optional): 输出图像路径
        """
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle(title, fontsize=16)
        
        # 速度变化
        axes[0, 0].plot(params["速度"], 'r-')
        axes[0, 0].set_title("速度变化")
        axes[0, 0].set_xlabel("点索引")
        axes[0, 0].set_ylabel("速度 (像素/秒)")
        axes[0, 0].grid(True)
        
        # 角度变化
        axes[0, 1].plot(params["角度"], 'g-')
        axes[0, 1].set_title("角度变化")
        axes[0, 1].set_xlabel("点索引")
        axes[0, 1].set_ylabel("角度 (度)")
        axes[0, 1].grid(True)
        
        # 针距变化
        axes[1, 0].plot(params["针距"], 'b-')
        axes[1, 0].set_title("针距变化")
        axes[1, 0].set_xlabel("点索引")
        axes[1, 0].set_ylabel("针距 (像素)")
        axes[1, 0].grid(True)
        
        # 曲率变化
        axes[1, 1].plot(params["曲率"], 'm-')
        axes[1, 1].set_title("曲率变化")
        axes[1, 1].set_xlabel("点索引")
        axes[1, 1].set_ylabel("曲率")
        axes[1, 1].grid(True)
        
        plt.tight_layout()
        
        # 保存图像
        if output_path:
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            
        plt.close()
    
    def save_parameters_to_json(self, stitch_type, stats, output_path=None):
        """
        将针法参数保存为JSON文件
        
        参数:
            stitch_type (str): 针法类型
            stats (dict): 针法参数统计指标
            output_path (str, optional): 输出文件路径
        """
        if output_path is None:
            output_path = os.path.join(self.output_dir, f"{stitch_type}_参数.json")
        
        # 创建包含针法类型的完整数据
        data = {
            "针法类型": stitch_type,
            "参数统计": stats
        }
        
        # 保存为JSON
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        print(f"针法参数已保存到: {output_path}")
    
    def evaluate_trajectory_precision(self, original, reconstructed):
        """
        评估轨迹重建精度
        
        参数:
            original (np.ndarray): 原始轨迹点
            reconstructed (np.ndarray): 重建轨迹点
            
        返回:
            float: 平均误差(mm)
        """
        # 从时空轨迹中提取空间坐标
        orig_points = original[:, 1:3]
        recon_points = reconstructed[:, 1:3]
        
        # 插值确保两个轨迹有相同数量的点
        if len(orig_points) != len(recon_points):
            # 使用更密集的轨迹作为参考
            if len(orig_points) > len(recon_points):
                dense, sparse = orig_points, recon_points
            else:
                dense, sparse = recon_points, orig_points
                
            # 线性插值得到等长的轨迹
            indices = np.linspace(0, len(sparse) - 1, len(dense)).astype(int)
            sparse = sparse[indices]
            
            # 恢复原始分配
            if len(orig_points) > len(recon_points):
                orig_points, recon_points = dense, sparse
            else:
                recon_points, orig_points = dense, sparse
        
        # 计算点对点的欧氏距离
        errors = np.sqrt(np.sum((orig_points - recon_points) ** 2, axis=1))
        
        # 换算为毫米 (假设1像素 = 0.1mm，根据实际应用调整)
        errors_mm = errors * 0.1
        
        # 计算平均误差
        mean_error = np.mean(errors_mm)
        
        return mean_error
    
    def analyze_stitch_video(self, video_path, stitch_type, save_results=True):
        """
        分析针法视频，提取参数并建模
        
        参数:
            video_path (str): 视频文件路径
            stitch_type (str): 针法类型
            save_results (bool): 是否保存结果
            
        返回:
            tuple: (轨迹样条模型, 针法参数统计)
        """
        # 从视频中提取轨迹
        trajectory = self.extract_motion_from_video(video_path)
        
        if trajectory is None or len(trajectory) < 3:
            print(f"错误: 无法从视频中提取有效轨迹: {video_path}")
            return None, None
        
        # 拟合样条曲线模型
        tck, u = self.fit_spline_model(trajectory)
        
        # 从模型生成平滑轨迹
        smooth_trajectory = self.generate_trajectory_from_model(tck)
        
        # 提取针法参数
        params, stats = self.extract_stitch_parameters(smooth_trajectory)
        
        # 评估轨迹精度
        precision = self.evaluate_trajectory_precision(trajectory, smooth_trajectory)
        stats["轨迹误差_mm"] = precision
        
        # 保存结果
        if save_results:
            # 创建针法专属目录
            stitch_dir = os.path.join(self.output_dir, stitch_type)
            os.makedirs(stitch_dir, exist_ok=True)
            
            # 保存可视化图像
            base_name = os.path.splitext(os.path.basename(video_path))[0]
            
            # 可视化轨迹
            traj_path = os.path.join(stitch_dir, f"{base_name}_轨迹.png")
            self.visualize_trajectory(smooth_trajectory, title=f"{stitch_type}轨迹", output_path=traj_path)
            
            # 可视化参数
            params_path = os.path.join(stitch_dir, f"{base_name}_参数.png")
            self.visualize_parameters(params, title=f"{stitch_type}参数", output_path=params_path)
            
            # 保存参数JSON
            json_path = os.path.join(stitch_dir, f"{base_name}_参数.json")
            self.save_parameters_to_json(stitch_type, stats, json_path)
            
            print(f"分析结果已保存到: {stitch_dir}")
            print(f"轨迹精度: {precision:.4f} mm")
        
        return tck, stats
    
    def batch_process_videos(self):
        """
        批量处理所有针法视频
        
        返回:
            dict: 所有针法的参数统计
        """
        all_stats = {}
        
        # 遍历针法类型目录
        for stitch_type in self.stitch_types:
            stitch_dir = os.path.join(self.data_dir, stitch_type)
            
            # 检查目录是否存在
            if not os.path.exists(stitch_dir):
                print(f"警告: 针法目录不存在: {stitch_dir}")
                continue
            
            # 统计当前针法的所有视频结果
            stitch_stats = []
            
            # 获取所有视频文件
            video_files = [f for f in os.listdir(stitch_dir) if f.lower().endswith(('.mp4', '.avi', '.mov'))]
            
            for video_file in video_files:
                video_path = os.path.join(stitch_dir, video_file)
                _, stats = self.analyze_stitch_video(video_path, stitch_type)
                
                if stats:
                    stitch_stats.append(stats)
            
            # 如果有结果，计算平均统计值
            if stitch_stats:
                avg_stats = {}
                
                # 获取所有键
                all_keys = set()
                for stats in stitch_stats:
                    all_keys.update(stats.keys())
                
                # 计算平均值
                for key in all_keys:
                    values = [stats.get(key, 0) for stats in stitch_stats]
                    avg_stats[key] = np.mean(values)
                
                all_stats[stitch_type] = avg_stats
                
                # 保存该针法的平均参数
                self.save_parameters_to_json(
                    stitch_type, 
                    avg_stats, 
                    os.path.join(self.output_dir, f"{stitch_type}_平均参数.json")
                )
        
        # 生成综合评估报告
        self.generate_evaluation_report(all_stats)
        
        return all_stats
    
    def generate_evaluation_report(self, all_stats):
        """
        生成针法参数评估报告
        
        参数:
            all_stats (dict): 所有针法的参数统计
        """
        # 提取共有的参数进行对比
        common_params = ["速度_CV", "角度_CV", "针距_CV", "轨迹误差_mm"]
        
        # 创建比较数据
        comparison_data = {}
        for param in common_params:
            if param.endswith("_CV"):  # 变异系数特殊处理
                param_name = param.split('_')[0]
                comparison_data[param_name] = {
                    stitch: stats.get(param, 0) * 100  # 转为百分比
                    for stitch, stats in all_stats.items()
                }
            else:
                param_name = param.split('_')[0]
                comparison_data[param_name] = {
                    stitch: stats.get(param, 0)
                    for stitch, stats in all_stats.items()
                }
        
        # 转换为DataFrame以便绘图
        df = pd.DataFrame(comparison_data)
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 微软雅黑
        plt.rcParams['axes.unicode_minus'] = False
        
        # 创建对比图表
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle("针法参数对比", fontsize=16)
        
        # 速度变异系数
        if '速度' in df.columns:
            df['速度'].plot(kind='bar', ax=axes[0, 0], color='skyblue')
            axes[0, 0].set_title("速度变异系数 (CV%)")
            axes[0, 0].set_ylabel("CV%")
            axes[0, 0].axhline(y=15, color='r', linestyle='--', label='目标 CV<15%')
            axes[0, 0].legend()
            axes[0, 0].grid(axis='y')
        
        # 角度变异系数
        if '角度' in df.columns:
            df['角度'].plot(kind='bar', ax=axes[0, 1], color='lightgreen')
            axes[0, 1].set_title("角度变异系数 (CV%)")
            axes[0, 1].set_ylabel("CV%")
            axes[0, 1].axhline(y=15, color='r', linestyle='--', label='目标 CV<15%')
            axes[0, 1].legend()
            axes[0, 1].grid(axis='y')
        
        # 针距变异系数
        if '针距' in df.columns:
            df['针距'].plot(kind='bar', ax=axes[1, 0], color='salmon')
            axes[1, 0].set_title("针距变异系数 (CV%)")
            axes[1, 0].set_ylabel("CV%")
            axes[1, 0].axhline(y=15, color='r', linestyle='--', label='目标 CV<15%')
            axes[1, 0].legend()
            axes[1, 0].grid(axis='y')
        
        # 轨迹误差
        if '轨迹' in df.columns:
            df['轨迹'].plot(kind='bar', ax=axes[1, 1], color='gold')
            axes[1, 1].set_title("轨迹重建误差 (mm)")
            axes[1, 1].set_ylabel("误差 (mm)")
            axes[1, 1].axhline(y=0.5, color='r', linestyle='--', label='目标 <0.5mm')
            axes[1, 1].legend()
            axes[1, 1].grid(axis='y')
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, "工艺参数评估.png"), dpi=300, bbox_inches='tight')
        plt.close()
        
        # 保存数据表格
        csv_path = os.path.join(self.output_dir, "工艺参数对比.csv")
        df.to_csv(csv_path)
        
        print(f"针法参数评估报告已保存到: {self.output_dir}")


if __name__ == "__main__":
    # 测试代码
    data_dir = "../../data/工艺层"
    output_dir = "../../output/results/craft_parameters"
    
    extractor = CraftParameterExtractor(data_dir, output_dir)
    
    # 模拟处理单个视频
    # 注意: 由于缺少真实视频文件，这里只是示例代码
    # video_path = os.path.join(data_dir, "盘金绣/sample.mp4")
    # extractor.analyze_stitch_video(video_path, "盘金绣")
    
    # 对于测试目的，创建合成数据
    # 创建螺旋轨迹模拟盘金绣
    t = np.linspace(0, 10, 100)
    x = np.cos(t) * t
    y = np.sin(t) * t
    
    synthetic_trajectory = np.column_stack([t, x, y])
    
    # 提取针法参数
    params, stats = extractor.extract_stitch_parameters(synthetic_trajectory)
    
    # 可视化轨迹
    extractor.visualize_trajectory(
        synthetic_trajectory, 
        title="合成盘金绣轨迹", 
        output_path=os.path.join(output_dir, "合成盘金绣轨迹.png")
    )
    
    # 可视化参数
    extractor.visualize_parameters(
        params, 
        title="合成盘金绣参数", 
        output_path=os.path.join(output_dir, "合成盘金绣参数.png")
    )
    
    # 保存参数
    extractor.save_parameters_to_json("盘金绣", stats) 