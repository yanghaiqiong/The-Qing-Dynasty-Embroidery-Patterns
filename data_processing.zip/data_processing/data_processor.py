import os
import argparse
from image_processing import ImageProcessor
from knowledge_graph_builder import KnowledgeGraphBuilder
from craft_parameter_extractor import CraftParameterExtractor
import matplotlib.pyplot as plt
import json
import pandas as pd
import numpy as np

class DataProcessor:
    """金线刺绣多模态数据处理主类，整合图像、知识和工艺三层数据处理"""
    
    def __init__(self, data_dir, output_dir):
        """
        初始化数据处理器
        
        参数:
            data_dir (str): 数据根目录
            output_dir (str): 输出根目录
        """
        self.data_dir = data_dir
        self.output_dir = output_dir
        
        # 各层数据目录
        self.image_data_dir = os.path.join(data_dir, "图像层")
        self.knowledge_data_dir = os.path.join(data_dir, "知识层1")
        self.craft_data_dir = os.path.join(data_dir, "工艺层") if os.path.exists(os.path.join(data_dir, "工艺层")) else None
        
        # 各层输出目录
        self.image_output_dir = os.path.join(output_dir, "results/image_processing")
        self.knowledge_output_dir = os.path.join(output_dir, "results/knowledge_graph")
        self.craft_output_dir = os.path.join(output_dir, "results/craft_parameters")
        
        # 创建输出目录
        os.makedirs(self.image_output_dir, exist_ok=True)
        os.makedirs(self.knowledge_output_dir, exist_ok=True)
        os.makedirs(self.craft_output_dir, exist_ok=True)
        
        # 初始化处理器
        self.image_processor = ImageProcessor(self.image_data_dir, self.image_output_dir)
        self.knowledge_builder = KnowledgeGraphBuilder(self.knowledge_data_dir, self.knowledge_output_dir)
        if self.craft_data_dir:
            self.craft_extractor = CraftParameterExtractor(self.craft_data_dir, self.craft_output_dir)
        else:
            self.craft_extractor = None
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 微软雅黑
        plt.rcParams['axes.unicode_minus'] = False
    
    def process_image_layer(self, pattern_types=None):
        """
        处理图像层数据
        
        参数:
            pattern_types (list, optional): 要处理的图案类型列表，None表示处理所有
            
        返回:
            tuple: (平均SSIM, 平均ΔE)
        """
        print("\n===== 处理图像层数据 =====")
        
        # 如果未指定图案类型，获取所有子目录作为图案类型
        if pattern_types is None:
            pattern_types = [d for d in os.listdir(self.image_data_dir) 
                           if os.path.isdir(os.path.join(self.image_data_dir, d))]
        
        # 处理每种图案类型
        for pattern_type in pattern_types:
            print(f"\n处理图案: {pattern_type}")
            self.image_processor.process_image_directory(pattern_type, light_type="diffuse")
        
        # 评估整个数据集
        avg_ssim, avg_delta_e = self.image_processor.evaluate_dataset(
            self.image_data_dir, self.image_output_dir
        )
        
        return avg_ssim, avg_delta_e
    
    def process_knowledge_layer(self, text_file=None):
        """
        处理知识层数据
        
        参数:
            text_file (str, optional): 规制文本文件路径
            
        返回:
            list: 提取的规制信息列表
        """
        print("\n===== 处理知识层数据 =====")
        
        # 构建知识图谱
        regulations = self.knowledge_builder.build_knowledge_graph(text_file)
        
        return regulations
    
    def process_craft_layer(self, simulate=True):
        """
        处理工艺层数据
        
        参数:
            simulate (bool): 是否使用模拟数据
            
        返回:
            dict: 针法参数统计
        """
        print("\n===== 处理工艺层数据 =====")
        
        if self.craft_extractor is None:
            print("警告: 工艺层数据目录不存在，跳过处理")
            return None
        
        if simulate:
            print("使用模拟数据进行工艺参数分析...")
            
            # 创建不同针法的合成轨迹
            stats = {}
            
            # 模拟盘金绣: 螺旋轨迹
            t = np.linspace(0, 10, 100)
            x_spiral = np.cos(t) * t * 0.5
            y_spiral = np.sin(t) * t * 0.5
            spiral_traj = np.column_stack([t, x_spiral, y_spiral])
            
            # 模拟平金绣: 波浪轨迹
            x_wave = np.linspace(0, 10, 100)
            y_wave = np.sin(x_wave * np.pi) * 2
            wave_traj = np.column_stack([x_wave/10, x_wave, y_wave])
            
            # 模拟垫高针: 锯齿轨迹
            x_zigzag = np.linspace(0, 10, 100)
            y_zigzag = np.array([(-1)**i * 2 for i in range(100)])
            zigzag_traj = np.column_stack([x_zigzag/10, x_zigzag, y_zigzag])
            
            # 分析轨迹
            stitch_types = ["盘金绣", "平金绣", "垫高针"]
            trajectories = [spiral_traj, wave_traj, zigzag_traj]
            
            for stitch_type, traj in zip(stitch_types, trajectories):
                # 提取参数
                params, stitch_stats = self.craft_extractor.extract_stitch_parameters(traj)
                
                # 可视化轨迹
                self.craft_extractor.visualize_trajectory(
                    traj, 
                    title=f"模拟{stitch_type}轨迹", 
                    output_path=os.path.join(self.craft_output_dir, f"模拟{stitch_type}轨迹.png")
                )
                
                # 可视化参数
                self.craft_extractor.visualize_parameters(
                    params, 
                    title=f"模拟{stitch_type}参数", 
                    output_path=os.path.join(self.craft_output_dir, f"模拟{stitch_type}参数.png")
                )
                
                # 保存参数
                self.craft_extractor.save_parameters_to_json(
                    stitch_type, 
                    stitch_stats, 
                    os.path.join(self.craft_output_dir, f"模拟{stitch_type}参数.json")
                )
                
                stats[stitch_type] = stitch_stats
            
            # 生成评估报告
            self.craft_extractor.generate_evaluation_report(stats)
            
            return stats
        else:
            # 批量处理实际视频
            return self.craft_extractor.batch_process_videos()
    
    def generate_integrated_report(self, image_metrics, regulations, craft_stats):
        """
        生成整合报告，汇总三层数据处理结果
        
        参数:
            image_metrics (tuple): 图像处理指标 (SSIM, ΔE)
            regulations (list): 知识图谱规制信息
            craft_stats (dict): 工艺参数统计
        """
        print("\n===== 生成整合报告 =====")
        
        # 创建报告数据
        report = {
            "图像层": {
                "平均SSIM": image_metrics[0],
                "平均ΔE": image_metrics[1],
                "达标情况": {
                    "SSIM": "达标" if image_metrics[0] >= 0.9 else "未达标",
                    "ΔE": "达标" if image_metrics[1] < 3 else "未达标"
                }
            },
            "知识层": {
                "规则数量": len(regulations),
                "规则覆盖率": self.knowledge_builder.calculate_coverage_rate(regulations),
                "达标情况": {
                    "覆盖率": "达标" if self.knowledge_builder.calculate_coverage_rate(regulations) >= 95 else "未达标"
                }
            },
            "工艺层": {}
        }
        
        # 添加工艺层数据（如果有）
        if craft_stats:
            cv_values = []
            error_values = []
            
            for stitch_type, stats in craft_stats.items():
                # 提取变异系数和误差值
                cv_keys = [k for k in stats.keys() if k.endswith('_CV')]
                if cv_keys:
                    avg_cv = np.mean([stats[k] for k in cv_keys]) * 100  # 转为百分比
                    cv_values.append(avg_cv)
                
                if '轨迹误差_mm' in stats:
                    error_values.append(stats['轨迹误差_mm'])
            
            # 计算平均值
            avg_cv = np.mean(cv_values) if cv_values else 0
            avg_error = np.mean(error_values) if error_values else 0
            
            report["工艺层"] = {
                "针法类型数": len(craft_stats),
                "平均变异系数(%)": avg_cv,
                "平均轨迹误差(mm)": avg_error,
                "达标情况": {
                    "变异系数": "达标" if avg_cv < 15 else "未达标",
                    "轨迹误差": "达标" if avg_error < 0.5 else "未达标"
                }
            }
        
        # 保存报告为JSON
        report_path = os.path.join(self.output_dir, "multimodal_data_report.json")
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        # 可视化报告
        self.visualize_integrated_report(report)
        
        print(f"整合报告已保存到: {report_path}")
    
    def visualize_integrated_report(self, report):
        """
        可视化整合报告
        
        参数:
            report (dict): 整合报告数据
        """
        # 准备可视化数据
        layer_names = list(report.keys())
        metrics = []
        target_values = []
        actual_values = []
        is_higher_better = []
        
        if "图像层" in report:
            metrics.append("SSIM")
            target_values.append(0.9)
            actual_values.append(report["图像层"]["平均SSIM"])
            is_higher_better.append(True)
            
            metrics.append("ΔE")
            target_values.append(3.0)
            actual_values.append(report["图像层"]["平均ΔE"])
            is_higher_better.append(False)
        
        if "知识层" in report:
            metrics.append("规则覆盖率(%)")
            target_values.append(95.0)
            actual_values.append(report["知识层"]["规则覆盖率"])
            is_higher_better.append(True)
        
        if "工艺层" in report:
            metrics.append("变异系数(%)")
            target_values.append(15.0)
            actual_values.append(report["工艺层"]["平均变异系数(%)"])
            is_higher_better.append(False)
            
            metrics.append("轨迹误差(mm)")
            target_values.append(0.5)
            actual_values.append(report["工艺层"]["平均轨迹误差(mm)"])
            is_higher_better.append(False)
        
        # 创建图表
        plt.figure(figsize=(12, 8))
        
        # 确定柱状图位置
        x = np.arange(len(metrics))
        width = 0.35
        
        # 绘制目标值和实际值
        plt.bar(x - width/2, target_values, width, label='目标值', color='lightblue')
        
        # 根据指标是否越高越好，设置不同颜色
        colors = []
        for i in range(len(metrics)):
            if is_higher_better[i]:
                colors.append('green' if actual_values[i] >= target_values[i] else 'red')
            else:
                colors.append('green' if actual_values[i] <= target_values[i] else 'red')
        
        plt.bar(x + width/2, actual_values, width, label='实际值', color=colors)
        
        # 添加标签和标题
        plt.xlabel('评估指标')
        plt.ylabel('值')
        plt.title('金线刺绣多模态数据评估报告', fontsize=16)
        plt.xticks(x, metrics)
        plt.legend()
        
        # 在柱状图上添加数值标签
        for i, v in enumerate(actual_values):
            plt.text(i + width/2, v + 0.05, f'{v:.2f}', ha='center')
        
        for i, v in enumerate(target_values):
            plt.text(i - width/2, v + 0.05, f'{v:.2f}', ha='center')
        
        # 添加各层说明文字
        plt.figtext(0.15, 0.01, "图像层目标: SSIM ≥ 0.9, ΔE < 3", fontsize=9)
        plt.figtext(0.45, 0.01, "知识层目标: 规则覆盖率 ≥ 95%", fontsize=9)
        plt.figtext(0.75, 0.01, "工艺层目标: 变异系数 < 15%, 误差 < 0.5mm", fontsize=9)
        
        plt.tight_layout(rect=[0, 0.05, 1, 0.95])
        
        # 保存图表
        plt.savefig(os.path.join(self.output_dir, "multimodal_data_evaluation.png"), dpi=300)
        plt.close()
    
    def process_all(self, simulate_craft=True):
        """
        处理所有层数据
        
        参数:
            simulate_craft (bool): 是否使用模拟工艺数据
        """
        # 处理图像层
        image_metrics = self.process_image_layer()
        
        # 处理知识层
        regulations = self.process_knowledge_layer()
        
        # 处理工艺层
        craft_stats = self.process_craft_layer(simulate=simulate_craft)
        
        # 生成整合报告
        self.generate_integrated_report(image_metrics, regulations, craft_stats)
        
        print("\n===== 数据处理完成 =====")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="金线刺绣多模态数据处理")
    parser.add_argument("--data_dir", type=str, default="../../data", help="数据根目录")
    parser.add_argument("--output_dir", type=str, default="../../output", help="输出根目录")
    parser.add_argument("--simulate_craft", action="store_true", help="是否使用模拟工艺数据")
    
    args = parser.parse_args()
    
    processor = DataProcessor(args.data_dir, args.output_dir)
    processor.process_all(simulate_craft=args.simulate_craft) 