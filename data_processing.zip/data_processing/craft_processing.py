import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import logging

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class CraftProcessor:
    """工艺层处理类，支持针法轨迹分析、参数提取、精度与离散度评估及可视化"""
    def __init__(self, data_dir, output_dir):
        self.data_dir = data_dir
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)

    def read_trajectory(self, csv_path):
        """
        读取OptiTrack导出的针法轨迹csv，返回numpy数组
        """
        df = pd.read_csv(csv_path)
        # 假设包含X,Y,Z三列
        return df[['X','Y','Z']].values

    def extract_parameters(self, trajectory):
        """
        提取针法参数：角度、速度、力度（假设力度为Z轴变化）
        """
        # 速度
        speeds = np.linalg.norm(np.diff(trajectory, axis=0), axis=1)
        # 角度
        vecs = np.diff(trajectory, axis=0)
        angles = []
        for i in range(1, len(vecs)):
            v1, v2 = vecs[i-1], vecs[i]
            cos_theta = np.dot(v1, v2) / (np.linalg.norm(v1)*np.linalg.norm(v2)+1e-8)
            angles.append(np.arccos(np.clip(cos_theta, -1, 1)))
        angles = np.degrees(angles)
        # 力度（Z轴变化）
        forces = np.abs(np.diff(trajectory[:,2]))
        return speeds, angles, forces

    def evaluate_trajectory_precision(self, trajectory, gt_trajectory):
        """
        轨迹精度评估：与GT轨迹的均方误差
        """
        min_len = min(len(trajectory), len(gt_trajectory))
        mse = np.mean((trajectory[:min_len] - gt_trajectory[:min_len])**2)
        return mse

    def evaluate_parameter_dispersion(self, param):
        """
        参数离散度（变异系数CV）
        """
        return np.std(param) / (np.mean(param)+1e-8)

    def plot_3d_trajectory(self, trajectory, output_path):
        """
        3D轨迹可视化
        """
        fig = plt.figure(figsize=(8,6))
        ax = fig.add_subplot(111, projection='3d')
        ax.plot(trajectory[:,0], trajectory[:,1], trajectory[:,2], marker='o')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        plt.title('针法3D轨迹')
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()

    def plot_param_box(self, params, labels, output_path):
        """
        参数分布箱线图
        """
        plt.figure(figsize=(8,6))
        plt.boxplot(params, labels=labels)
        plt.title('针法参数分布')
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()

    def plot_param_radar(self, params, labels, output_path):
        """
        参数分布雷达图
        """
        num_vars = len(params)
        angles = np.linspace(0, 2*np.pi, num_vars, endpoint=False).tolist()
        params = np.concatenate((params, [params[0]]))
        angles += angles[:1]
        fig, ax = plt.subplots(figsize=(6,6), subplot_kw=dict(polar=True))
        ax.plot(angles, params, 'o-', linewidth=2)
        ax.fill(angles, params, alpha=0.25)
        ax.set_thetagrids(np.degrees(angles), labels+labels[:1])
        plt.title('针法参数雷达图')
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()

def plot_3d_trajectory(traj_xyz, output_path):
    """
    绘制针法3D运动轨迹
    参数:
        traj_xyz (np.ndarray): N×3的轨迹点
        output_path (str): 输出路径
    """
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(traj_xyz[:, 0], traj_xyz[:, 1], traj_xyz[:, 2], color='blue', linewidth=2)
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    plt.title('针法3D运动轨迹')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"3D轨迹图已保存: {output_path}")

def compute_craft_parameters(traj_xyz, force=None):
    """
    提取针法参数：角度、速度、力度
    参数:
        traj_xyz (np.ndarray): N×3轨迹点
        force (np.ndarray): N×1力度（可选）
    返回:
        dict: {角度:[], 速度:[], 力度:[]}
    """
    # 速度
    v = np.linalg.norm(np.diff(traj_xyz, axis=0), axis=1)
    # 角度
    vecs = np.diff(traj_xyz, axis=0)
    angles = []
    for i in range(1, len(vecs)):
        cos_theta = np.dot(vecs[i-1], vecs[i]) / (np.linalg.norm(vecs[i-1]) * np.linalg.norm(vecs[i]) + 1e-8)
        angles.append(np.arccos(np.clip(cos_theta, -1, 1)))
    angles = np.degrees(angles)
    # 力度
    if force is not None:
        f = force[1:]
    else:
        f = np.zeros_like(v)
    return {'角度': angles, '速度': v, '力度': f}

def plot_craft_radar(params_dict, output_path):
    """
    绘制不同针法参数分布雷达图
    参数:
        params_dict (dict): {针法名: {'角度':[], '速度':[], '力度':[]}}
        output_path (str): 输出路径
    """
    labels = ['角度', '速度', '力度']
    num_vars = len(labels)
    angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()
    angles += angles[:1]
    plt.figure(figsize=(8, 8))
    for name, param in params_dict.items():
        values = [np.mean(param[l]) for l in labels]
        values += values[:1]
        plt.polar(angles, values, label=name, linewidth=2)
    plt.xticks(angles[:-1], labels)
    plt.title('不同针法参数分布雷达图')
    plt.legend(loc='upper right')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"雷达图已保存: {output_path}")

def plot_param_box(params_dict, save_path):
    """
    参数离散度箱线图
    参数:
        params_dict (dict): {针法名: {'角度':[], '速度':[], '力度':[]}}
        save_path (str): 输出路径
    """
    data = []
    labels = []
    for k, v in params_dict.items():
        if isinstance(v, (list, tuple)) and len(v) > 0:
            data.append(v)
            labels.append(str(k))
    if len(data) == 0:
        print("无有效工艺参数数据，跳过箱线图绘制")
        return
    if len(data) != len(labels):
        print("数据与标签数量不一致，已自动对齐")
        min_len = min(len(data), len(labels))
        data = data[:min_len]
        labels = labels[:min_len]
    plt.figure(figsize=(8, 6))
    plt.boxplot(data, labels=labels, patch_artist=True)
    plt.title('工艺参数分布箱线图')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
    print(f"箱线图已保存: {save_path}") 