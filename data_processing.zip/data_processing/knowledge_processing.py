import os
import json
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from collections import defaultdict
from sklearn.metrics import cohen_kappa_score
from pyld import jsonld
from krippendorff import alpha as krippendorff_alpha
import logging
from striprtf.striprtf import rtf_to_text
import re
import textwrap
import matplotlib
from matplotlib.text import Text

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def fix_missing_value(json_str):
    if not isinstance(json_str, str):
        return json_str
    # 1. 替换花式引号为英文引号
    json_str = json_str.replace('"', '"').replace('"', '"').replace("'", "'").replace("'", "'")
    json_str = json_str.replace(',', ',').replace(':', ':').replace(';', ';')
    json_str = json_str.replace('(', '(').replace(')', ')').replace('[', '[').replace(']', ']')
    # 1. 替换单引号为双引号
    json_str = json_str.replace("'", '"')
    # 2. 属性名加双引号（如 {名称: "xx"} -> {"名称": "xx"}），兼容中英文
    json_str = re.sub(r'([,{{\[])[ \t\r\n]*([\u4e00-\u9fa5\w\d]+)[ \t\r\n]*:', r'\1"\2":', json_str)
    # 3. 去掉末尾多余逗号
    json_str = re.sub(r',\s*([}}\]])', r'\1', json_str)
    # 4. 尝试解析
    try:
        return json.loads(json_str)
    except Exception as e:
        logger.error(f"健壮JSON解析失败: {e}\n原始内容片段: {json_str[:100]}")
        return {}

def safe_json_loads(json_str):
    # 若已是dict则直接返回
    if isinstance(json_str, dict):
        return json_str
    json_str = fix_missing_value(json_str)
    if not isinstance(json_str, str):
        return json_str
    # 0. 替换全角引号和常见中文标点为英文
    json_str = json_str.replace('"', '"').replace('"', '"').replace("'", "'").replace("'", "'")
    json_str = json_str.replace(',', ',').replace(':', ':').replace(';', ';')
    json_str = json_str.replace('(', '(').replace(')', ')').replace('[', '[').replace(']', ']')
    # 1. 替换单引号为双引号
    json_str = json_str.replace("'", '"')
    # 2. 属性名加双引号（如 {名称: "xx"} -> {"名称": "xx"}），兼容中英文
    json_str = re.sub(r'([,{{\[])[ \t\r\n]*([\u4e00-\u9fa5\w\d]+)[ \t\r\n]*:', r'\1"\2":', json_str)
    # 3. 去掉末尾多余逗号
    json_str = re.sub(r',\s*([}}\]])', r'\1', json_str)
    # 4. 尝试解析
    try:
        return json.loads(json_str)
    except Exception as e:
        logger.error(f"健壮JSON解析失败: {e}\n原始内容片段: {json_str[:100]}")
        return {}

def wrap_text(text, width=15):
    if not isinstance(text, str):
        text = str(text)
    return '\n'.join(textwrap.wrap(text, width=width))

def smart_wrap(text, max_pixel_width, font_size=12, font_family='Microsoft YaHei'):
    # 按像素宽度智能换行，适配matplotlib
    fig = plt.figure()
    renderer = fig.canvas.get_renderer()
    words = list(text)
    lines = []
    line = ''
    for w in words:
        test_line = line + w
        t = Text(text=test_line, fontproperties=matplotlib.font_manager.FontProperties(family=font_family, size=font_size))
        t.set_figure(fig)
        bbox = t.get_window_extent(renderer=renderer)
        if bbox.width > max_pixel_width and line:
            lines.append(line)
            line = w
        else:
            line = test_line
    if line:
        lines.append(line)
    plt.close(fig)
    return '\n'.join(lines)

class KnowledgeProcessor:
    """知识层处理类，支持知识图谱构建、JSON-LD编码、标注一致性与规则覆盖率评估及可视化"""
    def __init__(self, data_dir, output_dir):
        self.data_dir = data_dir
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)

    def parse_rules(self, rule_file):
        """
        解析jsonld文件，返回结构化知识（list of dict）
        """
        with open(rule_file, 'r', encoding='utf-8') as f:
            try:
                data = json.load(f)
            except Exception as e:
                logger.error(f"解析jsonld失败: {rule_file}, {e}")
                return []
        # 若为dict则转为list
        if isinstance(data, dict):
            data = [data]
        return data

    def to_jsonld(self, knowledge, output_path):
        """
        将结构化知识编码为JSON-LD格式
        """
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(knowledge, f, ensure_ascii=False, indent=2)

    def visualize_knowledge_graph(self, data, save_path):
        """
        可视化知识图谱结构，自动适配jsonld结构
        """
        G = nx.DiGraph()
        if isinstance(data, dict):
            data = [data]
        for k in data:
            keys = list(k.keys())
            if len(keys) >= 2:
                for i in range(len(keys)-1):
                    G.add_edge(str(k[keys[i]]), str(k[keys[i+1]]))
        if len(G.nodes) == 0:
            for k in data:
                for v in k.values():
                    G.add_node(str(v))
        img_width = 800
        img_height = 600
        plt.figure(figsize=(img_width/100, img_height/100))
        pos = nx.spring_layout(G, seed=42)
        # 坐标归一化后加边距
        margin = 0.12  # 边距比例，12%
        for k in pos:
            x, y = pos[k]
            pos[k] = ((1 - 2*margin) * x + margin, (1 - 2*margin) * y + margin)
        labels = {}
        node_margin = 60
        max_label_width = img_width - node_margin*2
        for node in G.nodes():
            label = str(node)
            labels[node] = smart_wrap(label, max_label_width)
        nx.draw(G, pos, labels=labels, with_labels=True, node_color='skyblue', font_family='Microsoft YaHei', node_size=2000, font_size=12, edge_color='gray')
        plt.title('知识图谱结构')
        plt.tight_layout(rect=[margin, margin, 1-margin, 1-margin])
        plt.savefig(save_path)
        plt.close()

    def evaluate_annotation_consistency(self, annotations):
        """
        计算标注一致性（Krippendorff's α，简化为Cohen's kappa近似）
        参数: annotations: List[List[int]]，每行为一个标注者的标注
        """
        if len(annotations) < 2:
            return 1.0
        scores = []
        for i in range(len(annotations)):
            for j in range(i+1, len(annotations)):
                scores.append(cohen_kappa_score(annotations[i], annotations[j]))
        return np.mean(scores)

    def visualize_consistency(self, alpha_values, output_path):
        """
        可视化不同规则/标注者的Krippendorff's α值
        """
        plt.figure(figsize=(8,6))
        plt.bar(range(len(alpha_values)), alpha_values, color='orange')
        plt.axhline(y=0.8, color='r', linestyle='--', label='合格线0.8')
        plt.xlabel('规则/标注者')
        plt.ylabel("Krippendorff's α")
        plt.title('标注一致性对比')
        plt.legend()
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()

    def evaluate_rule_coverage(self, rules, covered_rules):
        """
        计算规则覆盖率
        """
        total = len(rules)
        covered = len(set(covered_rules))
        return covered / total if total > 0 else 0

    def visualize_rule_coverage(self, coverage, output_path):
        """
        可视化规则覆盖率（饼图）
        """
        plt.figure(figsize=(6,6))
        plt.pie([coverage, 1-coverage], labels=['已覆盖','未覆盖'], autopct='%1.1f%%', colors=['#4CAF50','#FFC107'])
        plt.title('规则覆盖率')
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()

def parse_regulation(text_path, output_jsonld):
    """
    解析RTF，提取JSON内容，生成JSON-LD知识图谱
    """
    with open(text_path, 'r', encoding='utf-8') as f:
        rtf_content = f.read()
    plain_text = rtf_to_text(rtf_content)
    json_str = plain_text.strip()
    try:
        data = json.loads(json_str)
    except Exception:
        data = safe_json_loads(json_str)
    with open(output_jsonld, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    logger.info(f"知识图谱JSON-LD已保存: {output_jsonld}")

def visualize_knowledge_graph(jsonld_path, output_path):
    """
    可视化知识图谱结构（网络图）
    """
    with open(jsonld_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    G = nx.DiGraph()
    for node in data:
        G.add_node(node['@id'])
        if 'animal' in node:
            G.add_edge(node['@id'], node['animal'])
    plt.figure(figsize=(8, 6))
    pos = nx.spring_layout(G)
    nx.draw(G, pos, with_labels=True, node_color='skyblue', font_size=12, font_family='Microsoft YaHei')
    plt.title('知识图谱结构')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"知识图谱结构图已保存: {output_path}")

def evaluate_krippendorff_alpha(annotation_matrix):
    """
    计算标注一致性Krippendorff's α
    参数:
        annotation_matrix (list of list): 标注者×样本的二维标签矩阵
    返回:
        float: α值
    """
    return krippendorff_alpha(annotation_matrix, level_of_measurement='nominal')

def plot_alpha_comparison(alpha_dict, output_path):
    """
    Krippendorff's α横向对比柱状图
    参数:
        alpha_dict (dict): {规则类别: α值}
    """
    plt.figure(figsize=(8, 6))
    plt.bar(alpha_dict.keys(), alpha_dict.values(), color='orange')
    plt.ylabel("Krippendorff's α")
    plt.title('标注一致性对比')
    plt.ylim(0, 1)
    for i, v in enumerate(alpha_dict.values()):
        plt.text(i, v + 0.02, f'{v:.2f}', ha='center')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"Krippendorff's α对比图已保存: {output_path}")

def plot_rule_coverage(covered, total, output_path):
    """
    规则覆盖率饼图
    参数:
        covered (int): 已覆盖规则数
        total (int): 总规则数
    """
    plt.figure(figsize=(6, 6))
    plt.pie([covered, total - covered], labels=['已覆盖', '未覆盖'], autopct='%1.1f%%', colors=['#4CAF50', '#FFC107'])
    plt.title('规则覆盖率')
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    logger.info(f"规则覆盖率饼图已保存: {output_path}") 