import os
import json
import networkx as nx
import rdflib
from rdflib import Graph, Literal, Namespace, URIRef, BNode
from rdflib.namespace import RDF, RDFS, XSD
import matplotlib.pyplot as plt
import pandas as pd
from tqdm import tqdm
import numpy as np
from sklearn.metrics import cohen_kappa_score
import jieba
import jieba.analyse

class KnowledgeGraphBuilder:
    """金线刺绣知识图谱构建类，用于提取和结构化纹样规制信息"""
    
    def __init__(self, data_dir, output_dir):
        """
        初始化知识图谱构建器
        
        参数:
            data_dir (str): 输入知识层数据目录
            output_dir (str): 输出目录
        """
        self.data_dir = data_dir
        self.output_dir = output_dir
        
        # 创建输出目录
        os.makedirs(self.output_dir, exist_ok=True)
        
        # 初始化RDF图
        self.graph = Graph()
        
        # 自定义命名空间
        self.ns = Namespace("http://goldembroidery.org/ontology#")
        self.instance = Namespace("http://goldembroidery.org/instance#")
        
        # 绑定命名空间
        self.graph.bind("ge", self.ns)
        self.graph.bind("gei", self.instance)
        
        # 初始化NetworkX图形用于可视化
        self.nx_graph = nx.DiGraph()
        
        # 官品数字到汉字的映射
        self.rank_mapping = {
            "一品": 1, "二品": 2, "三品": 3, "四品": 4, "五品": 5,
            "六品": 6, "七品": 7, "八品": 8, "九品": 9
        }
        
        # 准备jieba分词
        jieba.setLogLevel(20)  # 设置jieba的日志级别为INFO以上
        
        # 加载官品动物标准
        self.standard_rules = {
            "文官": {
                1: "仙鹤", 2: "锦鸡", 3: "孔雀", 4: "云雁", 
                5: "白鹇", 6: "鹭鸶", 7: "鸂鶒", 8: "鹌鹑", 9: "练鹊"
            },
            "武官": {
                1: "麒麟", 2: "狮子", 3: "豹子", 4: "虎", 
                5: "熊", 6: "彪纹", 7: "犀牛", 8: "犀牛", 9: "海马"
            }
        }
    
    def extract_text_from_files(self, text_file_path):
        """
        从文本文件中提取《大清会典》相关内容
        
        参数:
            text_file_path (str): 文本文件路径
            
        返回:
            list: 提取的文本段落列表
        """
        with open(text_file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        # 分段处理
        paragraphs = content.split('\n\n')
        
        # 提取与官服纹样相关的段落
        pattern_related = []
        keywords = ['补服', '补子', '官服', '品级', '文官', '武官', '纹样', '仙鹤', '麒麟']
        
        for para in paragraphs:
            if any(keyword in para for keyword in keywords):
                pattern_related.append(para)
        
        return pattern_related
    
    def parse_regulations(self, text_paragraphs):
        """
        解析文本段落提取规制信息
        
        参数:
            text_paragraphs (list): 文本段落列表
            
        返回:
            list: 规制信息列表，每项包含官品、类别和动物
        """
        regulations = []
        
        for para in text_paragraphs:
            # 使用jieba提取关键词
            keywords = jieba.analyse.textrank(para, topK=10, withWeight=False)
            
            # 尝试识别官品
            rank = None
            for word in keywords:
                if word in self.rank_mapping:
                    rank = self.rank_mapping[word]
                    break
            
            # 识别文武官员类别
            category = None
            if "文官" in para or "文臣" in para:
                category = "文官"
            elif "武官" in para or "武将" in para:
                category = "武官"
            
            # 识别动物纹样
            animal = None
            if rank is not None and category is not None:
                # 从标准规则中获取
                animal = self.standard_rules.get(category, {}).get(rank)
            else:
                # 尝试直接从文本中匹配动物
                all_animals = set()
                for cat in self.standard_rules.values():
                    all_animals.update(cat.values())
                
                for word in keywords:
                    if word in all_animals:
                        animal = word
                        break
            
            # 如果找到了完整的规制信息，添加到结果中
            if rank is not None and category is not None and animal is not None:
                regulations.append({
                    "rank": rank,
                    "category": category,
                    "animal": animal
                })
        
        return regulations
    
    def add_to_rdf_graph(self, regulations):
        """
        将规制信息添加到RDF图中
        
        参数:
            regulations (list): 规制信息列表
        """
        # 添加类和属性定义
        self.graph.add((self.ns.Rank, RDF.type, RDFS.Class))
        self.graph.add((self.ns.Category, RDF.type, RDFS.Class))
        self.graph.add((self.ns.Animal, RDF.type, RDFS.Class))
        self.graph.add((self.ns.Pattern, RDF.type, RDFS.Class))
        
        self.graph.add((self.ns.hasRank, RDF.type, RDF.Property))
        self.graph.add((self.ns.hasCategory, RDF.type, RDF.Property))
        self.graph.add((self.ns.hasAnimal, RDF.type, RDF.Property))
        self.graph.add((self.ns.belongsTo, RDF.type, RDF.Property))
        
        # 添加规制信息
        for reg in regulations:
            # 创建资源URI
            rank_uri = self.instance[f"Rank_{reg['rank']}"]
            category_uri = self.instance[f"Category_{reg['category']}"]
            animal_uri = self.instance[f"Animal_{reg['animal']}"]
            pattern_uri = self.instance[f"Pattern_{reg['category']}_{reg['rank']}"]
            
            # 添加基本类型
            self.graph.add((rank_uri, RDF.type, self.ns.Rank))
            self.graph.add((category_uri, RDF.type, self.ns.Category))
            self.graph.add((animal_uri, RDF.type, self.ns.Animal))
            self.graph.add((pattern_uri, RDF.type, self.ns.Pattern))
            
            # 添加标签
            self.graph.add((rank_uri, RDFS.label, Literal(f"{reg['rank']}品", lang="zh")))
            self.graph.add((category_uri, RDFS.label, Literal(reg['category'], lang="zh")))
            self.graph.add((animal_uri, RDFS.label, Literal(reg['animal'], lang="zh")))
            self.graph.add((pattern_uri, RDFS.label, Literal(f"{reg['category']}{reg['rank']}品{reg['animal']}", lang="zh")))
            
            # 添加关系
            self.graph.add((pattern_uri, self.ns.hasRank, rank_uri))
            self.graph.add((pattern_uri, self.ns.hasCategory, category_uri))
            self.graph.add((pattern_uri, self.ns.hasAnimal, animal_uri))
            self.graph.add((animal_uri, self.ns.belongsTo, pattern_uri))
            
            # 添加数值
            self.graph.add((rank_uri, self.ns.rankValue, Literal(reg['rank'], datatype=XSD.integer)))
    
    def add_to_networkx_graph(self, regulations):
        """
        将规制信息添加到NetworkX图中用于可视化
        
        参数:
            regulations (list): 规制信息列表
        """
        for reg in regulations:
            rank_node = f"{reg['rank']}品"
            category_node = reg['category']
            animal_node = reg['animal']
            pattern_node = f"{category_node}{rank_node}{animal_node}"
            
            # 添加节点
            self.nx_graph.add_node(rank_node, type="Rank")
            self.nx_graph.add_node(category_node, type="Category")
            self.nx_graph.add_node(animal_node, type="Animal")
            self.nx_graph.add_node(pattern_node, type="Pattern")
            
            # 添加边
            self.nx_graph.add_edge(pattern_node, rank_node, relation="hasRank")
            self.nx_graph.add_edge(pattern_node, category_node, relation="hasCategory")
            self.nx_graph.add_edge(pattern_node, animal_node, relation="hasAnimal")
            self.nx_graph.add_edge(animal_node, pattern_node, relation="belongsTo")
    
    def save_to_files(self):
        """
        将知识图谱保存到文件
        """
        # 保存RDF图为Turtle格式
        turtle_path = os.path.join(self.output_dir, "embroidery_ontology.ttl")
        self.graph.serialize(destination=turtle_path, format="turtle")
        
        # 保存为JSON-LD格式
        jsonld_path = os.path.join(self.output_dir, "embroidery_ontology.jsonld")
        jsonld = self.graph.serialize(format="json-ld")
        with open(jsonld_path, 'w', encoding='utf-8') as f:
            f.write(jsonld)
        
        # 保存NetworkX图为GEXF格式用于Gephi可视化
        gexf_path = os.path.join(self.output_dir, "embroidery_graph.gexf")
        nx.write_gexf(self.nx_graph, gexf_path)
        
        print(f"知识图谱已保存到: {self.output_dir}")
    
    def visualize_graph(self, output_path=None):
        """
        可视化知识图谱
        
        参数:
            output_path (str, optional): 输出图像路径
        """
        if output_path is None:
            output_path = os.path.join(self.output_dir, "knowledge_graph_visualization.png")
        
        # 创建节点类型的颜色映射
        color_map = {
            "Rank": "skyblue",
            "Category": "lightgreen",
            "Animal": "salmon",
            "Pattern": "gold"
        }
        
        # 获取节点颜色
        node_colors = [color_map[self.nx_graph.nodes[node]['type']] for node in self.nx_graph.nodes()]
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 微软雅黑
        plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像时负号'-'显示为方块的问题
        
        # 创建图形
        plt.figure(figsize=(20, 16))
        
        # 使用spring布局
        pos = nx.spring_layout(self.nx_graph, k=0.15, iterations=50)
        
        # 绘制节点
        nx.draw_networkx_nodes(self.nx_graph, pos, node_color=node_colors, node_size=800, alpha=0.8)
        
        # 绘制边
        nx.draw_networkx_edges(self.nx_graph, pos, width=1.0, alpha=0.5, arrows=True, arrowsize=15)
        
        # 绘制标签
        nx.draw_networkx_labels(self.nx_graph, pos, font_family='Microsoft YaHei', font_size=10)
        
        # 创建图例
        legend_elements = [plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=color, markersize=10, label=node_type)
                          for node_type, color in color_map.items()]
        plt.legend(handles=legend_elements, loc='upper right')
        
        # 保存图像
        plt.axis('off')
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"知识图谱可视化已保存到: {output_path}")
    
    def evaluate_annotation_consistency(self, annotations_list):
        """
        评估标注一致性
        
        参数:
            annotations_list (list): 不同标注者的标注列表
            
        返回:
            float: Krippendorff's alpha值
        """
        # 将标注转换为矩阵形式
        annotations = np.array(annotations_list)
        
        # 计算两两之间的Cohen's Kappa值
        n_annotators = len(annotations_list)
        kappa_values = []
        
        for i in range(n_annotators):
            for j in range(i+1, n_annotators):
                kappa = cohen_kappa_score(annotations[i], annotations[j])
                kappa_values.append(kappa)
        
        # 计算平均kappa值作为一致性指标
        avg_kappa = np.mean(kappa_values)
        
        return avg_kappa
    
    def calculate_coverage_rate(self, regulations):
        """
        计算规则覆盖率
        
        参数:
            regulations (list): 提取的规制信息列表
            
        返回:
            float: 覆盖率百分比
        """
        # 理论上应该有的规则总数（文官9品 + 武官9品）
        total_rules = 9 * 2
        
        # 获取规则中不重复的组合数量
        extracted_rules = set()
        for reg in regulations:
            extracted_rules.add((reg['category'], reg['rank']))
        
        coverage_rate = (len(extracted_rules) / total_rules) * 100
        
        return coverage_rate
    
    def generate_evaluation_report(self, regulations, annotations_list=None):
        """
        生成评估报告
        
        参数:
            regulations (list): 规制信息列表
            annotations_list (list, optional): 不同标注者的标注列表
            
        返回:
            dict: 评估指标
        """
        # 计算覆盖率
        coverage_rate = self.calculate_coverage_rate(regulations)
        
        # 计算标注一致性
        consistency = 0
        if annotations_list:
            consistency = self.evaluate_annotation_consistency(annotations_list)
        
        # 生成评估报告
        report = {
            "规则覆盖率": f"{coverage_rate:.2f}%",
            "标注一致性": f"{consistency:.4f}",
            "规则总数": len(regulations)
        }
        
        # 输出报告
        print("\n知识图谱评估报告:")
        for key, value in report.items():
            print(f"{key}: {value}")
        
        # 保存报告
        report_path = os.path.join(self.output_dir, "knowledge_graph_evaluation.json")
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        # 生成可视化评估图表
        self.visualize_evaluation(coverage_rate, consistency)
        
        return report
    
    def visualize_evaluation(self, coverage_rate, consistency):
        """
        可视化评估指标
        
        参数:
            coverage_rate (float): 规则覆盖率
            consistency (float): 标注一致性
        """
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 微软雅黑
        plt.rcParams['axes.unicode_minus'] = False
        
        # 创建图表
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        
        # 规则覆盖率饼图
        labels = ['已覆盖', '未覆盖']
        sizes = [coverage_rate, 100 - coverage_rate]
        colors = ['#66b3ff', '#c2c2d6']
        
        ax1.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
        ax1.axis('equal')
        ax1.set_title('规则覆盖率')
        
        # 标注一致性条形图
        categories = ['标注一致性']
        values = [consistency]
        target = 0.8  # 目标值
        
        ax2.bar(categories, values, color='#66b3ff', width=0.5)
        ax2.axhline(y=target, color='r', linestyle='--', label=f'目标 (α≥{target})')
        ax2.set_ylim(0, 1)
        ax2.set_ylabel('Krippendorff\'s α')
        ax2.set_title('标注一致性')
        ax2.legend()
        
        # 保存图表
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, "knowledge_graph_metrics.png"), dpi=300)
        plt.close()
    
    def build_knowledge_graph(self, text_file_path=None):
        """
        构建知识图谱的主方法
        
        参数:
            text_file_path (str, optional): 文本文件路径
            
        返回:
            list: 规制信息列表
        """
        # 如果没有提供文本文件，则使用硬编码的标准规则
        if text_file_path is None or not os.path.exists(text_file_path):
            print("未提供文本文件，使用预定义规则构建知识图谱...")
            regulations = []
            
            for category, ranks in self.standard_rules.items():
                for rank, animal in ranks.items():
                    regulations.append({
                        "rank": rank,
                        "category": category,
                        "animal": animal
                    })
        else:
            # 从文本文件提取内容
            text_paragraphs = self.extract_text_from_files(text_file_path)
            
            # 解析规制信息
            regulations = self.parse_regulations(text_paragraphs)
        
        # 添加到RDF图
        self.add_to_rdf_graph(regulations)
        
        # 添加到NetworkX图用于可视化
        self.add_to_networkx_graph(regulations)
        
        # 保存知识图谱
        self.save_to_files()
        
        # 可视化知识图谱
        self.visualize_graph()
        
        # 生成评估报告
        self.generate_evaluation_report(regulations)
        
        return regulations


if __name__ == "__main__":
    # 测试代码
    data_dir = "../../data/知识层1"
    output_dir = "../../output/results/knowledge_graph"
    
    kg_builder = KnowledgeGraphBuilder(data_dir, output_dir)
    
    # 构建知识图谱
    regulations = kg_builder.build_knowledge_graph()
    
    # 打印规制信息
    for reg in regulations:
        print(f"{reg['category']}{reg['rank']}品: {reg['animal']}") 