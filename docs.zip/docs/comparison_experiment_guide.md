# 金线刺绣生成模型对比实验指南

## 概述

本系统实现了SDXL与DALL-E 3在金线刺绣图像生成任务上的完整自动化对比实验，包括图像生成、多维度评估、统计分析和可视化报告。

## 系统架构

```
对比实验系统
├── DALL-E 3生成器 (src/models/dalle3_generator.py)
├── 综合评估器 (src/evaluation/comprehensive_evaluator.py)
├── 自动化对比实验 (src/experiments/automated_comparison.py)
├── 配置系统 (config/comparison_config.json)
└── 运行脚本 (run_comparison_experiment.py)
```

## 功能特性

### 🎨 双模型生成
- **SDXL**: 基于本地训练的金线刺绣专用模型
- **DALL-E 3**: OpenAI的最新图像生成模型
- 支持批量生成和缓存机制

### 📊 多维度评估
- **FID分数**: 图像质量评估
- **GLCM纹理复杂度**: 纹理特征分析
- **CLIP相似度**: 文本-图像匹配度
- **文化准确性**: 传统文化元素识别
- **工艺可行性**: 刺绣工艺合理性
- **美学质量**: 构图、色彩和谐度

### 📈 统计分析
- t检验和Wilcoxon秩和检验
- 效应量计算（Cohen's d）
- 显著性检验
- 置信区间分析

### 📊 可视化报告
- 指标对比柱状图
- 分布图和箱线图
- 相关性矩阵热图
- 雷达图性能对比
- 最佳样本画廊
- Markdown格式详细报告

## 快速开始

### 1. 环境准备

```bash
# 安装依赖
pip install torch torchvision transformers diffusers
pip install opencv-python scikit-image matplotlib seaborn pandas scipy tqdm
pip install requests pillow numpy

# 检查SDXL模型
ls checkpoints/stable-diffusion-xl-base-1.0/
```

### 2. 快速测试

```bash
# 运行系统测试
python test_comparison_system.py
```

### 3. 基础实验（模拟模式）

```bash
# 使用模拟DALL-E 3运行对比实验
python run_comparison_experiment.py --test_mode
```

### 4. 完整实验（真实API）

```bash
# 使用真实DALL-E 3 API
python run_comparison_experiment.py --openai_api_key YOUR_API_KEY
```

## 详细使用

### 配置文件

编辑 `config/comparison_config.json`:

```json
{
  "output_dir": "output/experiments",
  "test_prompts": [
    "一品文官仙鹤金线刺绣",
    "二品文官锦鸡金线刺绣",
    "三品文官孔雀金线刺绣"
  ],
  "generation_params": {
    "sdxl": {
      "num_images_per_prompt": 3,
      "num_inference_steps": 30,
      "guidance_scale": 7.5,
      "image_size": 512
    },
    "dalle3": {
      "num_images_per_prompt": 3,
      "size": "1024x1024",
      "quality": "standard"
    }
  },
  "evaluation_metrics": [
    "fid_score",
    "glcm_texture", 
    "clip_similarity",
    "cultural_accuracy",
    "craft_feasibility",
    "aesthetic_quality"
  ]
}
```

### 命令行参数

```bash
python run_comparison_experiment.py [选项]

选项:
  --config CONFIG           配置文件路径
  --output_dir OUTPUT_DIR   输出目录
  --openai_api_key API_KEY  OpenAI API密钥
  --test_mode              测试模式（少量数据）
  --models {sdxl,dalle3}   指定测试模型
```

### 实验流程

1. **模型初始化**
   - 加载SDXL训练器
   - 初始化DALL-E 3生成器
   - 准备评估器

2. **图像生成**
   - 使用预定义提示词
   - 并行生成多张图像
   - 自动保存和缓存

3. **图像评估**
   - 多维度质量评估
   - 文化准确性分析
   - 工艺可行性检查

4. **统计分析**
   - 假设检验
   - 效应量计算
   - 显著性分析

5. **报告生成**
   - 可视化图表
   - 统计报告
   - 结论和建议

## 输出结果

### 目录结构

```
output/experiments/comparison_YYYYMMDD_HHMMSS/
├── sdxl_results/           # SDXL生成的图像
├── dalle3_results/         # DALL-E 3生成的图像
├── evaluation/             # 评估结果
│   ├── evaluation_results.json
│   └── statistical_analysis.json
├── reports/                # 报告文件
│   ├── comprehensive_report.json
│   └── experiment_report.md
├── visualizations/         # 可视化图表
│   ├── metric_comparison.png
│   ├── distribution_plots.png
│   ├── correlation_matrix.png
│   ├── radar_chart.png
│   └── sample_gallery.png
└── experiment_state.json  # 实验状态
```

### 关键文件说明

- **experiment_report.md**: 完整的Markdown格式报告
- **statistical_analysis.json**: 详细统计分析结果
- **metric_comparison.png**: 指标对比可视化
- **sample_gallery.png**: 最佳样本展示

## 评估指标详解

### 1. FID分数 (Fréchet Inception Distance)
- **范围**: 0-∞ (越低越好)
- **含义**: 生成图像与真实图像的分布距离
- **计算**: 基于Inception-v3特征的统计距离

### 2. GLCM纹理复杂度
- **范围**: 0-1 (适中为佳)
- **含义**: 图像纹理的复杂程度
- **计算**: 灰度共生矩阵的对比度和差异性

### 3. CLIP相似度
- **范围**: 0-1 (越高越好)
- **含义**: 图像与文本描述的匹配度
- **计算**: CLIP模型的余弦相似度

### 4. 文化准确性
- **范围**: 0-1 (越高越好)
- **含义**: 传统文化元素的准确表达
- **计算**: 基于文化符号词典的CLIP匹配

### 5. 工艺可行性
- **范围**: 0-1 (越高越好)
- **含义**: 刺绣工艺的合理性和可实现性
- **计算**: 基于工艺特征的综合评估

### 6. 美学质量
- **范围**: 0-1 (越高越好)
- **含义**: 图像的美学价值
- **计算**: 构图平衡、色彩和谐、细节丰富度

## 高级功能

### 自定义评估指标

```python
# 在 comprehensive_evaluator.py 中添加新指标
def _calculate_custom_metric(self, image_array):
    # 实现自定义评估逻辑
    return score
```

### 扩展生成模型

```python
# 创建新的生成器类
class CustomGenerator:
    def generate(self, prompt, **kwargs):
        # 实现生成逻辑
        return image
```

### 批量实验

```python
# 运行多组对比实验
configs = ["config1.json", "config2.json", "config3.json"]
for config in configs:
    experiment = AutomatedComparisonExperiment(config)
    experiment.run_full_experiment()
```

## 故障排除

### 常见问题

1. **SDXL模型未找到**
   ```bash
   # 解决方案：下载并设置SDXL模型
   python setup_local_pipeline.py
   ```

2. **DALL-E 3 API失败**
   ```bash
   # 解决方案：检查API密钥或使用模拟模式
   export OPENAI_API_KEY=your_key_here
   ```

3. **内存不足**
   ```bash
   # 解决方案：减少批量大小或使用CPU
   # 在配置中设置较小的 num_images_per_prompt
   ```

4. **依赖包缺失**
   ```bash
   # 解决方案：安装所需依赖
   pip install -r requirements.txt
   ```

### 调试模式

```bash
# 启用详细日志
export PYTHONPATH=src
python -m logging.basicConfig level=DEBUG run_comparison_experiment.py
```

## 性能优化

### 1. 缓存机制
- DALL-E 3生成结果自动缓存
- 避免重复API调用
- 支持断点续传

### 2. 并行处理
- 图像评估并行化
- 批量特征提取
- 异步API调用

### 3. 内存管理
- 及时释放GPU内存
- 分批处理大量图像
- 优化模型加载

## 扩展开发

### 添加新模型

1. 创建生成器类
2. 实现标准接口
3. 注册到对比系统
4. 更新配置文件

### 添加新指标

1. 在评估器中实现计算函数
2. 添加到评估流程
3. 更新可视化代码
4. 修改报告模板

### 自定义可视化

1. 创建新的绘图函数
2. 添加到可视化流程
3. 更新报告生成
4. 配置图表参数

## 最佳实践

### 1. 实验设计
- 使用足够的样本量
- 控制变量
- 重复实验验证
- 记录实验条件

### 2. 数据管理
- 规范命名约定
- 版本控制配置
- 备份重要结果
- 文档化实验过程

### 3. 结果解释
- 考虑统计显著性
- 分析效应量大小
- 结合领域知识
- 谨慎得出结论

## 参考资料

- [SDXL论文](https://arxiv.org/abs/2307.01952)
- [DALL-E 3技术报告](https://openai.com/dall-e-3)
- [FID评估指标](https://arxiv.org/abs/1706.08500)
- [CLIP模型](https://arxiv.org/abs/2103.00020)

## 更新日志

### v1.0.0 (2024-01-XX)
- 初始版本发布
- 支持SDXL vs DALL-E 3对比
- 完整的评估和可视化系统
- 自动化实验流程

---

*如有问题或建议，请提交Issue或联系开发团队。* 